---
{"dg-publish":true,"permalink":"/courses/tryhackme/try-hack-me/","dgPassFrontmatter":true,"noteIcon":""}
---

# operating system 
## linux 
[[3_code/0xor1Day-main/src/site/notes/courses/tryhackme/linux_fandamentals/Linux Fundamentals\|Linux Fundamentals]]
## windows 
[[3_code/0xor1Day-main/src/site/notes/courses/tryhackme/windows fundamentals/windows fundamentals\|windows fundamentals]]
# text_editor 
[[3_code/0xor1Day-main/src/site/notes/courses/tryhackme/vim/vim\|vim]]
# scripting language 
[[3_code/0xor1Day-main/src/site/notes/courses/tryhackme/Bash Scripting/Bash Scripting\|Bash Scripting]]

# network 
[[3_code/0xor1Day-main/src/site/notes/courses/tryhackme/Network Fundamentals/Network Fundamentals\|Network Fundamentals]]

