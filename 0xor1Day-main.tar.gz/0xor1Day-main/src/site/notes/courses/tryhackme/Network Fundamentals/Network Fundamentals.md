---
{"dg-publish":true,"permalink":"/courses/tryhackme/network-fundamentals/network-fundamentals/","dgPassFrontmatter":true,"noteIcon":""}
---


# What is Networking?

- Task 1 [[3_code/0xor1Day-main/src/site/notes/courses/tryhackme/Network Fundamentals/network/What is Networking\|What is Networking]]
- Task 2 [[3_code/0xor1Day-main/src/site/notes/courses/tryhackme/Network Fundamentals/network/What is the Internet_\|What is the Internet_]]
- Task 3 [[3_code/0xor1Day-main/src/site/notes/courses/tryhackme/Network Fundamentals/network/Identifying Devices on a Network\|Identifying Devices on a Network]]
- Task 4 [[3_code/0xor1Day-main/src/site/notes/courses/tryhackme/Network Fundamentals/network/Ping (ICMP)\|Ping (ICMP)]]
- Task 5 [[3_code/0xor1Day-main/src/site/notes/courses/tryhackme/Network Fundamentals/network/Continue Your Learning Intro to LAN\|Continue Your Learning Intro to LAN]]

# Intro to LAN

- Task 1 [[3_code/0xor1Day-main/src/site/notes/courses/tryhackme/Network Fundamentals/LAN/Introducing LAN Topologies\|Introducing LAN Topologies]]
- Task 2 [[3_code/0xor1Day-main/src/site/notes/courses/tryhackme/Network Fundamentals/LAN/A Primer on Subnetting\|A Primer on Subnetting]]
- Task 3 [[3_code/0xor1Day-main/src/site/notes/courses/tryhackme/Network Fundamentals/LAN/The ARP Protocol\|The ARP Protocol]]
- Task 4 [[3_code/0xor1Day-main/src/site/notes/courses/tryhackme/Network Fundamentals/LAN/The DHCP Protocol\|The DHCP Protocol]]
- Task 5 [[3_code/0xor1Day-main/src/site/notes/courses/tryhackme/Network Fundamentals/LAN/Continue Your Learning OSI Model\|Continue Your Learning OSI Model]]

# OSI Model 


