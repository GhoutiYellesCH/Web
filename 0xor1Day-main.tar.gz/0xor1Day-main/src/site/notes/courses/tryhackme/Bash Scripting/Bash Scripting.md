---
{"dg-publish":true,"permalink":"/courses/tryhackme/bash-scripting/bash-scripting/","dgPassFrontmatter":true,"noteIcon":""}
---

#bash 

---
Task 1 [[3_code/0xor1Day-main/src/site/notes/courses/tryhackme/Bash Scripting/content/Introduction_bash\|Introduction_bash]]

Task 2 [[3_code/0xor1Day-main/src/site/notes/courses/tryhackme/Bash Scripting/content/Our first simple bash scripts\|Our first simple bash scripts ]]

Task 3 [[3_code/0xor1Day-main/src/site/notes/courses/tryhackme/Bash Scripting/content/Variables\|Variables]]

Task 4 [[3_code/0xor1Day-main/src/site/notes/courses/tryhackme/Bash Scripting/content/Parameters\|Parameters]]

Task 5 [[3_code/0xor1Day-main/src/site/notes/courses/tryhackme/Bash Scripting/content/Arrays\|Arrays]]

Task 6 [[3_code/0xor1Day-main/src/site/notes/courses/tryhackme/Bash Scripting/content/Conditionals\|Conditionals]]

Task 7: [[3_code/0xor1Day-main/src/site/notes/courses/tryhackme/Bash Scripting/content/Further reading\|Further reading]]