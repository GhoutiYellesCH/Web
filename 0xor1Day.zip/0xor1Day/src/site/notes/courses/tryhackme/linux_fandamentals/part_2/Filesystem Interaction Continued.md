---
{"dg-publish":true,"permalink":"/courses/tryhackme/linux-fandamentals/part-2/filesystem-interaction-continued/","dgPassFrontmatter":true,"noteIcon":""}
---

