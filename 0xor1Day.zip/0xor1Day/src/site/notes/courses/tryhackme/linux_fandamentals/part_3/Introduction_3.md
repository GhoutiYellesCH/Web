---
{"dg-publish":true,"permalink":"/courses/tryhackme/linux-fandamentals/part-3/introduction-3/","dgPassFrontmatter":true,"noteIcon":""}
---

![Pasted image 20230830181638.png](/img/user/courses/tryhackme/linux_fandamentals/part_3/img/Pasted%20image%2020230830181638.png)

Welcome to part three (and the finale) of the Linux Fundamentals module. So far, throughout the series, you have got hands-on with some fundamental concepts and used some important commands. This room is going to showcase some useful utilities and applications that you are likely to use day-to-day. You're also going to advance your Linux-fu skills by learning about automation, package management, and service/application logging.

answer 
https://www.thedutchhacker.com/linux-fundamentals-part-3-on-tryhackme/
