---
{"dg-publish":true,"permalink":"/courses/tryhackme/windows-fundamentals/windows-fundamentals/","dgPassFrontmatter":true,"noteIcon":""}
---

# part 1 

Task 1 [[courses/tryhackme/windows fundamentals/part 1/Introduction to Windows\|Introduction to Windows]]

Task 2 Windows Editions

Task 3 The Desktop (GUI)

Task 4 The File System

Task 5 The Windows\System32 Folders

Task 6 User Accounts, Profiles, and Permissions

Task 7 User Account Control

Task 8 Settings and the Control Panel

Task 9 Task Manager

Task 10 Conclusion