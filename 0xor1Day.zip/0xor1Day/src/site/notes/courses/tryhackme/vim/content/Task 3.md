---
{"dg-publish":true,"permalink":"/courses/tryhackme/vim/content/task-3/","dgPassFrontmatter":true,"noteIcon":""}
---

