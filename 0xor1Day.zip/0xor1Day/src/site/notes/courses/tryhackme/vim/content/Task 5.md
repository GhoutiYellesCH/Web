---
{"dg-publish":true,"permalink":"/courses/tryhackme/vim/content/task-5/","dgPassFrontmatter":true,"noteIcon":""}
---

