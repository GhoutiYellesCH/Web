---
{"dg-publish":true,"permalink":"/courses/tryhackme/vim/vim-links/","dgPassFrontmatter":true,"noteIcon":""}
---

- https://medium.com/@tr1n1ty8/tryhackme-toolbox-vim-writeup-18ddadbacf72
- http://www.oualline.com/vim-cook.html#char%20twiddling
- https://vimhelp.org/#reference_toc
