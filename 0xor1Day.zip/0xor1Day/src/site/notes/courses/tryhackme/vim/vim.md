---
{"dg-publish":true,"permalink":"/courses/tryhackme/vim/vim/","dgPassFrontmatter":true,"noteIcon":""}
---

Task 1 [[courses/tryhackme/vim/content/Task 1\|Task 1]]

Task 2 [[courses/tryhackme/vim/content/Task 2\|Task 2]]

Task 3 [[courses/tryhackme/vim/content/Task 3\|Task 3]]

Task 4 [[courses/tryhackme/vim/content/Task 4\|Task 4]]

Task 5 [[courses/tryhackme/vim/content/Task 5\|Task 5]]

### writeup
- [vim write up](https://medium.com/@tr1n1ty8/tryhackme-toolbox-vim-writeup-18ddadbacf72)
- [[learn online/tryhackme/vim/links\|links]]
- 