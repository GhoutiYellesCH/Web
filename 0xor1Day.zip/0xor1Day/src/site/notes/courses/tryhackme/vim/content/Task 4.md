---
{"dg-publish":true,"permalink":"/courses/tryhackme/vim/content/task-4/","dgPassFrontmatter":true,"noteIcon":""}
---

