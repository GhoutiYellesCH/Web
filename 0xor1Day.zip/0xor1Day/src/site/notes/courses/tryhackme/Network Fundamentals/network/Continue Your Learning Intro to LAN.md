---
{"dg-publish":true,"permalink":"/courses/tryhackme/network-fundamentals/network/continue-your-learning-intro-to-lan/","dgPassFrontmatter":true,"noteIcon":""}
---

Continue your learning by joining the [[courses/tryhackme/Network Fundamentals/Network Fundamentals#Intro to LAN\|Network Fundamentals#Intro to LAN]] room.