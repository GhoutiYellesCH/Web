---
{"dg-publish":true,"permalink":"/courses/tryhackme/network-fundamentals/lan/continue-your-learning-osi-model/","dgPassFrontmatter":true,"noteIcon":""}
---

Continue your learning by joining the ["OSI Model" room.](https://tryhackme.com/room/osimodelzi)

