---
{"dg-publish":true,"permalink":"/courses/tryhackme/try-hack-me/","dgPassFrontmatter":true,"noteIcon":""}
---

# operating system 
## linux 
[[courses/tryhackme/linux_fandamentals/Linux Fundamentals\|Linux Fundamentals]]
## windows 
[[courses/tryhackme/windows fundamentals/windows fundamentals\|windows fundamentals]]
# text_editor 
[[courses/tryhackme/vim/vim\|vim]]
# scripting language 
[[courses/tryhackme/Bash Scripting/Bash Scripting\|Bash Scripting]]

# network 
[[courses/tryhackme/Network Fundamentals/Network Fundamentals\|Network Fundamentals]]

