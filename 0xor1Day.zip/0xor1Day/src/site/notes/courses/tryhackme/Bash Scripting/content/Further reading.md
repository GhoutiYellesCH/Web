---
{"dg-publish":true,"permalink":"/courses/tryhackme/bash-scripting/content/further-reading/","dgPassFrontmatter":true,"noteIcon":""}
---

Hi there and thank you so much for completing this room on bash scripting! I want to congratulate you on persevering when things got tough and completing the room.

If you want to further extend your knowledge of bash or coding in general I really suggest the following websites:

- [](https://www.codewars.com/)[https://www.codewars.com/](https://www.codewars.com/)
- [](https://www.hackerrank.com/)[https://www.hackerrank.com/](https://www.hackerrank.com/)
- And of course google!

Thanks again. If you want to ask me about anything or have any queries about the room you can reach me on twitter [](https://twitter.com/fieldraccoon)[https://twitter.com/fieldraccoon](https://twitter.com/fieldraccoon)

Good Luck on your bash journey!