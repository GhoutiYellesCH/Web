---
{"dg-publish":true,"permalink":"/courses/tryhackme/bash-scripting/bash-scripting/","dgPassFrontmatter":true,"noteIcon":""}
---

#bash 

---
Task 1 [[courses/tryhackme/Bash Scripting/content/Introduction_bash\|Introduction_bash]]

Task 2 [[Our first simple bash scripts \|Our first simple bash scripts ]]

Task 3 [[courses/tryhackme/Bash Scripting/content/Variables\|Variables]]

Task 4 [[courses/tryhackme/Bash Scripting/content/Parameters\|Parameters]]

Task 5 [[courses/tryhackme/Bash Scripting/content/Arrays\|Arrays]]

Task 6 [[courses/tryhackme/Bash Scripting/content/Conditionals\|Conditionals]]

Task 7: [[courses/tryhackme/Bash Scripting/content/Further reading\|Further reading]]