---
{"dg-publish":true,"permalink":"/00-projects/01-calender-and-my-work/my-main-desk/1-my-witing/01-publish/courses/tryhackme/malewar-history/","dgPassFrontmatter":true,"noteIcon":"","created":"2024-09-19T13:36:47.509+01:00"}
---

- https://www.theregister.com/2012/12/14/first_virus_elk_cloner_creator_interviewed/
- https://www.trendmicro.com/vinfo/us/security/definition/boot-sector-virus#:~:text=Boot%20sector%20viruses%20infect%20the,infect%20the%20computer%20hard%20drive.
- https://www.osnews.com/story/29157/interview-with-ray-tomlinson-on-creeperreaper/
- https://duckduckgo.com/?t=ffab&q=ARPANET&atb=v388-1&ia=web
- https://en.wikipedia.org/wiki/Von_Neumann_architecture
- https://en.wikipedia.org/wiki/PDP-10
- https://en.wikipedia.org/wiki/TENEX_(operating_system)
- https://en.wikipedia.org/wiki/Morris_worm
- https://en.wikipedia.org/wiki/Berkeley_r-commands
- https://en.wikipedia.org/wiki/Data_Protection_Act_2018

