---
{"dg-publish":true,"permalink":"/00-projects/01-calender-and-my-work/my-main-desk/3-code/0xor1-day-main/src/site/notes/courses/tryhackme/network-fundamentals/network/what-is-the-internet/","dgPassFrontmatter":true,"noteIcon":""}
---


Now that we've learnt what a network is and how one is defined in computing (just devices connected), let's explore the Internet.

The Internet is one giant network that consists of many, many small networks within itself. Using our example from the previous task, let's now imagine that Alice made some new friends named Zayn and Toby that she wants to introduce to Bob and Jim. The problem is that Alice is the only person who speaks the same language as Zayn and Toby. So Alice will have to be the messenger!

  ![Pasted image 20230902101345.png](/img/user/courses/tryhackme/Network%20Fundamentals/img/Pasted%20image%2020230902101345.png)

Because Alice can speak both languages, they can communicate to one another through Alice — forming a new network.

The first iteration of the Internet was within the ARPANET project in the late 1960s. This project was funded by the United States Defence Department and was the first documented network in action. However, it wasn't until 1989 when the Internet as we know it was invented by Tim Berners-Lee by the creation of the **W**orld **W**ide **W**eb (**WWW**). It wasn't until this point that the Internet started to be used as a repository for storing and sharing information, just like it is today.

Let's relate Alice's network of friends to computing devices. The Internet looks like a much larger version of this sort of diagram:

  

![Pasted image 20230902101405.png](/img/user/courses/tryhackme/Network%20Fundamentals/img/Pasted%20image%2020230902101405.png)

As previously stated, the Internet is made up of many small networks all joined together.  These small networks are called private networks, where networks connecting these small networks are called public networks -- or the Internet! So, to recap, a network can be one of two types:  

- A private network  
    
- A public network

Devices will use a set of labels to identify themselves on a network, which we will come onto in the task below.

## Answer the questions below

Who invented the World Wide Web?

**answer**: Tim Berners-Lee
