---
{"dg-publish":true,"permalink":"/00-projects/01-calender-and-my-work/my-main-desk/3-code/0xor1-day-main/src/site/notes/courses/tryhackme/vim/content/task-4/","dgPassFrontmatter":true,"noteIcon":""}
---


