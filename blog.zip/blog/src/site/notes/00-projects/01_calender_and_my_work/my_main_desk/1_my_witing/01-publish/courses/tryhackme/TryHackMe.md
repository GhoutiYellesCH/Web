---
{"dg-publish":true,"permalink":"/00-projects/01-calender-and-my-work/my-main-desk/1-my-witing/01-publish/courses/tryhackme/try-hack-me/","dgPassFrontmatter":true,"noteIcon":"","created":"2024-09-19T13:36:47.479+01:00"}
---

# operating system 
## linux 
[[00-projects/01_calender_and_my_work/my_main_desk/1_my_witing/01-publish/courses/tryhackme/linux_fandamentals/Linux Fundamentals\|Linux Fundamentals]]
## windows 
[[00-projects/01_calender_and_my_work/my_main_desk/1_my_witing/01-publish/courses/tryhackme/windows fundamentals/windows fundamentals\|windows fundamentals]]
# text_editor 
[[00-projects/01_calender_and_my_work/my_main_desk/1_my_witing/01-publish/courses/tryhackme/vim/vim\|vim]]
# scripting language 
[[00-projects/01_calender_and_my_work/my_main_desk/1_my_witing/01-publish/courses/tryhackme/Bash Scripting/Bash Scripting\|Bash Scripting]]

# network 
[[00-projects/01_calender_and_my_work/my_main_desk/1_my_witing/01-publish/courses/tryhackme/Network Fundamentals/Network Fundamentals\|Network Fundamentals]]

