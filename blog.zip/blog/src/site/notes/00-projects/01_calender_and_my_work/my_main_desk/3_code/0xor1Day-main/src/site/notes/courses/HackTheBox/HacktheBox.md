---
{"dg-publish":true,"permalink":"/00-projects/01-calender-and-my-work/my-main-desk/3-code/0xor1-day-main/src/site/notes/courses/hack-the-box/hackthe-box/","dgPassFrontmatter":true,"noteIcon":"","created":"2024-09-16T09:05:48.133+01:00"}
---



- [[00-projects/01_calender_and_my_work/my_main_desk/3_code/0xor1Day-main/src/site/notes/courses/HackTheBox/Kioptrix Level 1\|Kioptrix Level 1]]
- 