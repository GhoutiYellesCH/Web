---
{"dg-publish":true,"permalink":"/00-projects/01-calender-and-my-work/my-main-desk/3-code/0xor1-day-main/src/site/notes/courses/tryhackme/vim/vim/","dgPassFrontmatter":true,"noteIcon":""}
---


Task 1 [[00-projects/01_calender_and_my_work/my_main_desk/3_code/0xor1Day-main/src/site/notes/courses/tryhackme/vim/content/Task 1\|Task 1]]

Task 2 [[00-projects/01_calender_and_my_work/my_main_desk/3_code/0xor1Day-main/src/site/notes/courses/tryhackme/vim/content/Task 2\|Task 2]]

Task 3 [[00-projects/01_calender_and_my_work/my_main_desk/3_code/0xor1Day-main/src/site/notes/courses/tryhackme/vim/content/Task 3\|Task 3]]

Task 4 [[00-projects/01_calender_and_my_work/my_main_desk/3_code/0xor1Day-main/src/site/notes/courses/tryhackme/vim/content/Task 4\|Task 4]]

Task 5 [[00-projects/01_calender_and_my_work/my_main_desk/3_code/0xor1Day-main/src/site/notes/courses/tryhackme/vim/content/Task 5\|Task 5]]

### writeup
- [vim write up](https://medium.com/@tr1n1ty8/tryhackme-toolbox-vim-writeup-18ddadbacf72)
- [[learn online/tryhackme/vim/links\|links]]
- 