---
{"dg-publish":true,"permalink":"/00-projects/01-calender-and-my-work/my-main-desk/1-my-witing/01-publish/courses/tryhackme/network-fundamentals/network-fundamentals/","dgPassFrontmatter":true,"noteIcon":"","created":"2024-09-19T13:36:47.518+01:00"}
---


# What is Networking?

- Task 1 [[00-projects/01_calender_and_my_work/my_main_desk/1_my_witing/01-publish/courses/tryhackme/Network Fundamentals/network/What is Networking\|What is Networking]]
- Task 2 [[00-projects/01_calender_and_my_work/my_main_desk/1_my_witing/01-publish/courses/tryhackme/Network Fundamentals/network/What is the Internet_\|What is the Internet_]]
- Task 3 [[00-projects/01_calender_and_my_work/my_main_desk/1_my_witing/01-publish/courses/tryhackme/Network Fundamentals/network/Identifying Devices on a Network\|Identifying Devices on a Network]]
- Task 4 [[00-projects/01_calender_and_my_work/my_main_desk/1_my_witing/01-publish/courses/tryhackme/Network Fundamentals/network/Ping (ICMP)\|Ping (ICMP)]]
- Task 5 [[00-projects/01_calender_and_my_work/my_main_desk/1_my_witing/01-publish/courses/tryhackme/Network Fundamentals/network/Continue Your Learning Intro to LAN\|Continue Your Learning Intro to LAN]]

# Intro to LAN

- Task 1 [[00-projects/01_calender_and_my_work/my_main_desk/1_my_witing/01-publish/courses/tryhackme/Network Fundamentals/LAN/Introducing LAN Topologies\|Introducing LAN Topologies]]
- Task 2 [[00-projects/01_calender_and_my_work/my_main_desk/1_my_witing/01-publish/courses/tryhackme/Network Fundamentals/LAN/A Primer on Subnetting\|A Primer on Subnetting]]
- Task 3 [[00-projects/01_calender_and_my_work/my_main_desk/1_my_witing/01-publish/courses/tryhackme/Network Fundamentals/LAN/The ARP Protocol\|The ARP Protocol]]
- Task 4 [[00-projects/01_calender_and_my_work/my_main_desk/1_my_witing/01-publish/courses/tryhackme/Network Fundamentals/LAN/The DHCP Protocol\|The DHCP Protocol]]
- Task 5 [[00-projects/01_calender_and_my_work/my_main_desk/1_my_witing/01-publish/courses/tryhackme/Network Fundamentals/LAN/Continue Your Learning OSI Model\|Continue Your Learning OSI Model]]

# OSI Model 


