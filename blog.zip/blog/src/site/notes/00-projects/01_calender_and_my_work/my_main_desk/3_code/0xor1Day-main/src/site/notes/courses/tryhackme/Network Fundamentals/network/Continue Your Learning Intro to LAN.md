---
{"dg-publish":true,"permalink":"/00-projects/01-calender-and-my-work/my-main-desk/3-code/0xor1-day-main/src/site/notes/courses/tryhackme/network-fundamentals/network/continue-your-learning-intro-to-lan/","dgPassFrontmatter":true,"noteIcon":""}
---


Continue your learning by joining the [[00-projects/01_calender_and_my_work/my_main_desk/3_code/0xor1Day-main/src/site/notes/courses/tryhackme/Network Fundamentals/Network Fundamentals#Intro to LAN\|Network Fundamentals#Intro to LAN]] room.