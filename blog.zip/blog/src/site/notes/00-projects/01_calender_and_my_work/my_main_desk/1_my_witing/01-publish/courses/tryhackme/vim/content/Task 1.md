---
{"dg-publish":true,"permalink":"/00-projects/01-calender-and-my-work/my-main-desk/1-my-witing/01-publish/courses/tryhackme/vim/content/task-1/","dgPassFrontmatter":true,"noteIcon":"","created":"2024-09-19T13:36:47.476+01:00"}
---

**Lets get started!**

To check whether Vim is installed:  

    - Launch a Terminal Window

    - Type "vim"

If you're looking at the Vim splash page

![Pasted image 20230831145350.png](/img/user/00-projects/01_calender_and_my_work/my_main_desk/1_my_witing/01-publish/courses/tryhackme/vim/content/img/Pasted%20image%2020230831145350.png)

Then you're in luck!   

Otherwise type:

**Debian-Based Distributions:**

sudo apt install vim

**Arch-Based Distributions:**

sudo pacman -S vim

**Fedora-Based Distributions:**

sudo dnf install vim-enhanced

**Windows:**

Go to: [https://www.vim.org/download.php#pc](https://www.vim.org/download.php#pc)[](https://www.vim.org/download.php#pc)

Download and install the "self-installing-executable"
