---
{"dg-publish":true,"permalink":"/00-projects/01-calender-and-my-work/my-main-desk/1-my-witing/01-publish/01-notes/02-arm-architectur/architecture/architecture/","dgPassFrontmatter":true,"noteIcon":"","created":"2024-09-19T13:36:47.574+01:00"}
---


https://youtu.be/jx-w2o-Lj8g?si=Hy95uCzexZclrA09

https://youtu.be/d86ws7mQYIg?si=IArJJtcBOMYg9RP2

https://youtu.be/5f3NJnvnk7k?si=R4mcco7YSS_oe3lv

https://youtu.be/0rNEtAz3wJQ?si=w5ZSIrLyUVr4jr7Y

https://youtu.be/vhKSfKbpZSQ?si=S3Vn3pgnixCNvTOH




- Chipset :
![01-publish/01_notes/02_arm_architectur/architecture/img/Intel-H470-Chipset-Diagram.jpg](/img/user/00-projects/01_calender_and_my_work/my_main_desk/1_my_witing/01-publish/01_notes/02_arm_architectur/architecture/img/Intel-H470-Chipset-Diagram.jpg)

![01-publish/01_notes/02_arm_architectur/architecture/img/Pasted image 20231128231543.png](/img/user/00-projects/01_calender_and_my_work/my_main_desk/1_my_witing/01-publish/01_notes/02_arm_architectur/architecture/img/Pasted%20image%2020231128231543.png)


