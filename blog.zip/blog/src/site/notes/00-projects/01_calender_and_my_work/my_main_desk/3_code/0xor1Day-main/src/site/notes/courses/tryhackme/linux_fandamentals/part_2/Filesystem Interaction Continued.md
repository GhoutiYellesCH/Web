---
{"dg-publish":true,"permalink":"/00-projects/01-calender-and-my-work/my-main-desk/3-code/0xor1-day-main/src/site/notes/courses/tryhackme/linux-fandamentals/part-2/filesystem-interaction-continued/","dgPassFrontmatter":true,"noteIcon":"","created":"2024-09-16T09:05:48.141+01:00"}
---


