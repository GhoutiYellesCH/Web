---
{"dg-publish":true,"permalink":"/00-projects/01-calender-and-my-work/my-main-desk/3-code/0xor1-day-main/src/site/notes/courses/tryhackme/linux-fandamentals/part-3/deploy-your-linux-machine/","dgPassFrontmatter":true,"noteIcon":"","created":"2024-09-16T09:05:48.141+01:00"}
---


Deploying Your Linux Machine

Press the green "Start Machine" button on the top-right of this task and then scroll to the top of the page to see the deployment information like so

![Pasted image 20230830182231.png](/img/user/courses/tryhackme/linux_fandamentals/part_3/img/Pasted%20image%2020230830182231.png)

The IP address displayed is the address of your Linux machine that you will be logging into using SSH. Take note of this for now.

  

Deploying the TryHackMe AttackBox

Looking at the top of the page, press the "Start AttackBox" button to deploy the TryHackMe AttackBox that we will be interacting with. The TryHackMe AttackBox is a Ubuntu Linux machine that is hosted online in the cloud and can be interacted with via your browser. You will be using this to interact with the machine that you deploy in this task.  

![Pasted image 20230831124803.png](/img/user/courses/tryhackme/linux_fandamentals/part_3/img/Pasted%20image%2020230831124803.png)

  

**Use The Following Credentials:**

IP Address: **MACHINE_IP**

Username: **tryhackme**

Password: **tryhackme**