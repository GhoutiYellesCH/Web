---
{"dg-publish":true,"permalink":"/00-projects/01-calender-and-my-work/my-main-desk/1-my-witing/01-publish/courses/tryhackme/network-fundamentals/lan/continue-your-learning-osi-model/","dgPassFrontmatter":true,"noteIcon":""}
---

Continue your learning by joining the ["OSI Model" room.](https://tryhackme.com/room/osimodelzi)

