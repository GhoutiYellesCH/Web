---
{"dg-publish":true,"permalink":"/00-projects/01-calender-and-my-work/my-main-desk/1-my-witing/01-publish/faculter-cs/semester-4/orionte-objet-progamming-2/les-collections/","dgPassFrontmatter":true,"noteIcon":""}
---

Status:
Tags: <% tp.file.cursor(3) %>
Links: [[<% tp.file.cursor(4) %>\|<% tp.file.cursor(4) %>]]

___
# Les collections
<% tp.file.cursor(5) %>
___

# introduction 

## definition 
Une collection est un objet qui contient d’autres objets  
### Exemple  
Un tableau est une collection  
### Classes  
• AbstractCollection, ArrayList, Arrays, Collections, HashSet, LinkedList, TreeSet, Vector…  
### Interfaces  
• List, Map, Set, SortedMap, SortedSet  
Ces classes et interfaces se trouvent dans le paquetage java.util  


# ArrayList  
## Description  
- ArrayList fournit un tableau ==dynamique== et  
- spécifie AbstractList et implémente List.  
### Déclaration  
```java
public class ArrayList<E> extends AbstractList<E>  
	implements List<E>, RandomAccess, Cloneable, Serializable 
```
## Quelques caractéristiques  
La classe ==java.util.ArrayList== est la classe la plus utilisée  
- Un ArrayList se comporte comme un tableau, il contient  
plusieurs objets (de la classe Object uniquement)  
- Ne peut contenir des types primitifs  
- Accède à ses éléments à l’aide d'un index  
- Pas de taille prédéfinie  
- Existe des méthodes pour ajouter ou enlever un élément  
  
## Création d’une instance ArrayList  
Il y a des constructeurs :  
```java
	ArrayList()  
	ArrayList(int initialCapacity)  
```
Il y a deux manières d’ajouter un élément :  
- à la fin d'un ArrayList : ==boolean add(Object newElement)==  
- à une position donnée : ==void add(int index, Object newElement)== 
le paramètre ==index== indique où insérer le nouvel élément  
## Autres méthodes d’ArrayList  
- Pour remplacer un objet à une position donnée Object :  
```java
	ArrayList()  
	ArrayList(int initialCapacity)  
```
set(int index, Object newElement)  
- Pour accéder à un élément ==Object get(int index)==  
- Pour tester le contenu ==boolean isEmpty() == 
- pour connaître le nombre d’éléments dans la liste 
```java
	int size();
```
- Pour savoir si un objet est présent ou non dans une liste  
```java
	boolean contains(Object obj)   
```
- Pour supprimer un élément à une position donnée,  
```java
	remove(int index)
```
#### Exemple  
```java
public class Etudiant{  
	private String leNom;  
	public Etudiant(String unNom){  
		leNom = unNom;  
	}  
	public void setNom(String nom) { leNom = nom; }  
	public String getNom() { return leNom; }  
}
```
#### Exemple (utilisant la classe Object)  
```java
public static void main(String [] args) {  
	ArrayList <Object> tableauEtudiants= new ArrayList<Object>();  
	Etudiant e1 = new Etudiant("Bachir")  
	Etudiant e2 = new Etudiant("Nadir");  
	tableauEtudiants.add(e1);  
	tableauEtudiants.add(e2);  
	if (! tableauEtudiants.isEmpty()) {  
		for (int i = 0; i< tableauEtudiants.size();i++)  
			System.out.println(((Etudiant) tableauEtudiants.get(i)).getNom());  
			tableauEtudiants.remove(1);}  
		}
	}
}
```  
#### Exemple (utilisant la classe Etudiant )  
```java 
public static void main(String [] args) {  
	ArrayList<Etudiant> tableauEtudiants =  new ArrayList<Etudiant> ();  
	Etudiant emp1 = new Etudiant(« Bachir ");  
	Etudiant emp2 = new Etudiant("Nadir");  
	tableauEtudiants.add(emp1);  
	tableauEtudiants.add(emp2);  
	if (!tableauEtudiants.isEmpty()) {  
		for (int i = 0; i< tableauEtudiants.size(),i++)  {
			System.out.println((Etudiant) tableauEtudiants.get(i).getNom());  
			tableauEtudiants.remove(1);}  
		}
	}
}
```

## Boucles
### Exemple
Utilisation d’un index :
```java
for (int i = 0; i< tableauEtudiants.size();i++)
	System.out.println( tableauEtudiants.get(i).getNom());
```
## Boucle for-each
Répéter des actions pour chaque objet d'une collection donnée

![Pasted image 20240312112111.png](/img/user/00-projects/01_calender_and_my_work/my_main_desk/1_my_witing/01-publish/Faculter%20CS/Semester%204/oriont%C3%A9%20objet%20progamming%202/img/Pasted%20image%2020240312112111.png)
### Exemple
```java
for (Etudiant e : tableauEtudiants)
	System.out.println( e.getNom());
```
### Exemple
### Utilisation de Iterator
ArrayList implémente la méthode ==Iterator iterator()== qui retourne un itérateur sur l’ensemble des éléments.
```java
for (Iterator<Etudiant> i=tableauEtudiants.iterator();i.hasNext();)
	System.out.println( i.next().getNom());
```
## Exercice
Ecrire une classe ==TestClientIterator== qui
1. Remplira les 03 objets suivant dans un objet ArrayList.

| Element | Type    | Valeur |
| ------- | ------- | ------ |
| 1       | Integer | 42     |
| 2       | String  | "test" |
| 3       | Bouble  | -12.34 |

2. Parcourir cette liste (comme ==Iterator== et/ou ==non==), afind’ afficher ces trois éléments.
```java
import java.util.*;
class TestClientIterator {
	public static void main(String[] args) {
		ArrayList<Object> al = new ArrayList<Object>();
		al.add(new Integer(42));
		al.add(new String("test"));
		al.add(new Double("-12.34"));
		// Commme Iterator
		for(Iterator<Object> iter=al.iterator(); iter.hasNext();)
			System.out.println( iter.next() );
		//Pas comme Iterator
		for(Object o:al) System.out.println( o );
	}
} 
```

Comme ArrayList, ==LinkedList== implémentent l'interface ==List==.
- ArrayList utilise un ==tableau== extensible
- Utilise ==efficacement== les méthodes ==get() et set()==.
- LinkedList est implémentée sous forme d'une ==liste chaînée==,
- Ces performances ==d'ajout et de suppression== sont meilleures que celles de ArrayList, mais mauvaises pour les méthodes get() et set().
## Comparaison de temps d’exécution de méthodes entre objets LinkedList et ArrayList
--------------méthode ==add== ----------------
	ArrayList : 101
	LinkedList : 469
--------------méthode ==get== -----------------
	ArrayList : 1
	LinkedList : 24592
--------------méthode ==remove== ------------
	ArrayList : 2671
	LinkedList : 94
----------------------------------------------
# Autres Collections

![Pasted image 20240312113558.png](/img/user/00-projects/01_calender_and_my_work/my_main_desk/1_my_witing/01-publish/Faculter%20CS/Semester%204/oriont%C3%A9%20objet%20progamming%202/img/Pasted%20image%2020240312113558.png)
Plusieurs types de collections :
- Interfaces ==List== et ==Set== qui héritent l'interface ==Collection==
	- Les objets List acceptent toutes les valeurs, même les valeurs null
	- Set n'autorisent pas deux fois la même valeur (le même objet), ce qui est pratique pour une liste d'éléments uniques.
- Ainsi que l'interface ==Map== 
	Les Map fonctionnent avec un système clé - valeur pour ranger et retrouver les objets qu'elles contiennent.

## application {Untitled}

### type 1

### type 1

### type 1

## Criticisms {Untitled}

### type 1

### type 1

### type 1

## Future of {Untitled}

### type 1

### type 1

### type 1

References:
- l


Created:: 2024-03-12 11:08