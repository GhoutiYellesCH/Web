---
{"dg-publish":true,"permalink":"/00-projects/01-calender-and-my-work/my-main-desk/1-my-witing/01-publish/01-notes/02-arm-architectur/00-eniac-1945-first-cpu-ever/","dgPassFrontmatter":true,"noteIcon":"","created":"2024-09-19T13:36:47.574+01:00"}
---


ENIAC, which stands for Electronic Numerical Integrator and Computer, was one of the earliest general-purpose electronic digital computers. It was designed and built during World War II in the United States and became operational in 1945. ENIAC was a significant milestone in the history of computing and is considered the first electronic general-purpose computer.

![](https://www.youtube.com/watch?v=bGk9W65vXNA)

Here are some key details about ENIAC:

1. **Purpose and Development:** ENIAC was developed to calculate artillery firing tables for the United States Army's Ballistic Research Laboratory. The need for such complex calculations arose during the war, and ENIAC was designed to automate and speed up this process significantly.

2. **Invention and Inventors:** ENIAC was invented by John W. Mauchly and J. Presper Eckert, who were engineers and inventors. They started working on the concept in 1943 and completed the construction of ENIAC in 1945.

3. **Size and Components:** ENIAC was an enormous machine, covering about 1,800 square feet (167 square meters) of floor space. It used around 17,468 vacuum tubes, 7,200 crystal diodes, 1,500 relays, 70,000 resistors, 10,000 capacitors, and approximately 5 million hand-soldered joints. The machine weighed around 30 tons.

4. **Speed and Capabilities:** ENIAC was incredibly fast compared to the mechanical calculators of its time. It could perform about 5,000 additions per second, a remarkable speed in the 1940s. It was also capable of performing complex multiplication and division operations.

5. **Programming:** ENIAC was programmed using plugboards and switches. It didn't store programs in memory as modern computers do. Instead, the wiring of the machine had to be manually changed to perform different tasks, making it a labor-intensive process to switch from one computation to another.

6. **Legacy:** ENIAC's successful operation paved the way for further developments in electronic computing. Its design principles influenced the development of subsequent computers, and it demonstrated the potential of electronic computing devices in various scientific and engineering applications.

ENIAC's significance lies in its status as the first large-scale, fully electronic, general-purpose digital computer. It marked the beginning of the electronic computing era, leading to rapid advancements in computer technology over the following decades.