---
{"dg-publish":true,"tags":["AI","ML","Python"],"permalink":"/00-projects/01-calender-and-my-work/my-main-desk/1-my-witing/01-publish/faculter-cs/semester-4/projet-pluridesiplinaire/pratique-du-machine-learning-in-python/","dgPassFrontmatter":true,"noteIcon":""}
---


Status:
Tags: <% tp.file.cursor(3) %>
Links: [[<% tp.file.cursor(4) %>\|<% tp.file.cursor(4) %>]]

___
# pratique du machine learning in python
<% tp.file.cursor(5) %>
___

# introduction 

Bonjour et bienvenue à notre cours sur le machine learning avec Python.

Dans ce cours, nous étudierons la théorie de l'apprentissage automatique ou machine learning.

Et comment utiliser les bibliothèques Python populaires pour mettre en œuvre des modèles d'apprentissage automatique en utilisant le langage Python.

Alors commençons.

![Pasted image 20240314111015.png](/img/user/00-projects/01_calender_and_my_work/my_main_desk/1_my_witing/01-publish/Faculter%20CS/Semester%204/projet%20pluridesiplinaire/img/Pasted%20image%2020240314111015.png)

Ce cours est divisé en dix sections.

Nous allons parcourir ces sections une par une.

La première est une [[00-projects/01_calender_and_my_work/my_main_desk/1_my_witing/01-publish/Faculter CS/Semester 4/projet pluridesiplinaire/pratique du machine learning in python#Introduction aux machines learning\|pratique du machine learning in python#Introduction aux machines learning]].

Dans cette section, nous allons découvrir le monde fascinant du machine learning.

Ensuite, nous étudierons quatre algorithmes pratiques de machine learning, à savoir ==la régression, la classification, le regroupement et le système de recommandation==.

Très bien.

Commençons maintenant avec notre première section qui est :

## Introduction aux machines learning.

### Alors, qu'est ce que le machine learning?

![OIG1.jpg](/img/user/00-projects/01_calender_and_my_work/my_main_desk/1_my_witing/01-publish/Faculter%20CS/Semester%204/projet%20pluridesiplinaire/img/OIG1.jpg)
Le machine learning est une forme d'intelligence artificielle qui consiste à apprendre aux machines à effectuer des tâches sans les programmer explicitement.

L'objectif du machine learning est de comprendre la structure des données, puis d'adapter ces données à des modèles qui peuvent être compris et utilisés par des personnes.

### **Le machine learning présente les caractéristiques suivantes.**

1. Apprend la relation entre les données.
2. Il peut prédire des événements pour d'autres données.
3. Améliorer les performances par rapport à l'expérience.


Tout d'abord, nous alimentons les machines avec des données et la machine apprend.

Elle va apprendre la relation entre ces données.

Ensuite, sur la base de cette relation, elle peut prédire des événements pour d'autres données.

Et troisièmement, ses performances s'améliorent avec le temps, ce qui signifie qu'ils possèdent une certaine intelligence comme les humains.

## application 
![_54107f30-2de4-4c5d-a413-eff211f8c1f9.jpg](/img/user/00-projects/01_calender_and_my_work/my_main_desk/1_my_witing/01-publish/Faculter%20CS/Semester%204/projet%20pluridesiplinaire/img/_54107f30-2de4-4c5d-a413-eff211f8c1f9.jpg)
Je crois que je n'aurais pas tort de dire que le machine learning est presque partout.

Il a tellement d'applications.
- Diagnostique Med 
- Voitures autonomes 
- Filtrage de spam
- Trading en bourse 
- Traduction automatique
- Recommandation produit 
- Prediction de circulation 
- Reconnaissance d’image
- Reconnaissance vocale
Et plein d’autres !

Par exemple, il est utilisé pour le diagnostic médical.

Les voitures à conduite autonome, le filtrage de mail non sollicité, le commerce boursier, la traduction automatique de langues, les recommandations de produits.

Même la prédiction du trafic, la reconnaissance d'images, la reconnaissance vocale et encore plein d'autres applications.

Voici quelques exemples spécifiques d'applications du machine learning.

Il est utilisé pour détecter le cancer et les tumeurs cérébrales par exemple.

En deux, on peut voir avec l'entreprise Tesla qui construit des voitures.

Elle travaille sur les voitures autonomes en utilisant le machine learning en trois.

Gmail sépare les mails indésirables dans un dossier différent de celui des courriers importants et utilise

## Méthodes de Machine Learning

En machine learning.

Les tâches sont généralement classées en grandes catégories.

Ces catégories sont basées sur la façon dont l'apprentissage est reçu.

Deux des méthodes d'apprentissage automatique les plus largement adoptées sont l'apprentissage supervisé et l'apprentissage non supervisé.

### Qu’est-ce que l’apprentissage supervisé ?
Dans l'apprentissage supervisé.
![Pasted image 20240314140200.png](/img/user/00-projects/01_calender_and_my_work/my_main_desk/1_my_witing/01-publish/Faculter%20CS/Semester%204/projet%20pluridesiplinaire/img/Pasted%20image%2020240314140200.png)
L'ordinateur reçoit des exemples d'entrées étiquetées avec les sorties souhaitées.

L'objectif de cette méthode est de permettre à l'algorithme d'apprendre en comparant ses résultats réels aux résultats enseignés afin de détecter les erreurs et de modifier le modèle en conséquence.

L'apprentissage supervisé utilise donc des modèles pour prédire et attribuer des valeurs d'étiquetage aux données non étiquetées.

![Pasted image 20240314140348.png](/img/user/00-projects/01_calender_and_my_work/my_main_desk/1_my_witing/01-publish/Faculter%20CS/Semester%204/projet%20pluridesiplinaire/img/Pasted%20image%2020240314140348.png)

Comme nous pouvons le voir dans la figure, nous avons fourni l'ensemble des données avec les étiquettes.

Donc, sur la base de l'ensemble des données étiquetées d'entrée, le modèle va prédire la classe de l'ensemble de données de test comme Carré et Triangle.

Un cas courant de l'apprentissage supervisé consiste à utiliser des données historiques pour prédire des événements futurs statistiquement probables.

Il peut utiliser des informations boursières historiques pour, par exemple, anticiper les fluctuations à venir.

Ou encore des photos de chiens marqués peuvent être utilisées comme des données d'entrée pour classer des photos de chiens non marqués.
### Qu’est-ce que l’apprentissage non supervisé ?
Vient ensuite l'apprentissage non supervisé, comme son nom l'indique, dans l'apprentissage non supervisé.

![Pasted image 20240314140501.png](/img/user/00-projects/01_calender_and_my_work/my_main_desk/1_my_witing/01-publish/Faculter%20CS/Semester%204/projet%20pluridesiplinaire/img/Pasted%20image%2020240314140501.png)

Les données ne sont pas étiquetées, de sorte que l'algorithme d'apprentissage doit trouver des points communs entre les données d'entrée.

Comme nous pouvons le voir dans la figure que nous avons fourni, nous avons donné des données brutes, sans étiquette en entrée.

Ensuite, l'algorithme divise les données en différents groupes en fonction de leur similarité.

Ainsi, il regroupe les chiens et les chats séparément.

L'approche de l'apprentissage non supervisée permet de découvrir des modèles cachés dans un ensemble de données qui sont nécessaires pour classer les données brutes.

Les données non étiquetées étant plus abondantes que les données étiquetées.

Les méthodes d'apprentissage automatique qui facilitent l'apprentissage non supervisé sont particulièrement précieuses.

### Apprentissage supervisé vs apprentissage non supervisé

Dans ce cours, nous aborderons deux concepts l'apprentissage supervisé et l'apprentissage non supervisé.

Et comment les encadrer mathématiquement?

Je vais expliquer l'idée de comment nous pourrions décrire mathématiquement ce que l'apprentissage supervisé et non supervisé implique réellement en termes de signification.

Les deux idées clés ici sont supervisées et non supervisées, qui sont les deux paradigmes les plus répandus en data science.

Il existe également l'apprentissage par renforcement qui a une structure différente, mais nous ne la aborderons pas ici.

Dans ce cours, nous allons nous concentrer sur la différence entre deux concepts.

L'apprentissage supervisé et l'apprentissage non supervisé.

![Pasted image 20240314140643.png](/img/user/00-projects/01_calender_and_my_work/my_main_desk/1_my_witing/01-publish/Faculter%20CS/Semester%204/projet%20pluridesiplinaire/img/Pasted%20image%2020240314140643.png)

L'apprentissage supervisé consiste à fournir des étiquettes aux données.

C'est ce que signifie la supervision.

On parle d'apprentissage non supervisé lorsque vous ne donnez aucune information sur les données et qu'il doit découvrir des modèles dans les données afin de les exploiter et de vous les représenter.

Je vais vous donner un exemple pour le démontrer.

Alors que l'apprentissage supervisé implique de placer des étiquettes sur votre ensemble de données d'entraînement pour donner à l'algorithme une idée de ce que vous voulez qu'il fasse.

L'apprentissage non supervisé consiste à jeter des données dans le pot et à lui demander de détecter des modèles.

Ici, vous voyez un tas de points gris.

Et votre travail consiste à écrire un algorithme d'apprentissage non supervisé, qui peut vous dire comment regrouper et classer ces données.

Ici, il est assez facile de voir qu'il y a un cluster ici et un cluster là bas.

Donc ce que nous aimerions faire, c'est créer un algorithme qui, tout comme notre œil nu, peut nous dire que ces deux clusters sont distincts.

Une chose à noter ici lorsque ces groupes se rapprochent, il est beaucoup plus difficile de dire ou sont les groupes.

Et même s'il y a un groupe comme je ne vous dis rien d'autre que la position de chaque ensemble de données dans un certain espace d'état, votre tâche consiste à me dire s'il y a ou non un, deux, trois, quatre

ou même plusieurs groupes de même types de données.

Vos mesures de performance seront toujours meilleures dans un contexte supervisé.

Voici comment cela fonctionne dans un cadre supervisé.

Je vous donne des données et vous devez décider si les boules grises restantes appartiennent à l'une des deux classes suivantes, bleue ou rouge.

Votre travail consiste à déterminer à quelle classe appartiennent les boules grises restantes.

Ici, vous verrez que cela aide vraiment, car vous pouvez dire que tout ce qui se trouve dans ce groupe sera bleu.

Et là bas, tout ce qui se trouve dans ce groupe sera rouge.

Lorsque je les mélange, vous pouvez voir que j'ai créé un travail de classification beaucoup plus difficile. 

Mais vous pouvez voir principalement que les boules bleues sont ici et les rouges là.

C'est donc le début de la structure de ce que nous devons comprendre, de l'apprentissage supervisé et non supervisé.

Tout se résume à la formation d'étiquette.

Plus tard dans ce cours, nous passerons en revue certaines des principales méthodes les plus populaires pour l'apprentissage supervisé et l'apprentissage non supervisé.

Afin que vous ayez une meilleure compréhension des principes impliqués.

## Implementation D'algorithmes ML en Python {pratique du machine learning in python}

### Introduction 
Maintenant, nous avons une idée de ce qu'est le machine learning en général.

Bientôt, nous allons rentrer dans le vif du sujet en commençant à implémenter des algorithmes.

Avant ça, nous allons devoir mettre en place l'environnement qui nous sera utile pour la suite.

Le langage informatique que nous allons utiliser et le langage de programmation Python.

![th-4175779202.jpg](/img/user/00-projects/01_calender_and_my_work/my_main_desk/1_my_witing/01-publish/Faculter%20CS/Semester%204/projet%20pluridesiplinaire/img/th-4175779202.jpg)

Python est un langage de programmation qui est beaucoup utilisé en datacenter.

Une des raisons de sa popularité actuelle et qu'il est déjà très utilisé dans le monde et qui possède de multiples librairies bibliothèques.

En français, on peut citer par exemple Numbi Sipi, Math Plutôt Lib Panda ou Saint-Kitts Learning.
### Bibliothèques Python pour le Machine Learning

Voyons quel type de bibliothèque nous avons.

Premièrement, on a.

![Pasted image 20240314141133.png](/img/user/00-projects/01_calender_and_my_work/my_main_desk/1_my_witing/01-publish/Faculter%20CS/Semester%204/projet%20pluridesiplinaire/img/Pasted%20image%2020240314141133.png)

La bibliothèque NumPy, Numpy permet de traiter de grands tableaux et matrices multidimensionnelles ainsi qu'une large collection de fonctions mathématiques de haut niveau pour opérer sur ces tableaux.

Numpy permet de traiter de grands tableaux et matrices multidimensionnels, ainsi qu'une large collection de fonctions mathématiques de haut niveau pour opérer sur
ces tableaux.

Scipy est utilisé pour le calcul scientifique et le calcul technique.
SciPy contient des modules pour l'optimisation, l'algèbre linéaire, l'intégration, les fonctions spéciales, le traitement des signaux et des images, ainsi que d'autres tâches courantes en sciences et en ingénierie.

Le troisième est Matplotlib.

Matplotlib est une bibliothèque de traçage, et elle est facile à utiliser avec Numpy parce que sa partie numérique est intégrée à Numpy.

Puis il y a les bibliothèques de pandas pandas et conçus pour la manipulation et l'analyse de données.

Il offre notamment des structures de données et des opérations pour la manipulation de tableaux numériques et de séries chronologiques

En dernier, il y Scikit-learn, également connu sous le nom de SKLearn.

C'est une bibliothèque libre d'apprentissage automatique pour le langage de programmation Python.

Elle propose divers algorithmes de classification, de régression et de regroupement.

Elle est conçue pour interagir avec les bibliothèques numériques et scientifiques Python, NumPy et SciPy.
### Configuration de Python

Dans ce cours, nous allons travailler avec Python trois.

Python deux est une version obsolète de Python.

![Pasted image 20240314141912.png](/img/user/00-projects/01_calender_and_my_work/my_main_desk/1_my_witing/01-publish/Faculter%20CS/Semester%204/projet%20pluridesiplinaire/img/Pasted%20image%2020240314141912.png)

Ce graphique montre la popularité de Python trois par rapport à Python deux dans les cinq dernières années.

Et comme vous pouvez le voir, Python trois gagne largement.

Pour installer Python sur Windows, Aller sur: https://www.python.org/, cliquez sur Download.

[step by step guide how to install on windows](https://www.howtogeek.com/197947/how-to-install-python-on-windows/)

[step by step guide how to install on mac](https://www.dataquest.io/blog/installing-python-on-mac/)

[step by step guide how to install on ubuntu 22.04](https://linuxize.com/post/how-to-install-python-on-ubuntu-22-04/)

Cela vous montrera la dernière version de Python trois pour votre système d'exploitation.

### Qu’est-ce que Jupyter ?

![Pasted image 20240314143240.png](/img/user/00-projects/01_calender_and_my_work/my_main_desk/1_my_witing/01-publish/Faculter%20CS/Semester%204/projet%20pluridesiplinaire/img/Pasted%20image%2020240314143240.png)

l'Environnement d'intégration de Python que nous allons utiliser pour coder.

Et Jupiter not book.

Je vous recommande d'utiliser Jupiter aussi.

Jupiter, un notebook est une application web qui vous permet de créer des documents pouvant contenir du code, des visualisations et du texte narratif.

On a fini cette partie du court.

Voici une question pour vous lequel des énoncés suivants est vrai au sujet de l'apprentissage automatique non supervisé?

### Installation d’Anaconda Windows, Mac et Ubuntu

Pour télécharger Anaconda, cliquez sur le lien [anaconda](https://www.anaconda.com/).

Cliquez sur Download.

- [how to install in linux](https://docs.anaconda.com/free/anaconda/install/linux/)
- [how to install in windows](https://docs.anaconda.com/free/anaconda/install/windows/)
- [how to install in mac](https://docs.anaconda.com/free/anaconda/install/mac-os/)

Alors si tout s'est bien passé, Anaconda devrait être installé sur votre machine.

Pour lancer du jupyter Notebook. [ici][https://towardsdatascience.com/how-to-launch-jupyter-notebook-quickly-26e500ad4560]

Python trois pour créer un nouveau notebook.

Pour faire un nouveau du jupyter Notebook, cliquer sur New puis Python trois.

Un Jupyter Notebook vierge s'ouvrira dans un autre onglet.


![Pasted image 20240314143338.png](/img/user/00-projects/01_calender_and_my_work/my_main_desk/1_my_witing/01-publish/Faculter%20CS/Semester%204/projet%20pluridesiplinaire/img/Pasted%20image%2020240314143338.png)

Passons ailleurs à la suite.

### Implémentation de Python dans Jupyter

Voici l'interface de Duo jupyter Notebook que nous avons vu précédemment.

Du jupyter Notebook à une structure basée sur des cellules de code.

Cela nous permet d'avoir une visualisation du code des équations mathématiques du texte narratif en un seul endroit.

On peut avoir autant de cellules qu'on veut.

Pour l'instant restons sur juste le fait d'écrire du code en python sur le jupyter notebook.

Dans cette cellule, écrivez Print, ouvrez la parenthèse, ouvrez les guillemets, hello world.

Fermez la parenthèse, fermez les guillemets et cliquez sur le bouton Run.

La sortie du code s'affiche juste en dessous.

![Pasted image 20240314143753.png](/img/user/00-projects/01_calender_and_my_work/my_main_desk/1_my_witing/01-publish/Faculter%20CS/Semester%204/projet%20pluridesiplinaire/img/Pasted%20image%2020240314143753.png)

Passons maintenant à la suite.

### Gestion des répertoires dans Jupyter Notebook

Maintenant nous allons regarder comment gérer les différents répertoires dans un notebook pour ouvrir un duo PDA notebook dans un certain répertoire.

Copier coller le chemin de ce répertoire dans votre barre de recherche.

Tapez Anaconda promptes et ouvrez le.

Anaconda.

Prompte et l'interface de lignes de commande d'un Konda.

Ça va ouvrir Anaconda Ponte dans votre répertoire Windows.

Si votre répertoire est dans un autre drive, vous devez d'abord changer de drive.

Dans ce cas, nous voulons changer.

Pour aller dans le drive D, on écrit D deux points et on appuie sur Entrée.

Ensuite, pour passer au répertoire souhaité, on tape cd et on colle le chemin du répertoire, puis on appuie sur Entrée.

Finalement, pour lancer du PDF Notebook, écrivez simplement du pétale notre book sans les guillemets et appuyez sur Entrée.

Du puits des notebook s'ouvrira alors dans votre navigateur par défaut.

Si vous avez déjà un Jupiter Notebook dans votre répertoire, vous pouvez déjà l'ouvrir en appuyant dessus au lieu de recréer un nouveau notebook.

Cliquant ici sur Elo.

Points ip ie.

NB pour l'ouvrir notre Elo point hippy.

Greg.

NB ne contient qu'une ligne de code une commande d'affichage print.

Pour ouvrir un répertoire spécifique sur Mac, ouvrez le répertoire dans le terminal.

Écrivez ensuite du PDA Notebook sans les guillemets et cliquez sur Entrée.

Après un certain temps du Putain Notebook s'ouvrira dans votre navigateur.

Par défaut, vous pourrez voir les fichiers dans ce répertoire.

Dans ce cas, nous avons un autre bout qui s'appelle helo, pw ip ie.

NB ouvrons le en cliquant dessus.

Voici notre hello ip ie.

NB qui ne contient qu'une ligne de commande.

Il s'agit de la fonction print.

Passons maintenant à Ubuntu pour ouvrir GPT.

Un autre book dans un répertoire.

Dossier particulier dans Ubuntu.

Allez dans ce répertoire, faites un clic droit et sélectionnez Open in Terminal.

Tapez Jupiter, un autre book sans les guillemets, et appuyez sur Entrée.

Attendre un peu du PDA Notebook sera lancé dans votre navigateur par défaut.

Vous pouvez créer un nouveau notebook ou ouvrir un notebook existant.

Comme vous pouvez le voir, nous avons déjà un autre book qui s'appelle Hello!

Points i pays grec.

NB.

Ouvrons ce fichier en cliquant dessus.

Et voilà le fichier Elo points IP i quand B contient une simple instruction d'affichage print.

Voilà pour la gestion des répertoires d'un notebook.

Passons maintenant à la suite.

## Régression linéaire simple 

### Introductin 

La régression est une méthode statistique qui prédit une relation entre un résultat continu et la valeur d'une ou plusieurs variables d'entrée.

Elle est utilisée dans de nombreuses disciplines telles que les statistiques, l'économie, la finance,

les industries d'investissement, les data sciences, et cetera.

Parmi les exemples concrets d'analyse de régression, citons la prévision du prix d'une maison en fonction de ses caractéristiques, la prévision des ventes en fonction de paramètres d'entrée, la prévision de la météo, et cetera.

La régression peut être divisée en deux types la régression linéaire et la régression non linéaire.

Dans la régression linéaire, la relation entre les variables d'entrée et la variable de sortie est linéaire.

En d'autres termes, l'équation d'une ligne peut définir la relation entre l'entrée et la sortie.

Maintenant, gardez à l'esprit que la régression linéaire peut être divisée en deux parties.

Première partie la régression linéaire simple et en deux la régression linéaire multiple.

La régression linéaire simple n'implique qu'une seule variable d'entrée et cette unique variable d'entrée

est utilisée pour prédire une sortie, alors que dans la régression linéaire multiple, plus d'une variable d'entrée est impliquée.

Dans le cas de la régression non linéaire, la sortie peut être représentée par une fonction qui est une combinaison non-linéaire des entrées.

### Comment fonctionne la régression linéaire ?

Voyons comment fonctionne la régression linéaire.

Dans le tableau données.

J'ai les prix de chaque maison en fonction de la surface de la maison.

A l'aide de ces données, nous allons construire un modèle d'apprentissage automatique capable de prédire le prix d'un appartement de 330 pieds carrés.

Vous pouvez représenter les prix et les surfaces disponibles dans un diagramme de dispersion.

Sur le graphique, cela se fait avec des points rouges.

Maintenant, nous pouvons dessiner différentes lignes pour essayer d'ajuster ces points rouges.

Nous pouvons dessiner plusieurs lignes.

Elle semble correspondre à notre modèle.

Mais quelle est la ligne la mieux ajustée pour trouver la ligne la mieux ajustée?

Nous procédons comme suit.

Nous calculons ces valeurs.

Que vous voyez à l'écran?

Delta un et Delta deux.

Ces variables représentent l'erreur entre les points rouges et la ligne.

Ensuite, nous élevons au carré les erreurs individuelles et nous les additionnant.

Nous suivons cette procédure pour chaque ligne qui pourrait potentiellement être un bon ajustement pour

nos points de données.

Après avoir effectué ces calculs, nous arrivons à la conclusion suivante la ligne bleue que vous voyez

à l'écran me donne l'erreur minimale.

Donc je choisis cette ligne spécifique pour mon modèle.

L'étape suivante consiste à utiliser cette ligne bleue afin de prédire le prix de n'importe quelle maison

que nous souhaitons.

### Représentation de ligne

Je suppose que vous connaissez déjà l'équation de la ligne I qui est égale à m fois x plus b ou i et

la variable dépendante de la variable indépendante x.

EB et la pente de la ligne est B et l'ordonnée à l'origine.

Voici la représentation de l'équation de la ligne en termes de surface et de prix.

Ou le prix est une variable dépendante et la surface et la variable indépendante parce que nous calculons

le prix en fonction de la surface.

Nous allons trouver les valeurs les mieux adaptées pour MBB.

Ensuite, nous prédisant le prix d'une maison lorsque la surface est donnée en entrée.

### Implémentation en python : Importation de bibliothèques et de jeux de données

Nous allons maintenant écrire un simple code Python pour faire des prédictions sur le prix des maisons.

Importe panda az pd import nem pi az np importe.

Mat.

Plotte.

Lib.

Pi plotte.

AZ bld from.

Est ce qu'à l'heure linéaire tiré du bas modèle import linéaire.

Régression.

Ici, j'ai lancé mon notebook Jupiter et j'ai importé quelques bibliothèques utiles.

Tout d'abord, nous devons apporter les données à notre système.

Nous disposons d'un jeu de données nommé Home Price CSV, qui consiste en un tableau contenant des données

sur la superficie et les prix.

Je vais maintenant charger les données de notre fichier csv dans un data frame ou un cadre de données.

Deux pandas.

Je vais donc taper df égal pd point read.

Tiré du bas csv.

Ouvrez la parenthèse, ouvrez les guillemets home, précise CSV.

Fermez les guillemets.

Fermez la parenthèse.

Puis.

Exécuter la cellule.

Donc pour charger les données de mon fichier csv, j'ai utilisé la fonction PD point read tirée du PPA.

CSV et passé le nom du fichier comme argument.

Maintenant, notre jeu de données est stocké dans DF.

Comme vous pouvez le voir à l'écran.

### Implémentation en python : Distribution des données

La prochaine chose que je vais faire, c'est tracer les points de dispersion de nos données juste pour

avoir une idée de la façon dont les points sont distribués.

Je vais tracer un graphique de la surface en fonction du prix.

Alors je vais écrire PLD point X Label.

Ouvrez la parenthèse.

Ouvrez les guillemets area.

Ouvrez la parenthèse.

Est ce que R espace FT?

Fermez la parenthèse.

Fermez les guillemets.

Fermez la parenthèse.

Puis PLT point i que la belle.

Ouvrez la parenthèse.

Ouvrez les guillemets.

Pris.

Ouvrez la parenthèse US.

D'horreur.

Fermer la parenthèse.

Fermer les guillemets et fermer la.

Puis PLD pw.

Ouvrez la parenthèse.

DF pw area virgule df price virgule color égal.

Ouvrez les guillemets raides.

Fermez les guillemets virgules.

Marqueur égal.

Ouvrez les guillemets plus.

Fermez les guillemets.

Fermez la parenthèse.

Les deux premières lignes de code définissent les étiquettes X et Y du graphique.

Nous les avons nommées étiquettes X et étiquettes X Y, respectivement surface face carré et prix US

de rose.

Dans la troisième ligne, nous avons utilisé la méthode de dispersion qui désigne les points de coordonnées

X et Y sur le graphique.

Dans notre cas, les points sont la surface et le prix.

De plus, nous avons quelques arguments optionnels pour la fonction tels que la couleur ou le marqueur.

La couleur indique quelle couleur nous voulons, que nos points soient imprimés et le marqueur indique

quelle forme ces points doivent avoir.

Ensuite, nous imprimant le graphique et voyons la distribution.

D'après le graphique, j'ai l'impression que la distribution est adaptée à un modèle de régression linéaire.

Les points ne sont pas distribués au hasard.

Les points se déplacent vers le haut et vers la droite.

### Implémentation en python : Créer un objet de régression linéaire

Maintenant je vais aller de l'avant et utiliser le modèle de régression linéaire.

Donc tout d'abord, vous devez créer un objet de régression linéaire.

Je vais écrire.

Reg égal.

Linéaire.

Régression ouvrait la parenthèse.

Fermer la parenthèse.

Depuis la bibliothèque Escala Irene.

Nous avons importé le modèle linéaire.

Je vais créer un objet pour la régression linéaire et ensuite je vais ajuster mes données.

Alors maintenant, j'écris.

Reg Point feat.

Ouvrez la parenthèse.

DF.

Ouvrez le crochet, ouvrez le crochet, ouvrez les guillemets area.

Fermez guillemets, fermez les deux crochets virgules.

DF price.

Fermer la parenthèse lorsque je vais ajuster mes données.

Je veux dire que j'entraîne le modèle de régression linéaire en utilisant les points de données disponibles

dans le premier argument.

J'ai fourni un cadre de données, un data frame qui contient uniquement la zone et ensuite dans le second

argument, nous avons l'axe des i qui est notre prix.

Une fois que j'ai exécuté ce code, notre modèle est prêt à prédire les prix.

Donc faisons une prédiction.

Nous voulons prédire le prix d'une maison dont la surface est de 3300 pieds carrés.

Nous écrivons Wreck Point Predict.

Ouvrez la parenthèse, ouvrez les crochets 3300.

Fermez les crochets, fermez, arpentez.

Exécuter cette cellule et voilà, on obtient une sortie et nous pouvons voir qu'il a prédit le prix

qui est.

628 715,75342.

Ainsi, lorsque j'ai entraîné mon modèle avec l'ensemble des données données, il a calculé les coefficients

et les intercepte.

Voyons donc quelles sont les valeurs de ces coefficients?

Reg point qf tiré du bas indique la valeur du coefficient M.

Et lorsque nous faisons reg point.

Coeff tiré du bas, la valeur du coefficient M est affichée.

Et lorsque nous faisons rec point intercept tiré du bas.

Cela montrera donc la valeur du coefficient B.

En utilisant ces valeurs de coefficient et de Intercept, nous pouvons calculer le prix d'une maison.

Alors je vais écrire 135,788 fois 3300 plus 104 20 616,438.

Exécuter cette cellule et voilà, nous obtenons exactement le même résultat que précédemment.

## Régression linéaire multiple 


### Comprendre la régression linéaire multiple

Vous savez maintenant comment fonctionne la régression linéaire simple et comment l'implémenter en Python.

Maintenant nous allons apprendre la régression linéaire multiple.

Allons y.

Vous pouvez voir la représentation graphique de la régression linéaire simple sur la gauche et de la

régression linéaire multiple sur le côté de droite de votre écran.

La différence est uniquement due au fait que la régression linéaire multiple a plus d'une entrée ou

variable indépendante.

Cela signifie que la sortie dépend de chaque entrée.

Par conséquent, il y aura une corrélation linéaire unique entre chaque entrée et la sortie.

C'est corrélation.

Sont représentés par quatre lignes différentes sur le graphique à droite de l'écran.

L'illustration mathématique de la régression linéaire multiple est i égal a plus b1, b2, x2, plus

b3, x3, plus b4, x4, a et l'ordonnée à l'origine est b1 et la pente de la ligne, qui représente

la relation entre la production et la première variable indépendante B1, indique que si nous augmentons,

la valeur de x un d'une unité B1 nous indique de combien la valeur de la production sera affectée.

Quand à B2, B3 et B4, ils fonctionnent tous de manière similaire.

### . Implémentation en python : exploration du jeu de données

Pour la mise en œuvre de la régression linéaire multiple, nous allons utiliser un fichier CSV contenant

cinq colonnes et 50 lignes.

Dans ces données, nous avons les quatre variables indépendantes appelées RND Span, administration,

marketing, span and state.

Il y a une variable dépendante.

Profite.

Notre tâche ici est d'entraîner un modèle d'apprentissage automatique machine learning avec ces données

afin de comprendre la corrélation entre chacune des quatre variables indépendantes et de prédire un

bénéfice pour une autre nouvelle entreprise lorsque ces quatre variables indépendantes sont fournies.

OK, donc me voilà dans le Jupiter Notebook.

Tout d'abord, comme d'habitude, nous devons importer les bibliothèques requises, importer les bibliothèques.

Import estampille AZ NP.

Il porte Mad Blood, Lib, Point Pie, Plotte, Haze, BLT.

Importe pen dess az pd.

Ensuite nous stockons le jeu de données 50 tirées du bas startup CSV en tant que data frame pendant

dans une variable appelée DataSet en utilisant la fonction PD point read tirée du uid csv.

Je vais donc laisser ici une note sur ce que je fais.

Ensuite je vais écrire le code data set égal pd pwd read tiré du bas.

CSV.

Ouvrez la parenthèse, ouvrez les guillemets.

50 tirées du bas startup point.

CSV.

Fermer les guillemets.

Fermer la parenthèse.

Ensuite, nous utilisons les fonctions îlots pour découper le data frame afin d'attribuer des indices

à X et Y.

Je vais écrire ce qui suit x.

DataSet Ilog.

Ouvrez le crochet deux point.

Virgules 2.1 fermées les crochets, points values.

Puis i égal data.

Sept points il lock.

Ouvrez la parenthèse.

Deux points virgules.

Un fermé le crochet.

Point valise.

Ici, nous utilisons.

Crochets de point virgule 2.1.

Fermé le crochet qui peut être interprété comme inclure toutes les lignes.

Inclure toutes les colonnes jusqu'à un.

Exclure -1.

Dans ces lignes de code, -1 fait référence à la première colonne à partir de la dernière.

Ainsi, nous attribuons la zéroième première, deuxième et troisième colonne comme x.

Nous attribuons la dernière colonne -1 à la variable dépendante qui est i.

Ensuite, nous exprimons le data frame pour voir si nous avons obtenu les colonnes correctes pour nos

données de formation.

Alors j'écris data dataset pw head.

Ouvrez la parenthèse.

Cinq Fermez la bande.

Et voici les valeurs que nous attendions.


### Implémentation en python : codage de données catégorielles

Si les valeurs sont des nombres dans l'ensemble de données, nous pouvons facilement appliquer des calculs

mathématiques sur l'ensemble des données et créer des modèles de prédiction.

Dans cet ensemble de données, nous rencontrons une variable non numérique comme la variable state.

Ces données sont appelées données catégorielles.

Nous devons convertir ces valeurs catégorielles en valeurs numériques d'une manière ou d'une autre.

Nous codons ces données catégorielles en utilisant une autre bibliothèque importante appelée SK Learning.

Laissez moi donc d'abord écrire le code.

Puis je vous expliquerait tout.

From Escala compose Import colonnes transformées.

Froome escalade un point pris.

Processing import, one hot and code.

City égale Colin transformé, ouvrait la parenthèse, Transformers égale, ouvrait le crochet, ouvrait

la parenthèse, ouvrait les guillemets.

Encodeur, fermez les guillemets, virgules.

One hot encoder.

Ouvraient.

Fermer la parenthèse.

Virgules, crochets, trois fermées.

Crochets fermées, porteuses, crochets, virgules, reminder égales.

Ouvrez les guillemets.

Patrie, fermez les guillemets.

Fermez la parenthèse.

X égal mp pw.

Ouvrez la parenthèse ct pw.

Tiret du huit.

Transforme.

Ouvrez la parenthèse X.

Fermez les parenthèses.

Dans ce morceau de code, nous avons emporté le colon transformé.

Et le One Hot Encoder?

Dans notre cas, nous devons utiliser le One Hot Encoder pour transformer notre colonne State indexée

numéro trois en données numériques.

One Hot Encoder est un processus d'encodage ou chaque étiquette est représentée par un tableau d'entiers

plutôt que par un seul entier.

Un autre, vous pouvez voir que nous avons utilisé la classe colonnes transformées.

Cela permet de transformer séparément une colonne particulière du Data Frame.

Le constructeur de colonnes transformé prend un certain nombre d'arguments, mais seuls deux nous intéressent.

Le premier argument est un tableau appelé transformée, qui est une liste de tuples.

Le tableau contient les éléments suivants.

Dans le même ordre, non?

Un nom pour le transformateur de colonne qui facilitera le réglage des paramètres et la recherche du

transformateur.

Ensuite, il y a le transformateur.

Ici, nous sommes censés fournir un estimateur.

Nous pouvons aussi le Patriot, le passer ou le drop.

Laissez tomber si nous voulons.

Mais puisque nous en codons, les données.

Dans cet exemple, nous utilisons le One Hot Encoder.

N'oubliez pas que l'estimateur que vous utilisez ici doit prendre en charge l'ajustement et la transformation.

Donc le feat et le transforme.

Ensuite, il y a les colonnes, la liste des colonnes que nous voulons transformer.

Dans ce cas, nous allons seulement transformer la quatrième colonne.

Le deuxième paramètre qui nous intéresse et le reste.

Il indique au transformateur ce qu'il doit faire avec les autres colonnes de l'ensemble des données.

Par défaut, seules les colonnes qui sont transformées seront retournées par le transformateur.

Toutes les autres seront abandonnées.

Mais nous avons la possibilité d'indiquer au transformateur ce qu'il doit faire avec les autres colonnes.

Nous pouvons soit les laisser tomber.

Les faire passer sans modification.

Ou specifier un autre estimateur si nous voulons faire plus de traitements.

Comme vous pouvez le voir ici, nous avons nommé le transformateur simplement en CO2.

Ensuite, nous avons utilisé le constructeur One Hot Encoder pour fournir une nouvelle instance comme

estimateur et puis nous spécifiant que seule la quatrième colonne doit être transformée.

Nous nous assurons également que les colonnes restantes sont passées sans aucune modification.

Une fois que nous avons construit cet objet, colonne transformée, nous devons ajuster et transformer

l'ensemble des données.

Pour ce faire, nous avons la ligne de code suivante.

Elle prend le jeu de données X et transforme les valeurs de l'attribut state en numérique en utilisant

un encodeur en haute en couleur.

De plus, ce code prend toutes les valeurs du jeu de données X transformées et les convertit en un tableau.

Après l'encodage de notre jeu de données, nous pouvons voir que la quatrième colonne a été transformée

et qu'elle est devenue les trois premières colonnes.

Les valeurs zéro zéro un représentant New-York, les valeurs zéro un zéro la Floride et un zéro zéro

représentent la Californie.

Donc maintenant notre ensemble de données et numériques est prêt à être utilisé.

Incroyable!

Nous sommes maintenant bien équipés pour manipuler notre jeu de données.

Continuons.

### Implémentation en python : fractionnement des données en ensembles de formation
La prochaine tâche importante consiste à diviser notre ensemble de données en un ensemble de formations

d'entraînement et un ensemble de tests.

Nous faisons cela afin d'entraîner notre modèle avec une partie de données appelées ensembles d'entraînement

et de tester les résultats de la prédiction sur l'autre ensemble de données appelées ensembles de tests.

Très bien, faisons ça.

Nous écrivons from esca learning PW modèle tiré du huit Sélection Import train tiré du huit test tiré

du huit bits.

### Implémentation en python : Formation du modèle sur l’ensemble d’entrainement

Dans l'étape suivante, nous devons écrire ce qui suit From Escala un point linéaire modèle.

Importe.

Linéaire régression.

Régresse.

Sort égal, linéaire.

Régression.

Ouvrait fermé la parenthèse.

Régresser hors point fis x tiers du huit trains x grecs serait de huit trains.

Fermer la parenthèse.

Alors qu'est ce qu'on a fait ici?

Nous avons importé la classe linéaire regression que nous allons appliquer à notre ensemble de formation,

notre centre d'entraînement.

Nous avons attribué une variable appelée régression or à la classe linéaire régression.

Nous avons ensuite utilisé la fonction régression feet pour ajuster l'ensemble des données d'apprentissage

X-Trail et Y Training à cette classe linéaire.

Régression pour que le processus d'apprentissage ait lieu.

### Implémentation en python : prédiction des résultats de l’ensemble de tests

Nous allons maintenant prédire les valeurs de profit de l'ensemble de tests en utilisant le modèle formé.

Ressort.

Je vais donc d'abord écrire le code et ensuite l'expliquer.

Nous créons une variable I tirée du huit prod.

Donc on écrit i tiret de huit prod égal ré ressort point predict.

Ou est la parenthèse X tirée du bas test?

Fermer la parenthèse.

Ensuite une autre variable appelée df df égal pd point un data frame.

Ouvrez la parenthèse.

Ouvrez la parenthèse, ouvrez guillemets real value.

Fermez les guillemets.

Deux point y tiret de huit tests virgules.

Ouvrez les guillemets prédictif value.

Fermez les guillemets du point I prades.

Fermer la parenthèse.

Ziggy.

Fermer la parenthèse.

Ensuite nous imprime mon df.

Donc on écrit juste df.

Alors qu'est ce que j'ai fait ici?

J'ai utilisé la fonction Regression Point Predict pour prédire les valeurs de nos données de test X

tirées du huit tests.

Nous attribuons l'étiquette Predictive Value à I Prod.

Nous avons maintenant deux ensembles de données I Test qui sont les valeurs réelles et I Prod qui sont

les valeurs que nous avons prédites.

Ensuite, nous comparons les deux valeurs pour voir comment notre modèle s'est comporté.

Nous avons imprimé les valeurs du test en tant que valeurs réelles et les valeurs de I prod en tant

que valeurs prédites.

De chaque X test dans un data frame.

De cette façon, nous obtenons les valeurs pour l'ensemble des dix points de données X Test.

Nous pouvons voir que nos valeurs prédites sont globalement assez proches des valeurs réelles.

Pour la première valeur, les valeurs réelles sont 65 200.33 et les valeurs prédites sont

69 622.870630.

Nous constatons que le modèle a prédit cette valeur de manière très précise et nous pouvons donc dire

que notre modèle a une bonne précision.

Mais la question qui se pose est la suivante à quel point, à quel point cette précision est elle bonne?

Avons nous une méthode pour la mesurer?

Heureusement, nous en avons une.

Passons maintenant à l'exposé suivant et voyons comment nous pouvons mesurer cette précision.

### Évaluation des performances du modèle de régression
Sur l'écran, vous pouvez voir trois échelles pour mesurer la performance d'un modèle.

La première, c'est l'erreur absolue moyenne.

M a eux comme Mean Absolute Error.

C'est la moyenne de la valeur absolue des erreurs n et le nombre de valeurs I qui est une valeur réelle

et y qui chapeau est une valeur prédite, nous soustrait ion donc une valeur prédite de la valeur réelle

correspondante.

Puis nous prenons sa valeur absolue.

Nous faisons cela pour toutes les paires de valeurs réelles et prédites, et nous les additionnant ensemble

toutes.

Ensuite, nous divisons le tout par.

Cette valeur nous donne une idée précise de l'ampleur de l'erreur ou, en d'autres termes, de la précision

de notre modèle.

De même, nous avons l'erreur quadratique moyenne MS en anglais mince quad error qui est la moyenne

des erreurs quadratique.

Enfin, nous avons l'erreur quadratique moyenne RMS comme brute means quad error.

C'est la racine carrée de la moyenne des erreurs quadratique.

### Erreur quadratique moyenne racine en Python
Nous allons maintenant voir comment mettre en œuvre l'une de ces échelles d'évaluation de modèle en

Python.

Nous allons travailler en utilisant l'erreur quadratique moyenne.

Elle est déjà définie dans le module Escala, un point métrique.

Écrivons donc ce qui suit.

Hashtag RMC.

Root.

M'inscrire.

Error from escalope in import metric.

Print entre parenthèses.

NP.

SQL.

T.

Ou est la parenthèse Matrix pour maintien du bas squad?

Tiré du bas.

Erreur.

Ouvrez la parenthèse I tirée du bas test virgule i tiers du bas prod.

Fermez toutes les parenthèses.

Alors qu'est ce que je viens de faire?

J'ai importé l'échelle d'évaluation du modèle depuis la bibliothèque de l'escalier.

Ici, c'est root mean squared errors.

Elle msieur.

Nous l'emportons et introduisons nos valeurs réelles et prédites comme argument.

Voilà donc comment on peut mesurer l'erreur d'un modèle.

Felicitation.

Nous avons terminé la partie sur la régression avant de passer à la session suivante.

Laissez moi vous poser une question.

Laquelle des mesures d'évaluation suivantes peut être utilisée pour évaluer un modèle tout en modélisant

une variable de sortie continue?

La solution est d erreur quadratique moyenne.

Mince, quelle erreur puisque la régression linéaire donne la sortie sous forme de valeur continue.

Nous utilisons dans ce cas la métrique de l'erreur quadratique moyenne pour évaluer la performance du

modèle.

Les autres options sont utilisées pour traiter les problèmes de classification.

Nous aborderons la classification dans la section suivante.

## Algorithmes de classification : K-Plus proches voisins 
### Introduction à la classification
Alors qu'est ce que la classification?

La classification en machine learning et en statistique est une approche d'apprentissage supervisé dans

laquelle le programme informatique apprend à partir des données qui lui sont fournies et fait de nouvelles

prédictions ou classifications.

Voici quelques applications comme le filtrage d'email, la reconnaissance de la parole et de l'écriture

biométrie.

Reconnaissance des empreintes digitales, et cetera.

Par exemple, dans le système de reconnaissance d'empreintes digitales, le système reconnaîtra l'empreinte

digitale d'une personne spécifique, car il est formé par différentes empreintes digitales de différentes

personnes.

Ainsi, à l'aide de la classification, le système identifiera la classe d'empreintes digitales à laquelle

une personne spécifique appartient.

Les algorithmes de classification sont les suivants.

Réseaux neuronaux.

Régression et cas plus proches voisins.

### Algorithme K-Plus proches voisins (KNN)
Le cas plus proche voisin est une technique d'apprentissage supervisé qui mesure la similarité entre

deux classes.

Comme nous pouvons le voir dans la figure, nous avons deux catégories A et B et un nouveau point de

données qui est en couleur bleue.

La classification kn k ni reasonable cat plus proche voisin en anglais, va lui attribuer une catégorie

sur la base de la similarité.

Il affectera le nouveau point de donnée à la catégorie pour laquelle le nombre de voisins est la plus

élevée.

Il est donc affecté à la catégorie A.

Dans ce cas.

Voici une formule pour calculer la distance euclidienne, la distance euclidienne et la distance entre

deux points.

En calculant la distance euclidienne, on obtient le plus proche voisin.

### Exemple de KNN:
Laissez moi maintenant vous expliquer ce que sont les cas plus proches voisins à l'aide d'un exemple

simple.

Supposons que nous ayons une image d'entrée qui pourrait être soit un chien, soit un chat.

Nous ne savons pas vraiment.

Ainsi, pour l'identification de cette image d'entrée, nous utiliserons l'algorithme K plus proche

voisin KN.

L'approche KN nous aidera à classer l'image d'entrée car elle fonctionne sur des mesures de similarité.

KN va faire correspondre des caractéristiques similaires et sur la base de ces caractéristiques, il

va prédire si l'image est similaire à un chien ou similaire à un chat.

Dans cet exemple, l'image d'entrée ressemble plus à un chat qu'à un chien.

### K-Nearest Neighbours (KNN) en utilisant python

Pour réaliser KN et non Python, nous utiliserons un jeu de données appelé User Data CSV.

Il est joint au matériel de secours.

Voyons quelles informations contient cet ensemble de données.

Data set égal PD point read tiré du bas csv.

Ouvrez la parenthèse, ouvrez les guillemets users data pw, csv.

Fermez les guillemets, fermez la parenthèse.

DataSet pour le faire afficher.

Lançons cette cellule.

L'ensemble de données contient beaucoup d'informations.

Le salaire estimé et l'âge sont des variables que nous allons considérer comme des variables indépendantes.

Et la variable purchase.

Donc achat.

Et pour la variable dépendante?

Les étapes que nous allons réaliser pendant le codage sont les suivantes.

Prétraitement adaptation de KN à l'ensemble d'apprentissage.

Prédiction du résultat du test puis test de la précision des résultats dans les projets en cours.

Nous réalisons ces étapes une par une en Python.

### Implémentation en python : importation des bibliothèques requises
Tout d'abord, nous allons emporter les bibliothèques requises en écrivant ce qui suit.

En commentaire, on écrit Hashtag importé in the Library pour importation des bibliothèques Import Neamt

az m.p.

Im port man.

Pilote lib point by pilote as plt.

Import Panda, A Spiders From Escalante, Metric Import Confusion.

Tiré du huit Matrix.

### Implémentation en python : importation du jeu de données

Ensuite, nous allons importer le jeu de données, le data set dans notre système et mettre les variables

indépendantes dans X et les dépendantes.

Dans le GAC, nous écrivons donc ce qui suit en commentaire.

Import Thin the data cette importation de l'ensemble des données.

Data set égal PD point read tirée du huit csv.

Ouvrez la parenthèse, ouvrez les guillemets users data points csv.

Fermez les guillemets.

Fermez la parenthèse X égal data set pour i lock.

Ouvrez le crochet deux points virgules, deux 2.4 fermés.

Le crochet valide us i égal.

DataSet I Ilog ouvrez les crochets deux point virgule quatre.

Fermez le crochet.

Points values.

Print.

Ouvrez la parenthèse X, fermez la parenthèse.

Print.

Ouvrez la parenthèse i fermez la parenthèse.

Faisons fonctionner cette cellule et voilà.

Vous pouvez voir qu'en utilisant la fonction il lock, les valeurs de l'index de la colonne 2 à 3 sont

placées dans la variable X.

De même, l'indice de colonne quatre de l'ensemble de données est attribué à la variable I.

### Implémentation en python : fractionnement des données en ensembles de formation

Dans l'étape suivante, nous allons diviser notre ensemble de données en deux catégories tests et formations

et définir le pour centage de nos données que nous voulons utiliser comme données de formation ou de

test.

Alors je vais écrire Training and testing de data.

Ici, je vais diviser les données en deux parties.

Froome escalade.

Un point modèle qui est du huit sélections import train tiré du huit test tiré du huit splits X Train

X Test I train i test.

Égal train tiré du huit.

Test tiret du huit.

Split ouvrez la parenthèse x virgule i virgule.

Test tiers du huit size égale 0,25 virgule.

Random State égal zéro.

Fermé la parenthèse.

Dans ce code, nous avons utilisé 0,25 ou 25 % des données comme données de test et le reste pour l'ensemble

des données d'entraînement.

Ensuite, nous allons importer une méthode de mise à l'échelle appelée mise à l'échelle standard depuis

SQL.

Un point pris processing.

Alors j'écris from escalade prix processing import standard.

Scanner.

SC tiré du huit x égal standard scalaire ouvrait fermé la parenthèse.

X trains égale sc tirée du huit x point feet.

Tiré du huit Transform.

Ouvrez la parenthèse X tiré du huit.

Train X tiré du huit.

Test égal sc tirette huit x points.

Fuite du huit Transform.

Ouvrez la parenthèse X tirée du huit test.

Fermez la parenthèse.

Nous mettons nos données à l'échelle en Python pour normaliser les données dans une plage spécifique.

Il est utile de mettre à l'échelle les attributs d'entrée pour un modèle qui repose sur la magnitude

des valeurs.

Nous avons utilisé ici la méthode PHI pour mettre nos données à l'échelle.

Ce qu'il fait, c'est qu'il prend un ensemble de données à mettre à l'échelle comme entrées et il retourne

les données mises à l'échelle.

Ces données sont à nouveau enregistrées dans les mêmes variables X-Trail X test.

Dans notre cas.

### Implémentation en python : mise à l’échelle des fonctionnalités

En exécutant le code ci dessus.

Notre jeu de données est importé dans notre programme et bien pré traité.

Après la mise à l'échelle des caractéristiques, notre jeu de données de test ressemblera à ceci.

Maintenant que nos données sont mises à l'échelle, nous pouvons adapter le classifieur KN à l'ensemble

d'apprentissage.

### Implémentation en python : Importation du classificateur KNN
Ici, nous devons adapter le classifieur KN aux données d'entraînement.

Donc nous écrivons from escalade neighbourhood import cat neighbourhood classifier.

Classifieur égal K.

Neil B.

Classifieur.

N tiré du huit.

Neighbors égale cinq.

Régule métrique égalent.

Ou est les guillemets Minkowski fermaient les guillemets virgules p égales.

Deux.

Fermé la parenthèse classifieur.

Point.

Fitte ouvrait la parenthèse x tiret de8 train.

Virgules.

I tiret de8 train.

Fermer la parenthèse.

Alors, qu'est ce que je viens de faire ici?

Tout d'abord, j'ai emporté la classe dix FEN carnets B, classifieur de la bibliothèque Escale Nabeul.

Après avoir emporté la classe, nous avons créé l'objet classifié de la classe.

Le paramètre de cette classe sera n tiers du huit nimber.

Il définira le nombre de voisins requis par l'algorithme.

Habituellement, il en faut cinq métrique égales ou nb Minkowski.

C'est le paramètre par défaut et il établit la distance entre les points p à deux.

C'est donc que la métrique est équivalente à la métrique euclidienne standard.

Nous allons ensuite adapter le classifieur à notre ensemble de données d'entraînement.

L'ajustement d'un classifieur à un ensemble de données signifie que le classifieur s'entraîne et prédit

la sortie sur la base des données d'entraînement.

### Implémentation en python : Prédiction des résultats & Matrice de confusion

Ici.

Nous précisons d'abord les résultats pour les données X Test nous assignant les valeurs à I Prod.

Maintenant nous avons les valeurs prédites par le classifieur et les valeurs réelles également.

Si nous voulons comparer les deux valeurs et mesurer la précision de notre modèle, nous avons besoin

d'une méthode, l'une des métriques utilisées pour la comparaison et la matrice de confusion.

Une matrice de confusion est également connue sous le nom de matrice d'erreur.

Il s'agit d'un résumé des résultats de prédiction d'un problème de classification.

La matrice que vous voyez sur votre écran est une matrice de confusion, ce qui nous indique que 64

valeurs vraies sont correctement prédites.

Vrai, trois valeurs fausses sont incorrectement prédites.

Vraies.

Quatre valeurs vraies sont incorrectement prédites comme fausses.

29 valeurs fausses sont correctement prédites.

Fausses.

Le résultat montre qu'il y a 64 plus 29 égalent 93 prédictions correctes et trois plus quatre égalent

cette prédiction incorrecte.
## Algorithmes de classification : Arbre de décision 
### Introduction aux arbres de décision
Notre prochain sujet est l'arbre de décision.

Alors, qu'est ce que la technique de l'arbre de décision?

Il s'agit d'une technique d'apprentissage automatique supervisé dans laquelle les données sont divisées

en continu en fonction de paramètres.

Elle décompose un ensemble de données en sous ensembles de plus en plus petits.

Le résultat final est un arbre avec des nœuds de décision et des nœuds feuilles.

Un nœud de décision par exemple l'âge.

Le cholestérol.

À deux branches ou plus.

Le nœud feuille, par exemple âge moyen, représente une classification ou une décision.

L'algorithme d'apprentissage de l'arbre de décision et le suivant.

Il choisit d'abord une caractéristique dans un ensemble de données.

Il détermine ensuite l'importance de la caractéristique dans la segmentation des données, et la segmentation

des données dépendra de la meilleure caractéristique.

Après cela, nous répétons les étapes ci dessus.

Tous ces processus utilisent une sorte de critères et de mesure pour prendre des décisions.

L'un de ces critères est l'entropie.

Voyant ce que signifie l'entropie dans le prochain cours.
### Qu’est-ce que l’entropie ?

Alors qu'est ce que l'entropie, l'entropie et la mesure de la quantité d'incertitude ou d'aléatoire

dans les données?

Intuitivement, elle nous renseigne sur la prévisibilité d'un certain événement.

Par exemple, prenons l'exemple d'un lancer de pièce de monnaie dont la probabilité de pile et zéro

cinq et de phase zéro cinq.

Dans ce cas, l'entropie est la plus élevée possible car il n'y a aucun moyen de déterminer le résultat.

Sinon, considérez une pièce de monnaie qui a des têtes des deux côtés.

L'entropie d'un tel événement peut être prédit parfaitement puisque nous savons à l'avance que ce sera

toujours des têtes.

En d'autres termes, cet événement n'a rien d'aléatoire.

Par conséquent, notre entropie est nulle.

En particulier, les valeurs les plus faibles impliquent une incertitude moindre, tandis que les valeurs

les plus élevées indiquent une incertitude élevée.

Ainsi, en choisissant le paramètre pour chaque nœud d'un arbre, l'arbre de décision mesure cette valeur

et choisit celle qui a une grande certitude.

### Exploration de l’ensemble de données
Le jeu de données que nous allons utiliser pour l'implémentation en Python est le suivant ici, nous

voulons prédire si le salaire d'une personne est supérieur à 100 000 $ en fonction de l'entreprise,

de l'intitulé de son poste et de son diplôme.

Maintenant, lorsque vous regardez l'ensemble des données et que vous les donnez un être humain pour

résoudre ce problème, cet être humain essaye naturellement de construire un arbre de décision dans

son cerveau.

### Arborescence des décisions

Nous allons maintenant construire un algorithme d'arbre de décision en Python pour l'ensemble de données

donné.

Notre arbre aura la structure suivante les nœuds qui représentent les paramètres.

Ils seront connectés les uns aux autres et pour chaque combinaison, nous devrions avoir une réponse

finale, oui ou non.

Voici à quoi ressemblerait notre arbre de décision jusqu'à la deuxième profondeur.

Par deuxième profondeur, je veux dire qu'il y a deux couches de nœuds.

La première couche n'a qu'un seul nœud et ce nœud représente la société, ce qui signifie que notre

arbre est ramifié en fonction des entreprises.

Ainsi, la couche suivante de nœuds représente différentes entreprises telles que Google, Facebook,

ABC Pharma.

Et nous n'avons pas d'autres nœuds.

Ainsi, cet arbre a deux profondeurs d'après notre ensemble de données.

Notre arbre de décision nous indique que si une personne travaille chez Facebook, alors oui, elle

aura un salaire supérieur à 100 000 $, quel que soit son diplôme ou son poste.

### Implémentation en python : Importation de bibliothèques et de jeux de données

Pour implémenter en Python.

Comme d'habitude, nous allons d'abord importer les bibliothèques et les classes nécessaires.

La classe qui est nouvelle ici par rapport à l'exemple précédent et la classe décision tri classifieur

de la bibliothèque Escalante Tri.

Nous allons voir comment l'utiliser afin d'implémenter notre arbre de décision en python.

Encore une fois, comme précédemment, nous devons d'abord amener l'ensemble de données dans notre système.

Dans la première ligne, nous avons créé une liste de noms de colonnes à partir de nos données.

Ensuite, nous lisons le jeu de données avec les noms de colonnes correspondant à la liste ci dessus.

### Implémentation en python : codage de données catégorielles

Ensuite, nous suivons la procédure habituelle et nous divisons les variables indépendantes en X et

les variables dépendantes en Y.

A ce stade, nous savons tous que les algorithmes de machine learning fonctionnent sur des nombres et

non sur des étiquettes.

Donc nous allons convertir nos colonnes qui ont des étiquettes en nombre.

Pour cela, nous allons utiliser l'encodeur d'étiquettes.

Donc à partir de Escala ean, j'ai importé pri processing.

Ensuite, j'ai créé un objet de la classe Label Encodeur à partir de pré processing.

Ensuite, j'ai appelé la fonction feed transform de la classe label encodeur.

Sur la colonne compagnie.

Cette ligne de code prend les entrées d'étiquettes de la colonne Company et code ces valeurs en nombres,

puis les réaffecter à la même colonne.

De cette façon, toutes les valeurs d'étiquette de la colonne Company de nos données sont converties

en numérique.

Vous pouvez faire de même pour les colonnes job ou de gris dans les données.

Ensuite, pour voir à quoi ressemblent nos données, nous imprimant quelques lignes de nos données en

utilisant la fonction HEAD.

Par défaut, la fonction Head est utilisée pour obtenir les cinq premières lignes.

Vous ferez de même pour la colonne salary mort dans son cas.

Je vais donc devoir écrire en commentaire.

Split the dataset in features and tag ID.

Variables.

Donc on sépare un ensemble de données en caractéristiques et variables.

Cibles puis feature tirées du huit calls égales.

Ouvrez les crochets, ouvrez les guillemets company.

Fermez les guillemets virgules.

Ouvrez les guillemets job.

Fermez les guillemets virgules.

Ouvrez les guillemets de gris.

Fermez les guillemets.

Fermez les crochets.

X égal data.

Ouvrez les crochets.

Features.

Tiré du huit college fermé.

Les crochets y égalent data.

Ouvrez crochets, ouvrez les guillemets.

Sillery.

Tirets du huit morts, tirets 20 tirets son CA.

Fermez les guillemets, fermez le crochet.

On écrit un commentaire x égal data pwa.

Valent EWS ou crochet un deux point virgule 2.3.

Faire un crochet i égal data point value.

Ouvrez le crochet un deux point virgule trois.

Fermez le crochet.

One means we are not using the head.

Donc un signifie que nous n'utilisons pas l'en tête.

Puis on écrit Prints X.

Puis Print I et nous lançons la cellule et voilà.

Voici à quoi ressemblent nos variables X et Y.

### Implémentation en python : fractionnement des données en ensembles de formation

De même, pour former et tester notre modèle, nous devons diviser les données en X trains, x test

I trains et Y test.

C'est ce que nous devons faire ici.

Alors je vais écrire X.

Tirets, trains, virgules.

X tirets, test virgules.

I ti trane virgule i tiré test égal.

Train tiré test.

Tiret split.

Ouvrez la parenthèse x virgule y huit.

Test size.

Egale 0.2 virgule random tiret state.

Égal sans fermer la parenthèse et nous lançons cette cellule.

### Implémentation en python: prédiction et précision des résultats

Nous sommes maintenant prêts à entraîner notre classificateur.

Nous utilisons la classe Decision Tree Classifieur pour créer un arbre de décision.

Allons voir comment on peut faire ça en python.

Donc d'abord on crée un décision.

Trie classifier.

Donc un classificateur arbre de décision en utilisant l'entropie.

Alors j'écris.

Hashtag Create Decision tree classifier object using entropie.

Créer un objet classificateur arbre de décision utilisant l'entropie.

CLF.

Tiret entropie égale décision.

Tris Classifieur ouvrait la parenthèse Criterion.

Égal ouvrait les guillemets.

Entropie fermée les guillemets virgule max.

Tiret.

Deb égale trois.

Fermer la parenthèse.

Ensuite, nous entraînons le classificateur à arbre de décision.

Alors j'écris.

Trane Decision trie classifier.

Si LF tirait entropie égale CLF, entropie d'un filtre ouvrait la parenthèse X tiré du bas.

Très vieille gul i tiret très fermé la parenthèse.

Ensuite, nous devons prédire la réponse pour l'ensemble de données test.

Mais avant ça, laissez moi vous expliquer ce que je viens de faire.

La classe décision tri classifier prend deux arguments.

Le premier argument est le critère qu'il va utiliser pour créer un arbre de décision.

Et ce critère, et dans notre cas, l'entropie.

Le deuxième argument est le nombre de profondeur maximale que notre arbre aura.

Dans notre cas, nous l'avons spécifié comme étant trois.

Maintenant que le modèle de notre arbre décisionnel est construit, nous devons l'adapter à nos données.

Nous le faisons avec la fonction d'ajustement, comme pour nos modèles précédents.

Après cette opération, le modèle est prêt à prédire et à évaluer.

Alors j'écris predict the response for test.

DataSet.

Prédire la réponse pour l'ensemble des données de test.

I pride égale clf tiret entropie.

Predict.

Ouvrez la parenthèse X tiret test.

Fermez la parenthèse.

Ensuite print ouvrez la parenthèse, ouvrez les guillemets accuracy.

Deux points fermez les guillemets virgules.

Metric pw accuracy tiret score.

Ouvrez la parenthèse i tiret test virgules.

I tiret près.

Fermer les parenthèses.

Comme vous pouvez le voir.

La précision de notre modèle n'est que de 75 %.

Super.


## Algorithmes de classification : régression logistique 

### Introduction
Dans cette section, nous allons aborder un autre algorithme de classification, à savoir la régression

logistique.

Nous allons voir qu'est ce que la régression logistique?

Et de son implémentation en Python.

Dans ce cours, nous allons discuter de ce qu'est la régression logistique.

La régression logistique est utilisée pour prédire la probabilité d'une classe ou d'une occurrence spécifique.

Voici quelques conditions pour utiliser la régression logistique.

Un.

Si l'information est binaire.

Deux.

Si vous avez besoin de résultats probabilistes.

Trois.

Lorsqu'une limite de décision linéaire est nécessaire.

Donc ce sont les conditions.

Il existe donc de nombreuses applications de la régression logistique.

Par exemple, il est utilisé pour la prévision de survie chez les patients blessés dans le corps médical.

L'estimation de la probabilité qu'une personne subisse une crise cardiaque.

La prévision de la probabilité d'échec d'une procédure ou d'un produit.

La prédiction de la possibilité pour un propriétaire d'être en défaut de paiement auprès d'un prêteur.

Dans le prochain cours, nous verrons comment fonctionne la régression logistique en mettant en œuvre

l'algorithme sur un ensemble de données

### Étapes de mise en œuvre

Les documents ci joint contiennent un jeu de données qui contient les informations de divers utilisateurs

obtenues à partir de sites de réseaux sociaux.

L'ensemble de données est présenté dans l'image suivante.

Dans ce problème, nous allons prédire la variable achetée variable dépendante en utilisant l'âge et

le salaire variables indépendantes.

Nous allons suivre les mêmes étapes que pour le cas nn.

Elles sont prétraitement, ajustement de la régression logistique à l'ensemble d'apprentissage, prédiction

du résultat du test test de la précision des résultats.

Dans les prochaines diapositives.

Nous allons réaliser ces étapes une par une en python.

### Implémentation en python : Importation de bibliothèques et de jeux de données

Donc nous allons apporter des bibliothèques importantes.

Je vais écrire Importer in the library comme commentaire.

On emporte les bibliothèques imports.

Numbi as NP.

Import Mad plate libre Pipelette a splitté.

Import Panda à PD.

From S, Calonne, Metrix, Import Confusion, Matrix.

Et nous lançons cette cellule.

Nous importons ensuite l'ensemble des données en écrivant ce qui suit.

Je garde d'abord une petite note de ce que je fais imports things de data set data set égal pd pw rid

tiret csv.

Ouvrez la parenthèse, ouvrez les guillemets users data pw, csv.

Fermer les guillemets, fermer la parenthèse.

Ensuite, nous allons extraire les variables indépendantes et dépendantes.

Alors j'écris x égal data sept pw.

Il lock.

Ouvrez le crochet deux point virgule, ouvrez le crochet 2,4.

Fermez les crochets.

Points value i égale data sept points i lock.

Ouvrez les crochets deux point virgule quatre.

Fermez les crochets pw varius.

Dans l'étape suivante, nous allons diviser notre ensemble de données en données de test et en données

d'entraînement.

Nous allons également spécifier le pour centage de nos données que nous voulons utiliser comme données

de formation ou de test.

### Implémentation en python : fractionnement des données en ensembles de formation

Donc pour diviser mes données, je dois écrire ce qu'il suit.

Training and testing data.

Donc données d'entrainement et de tests comme commentaire divers de data in insu.

Tout part.

On divise les données entre deux parties.

From escalier un point modèle tiret selection import string tiret test tirets.

Split X tirets trains virgules x tirets test virgules.

Y tirets trains virgules.

I tiret test.

Égal train tiré.

Test tiret split.

Ouvrez la parenthèse x y virgule test tiret size égal 0.25 virgule random tiret state egale zéro.

Fermez la parenthèse et nous lançons cette cellule.

Alors, qu'est ce que je viens de faire?

J'ai d'abord importé la méthode de division de la formation et du test à partir de Escala, un point

modèle sélection.

Puis j'ai divisé mes données en ensembles de formation et ensembles de tests.

Dans ce code, nous avons utilisé 0.25 ou 25 % des données comme données test et le reste pour l'ensemble

des données d'entraînement.

### Implémentation en python : Pre-processing

Maintenant, nous allons effectuer un prétraitement sur notre ensemble de données.

Nous allons pré traiter les données afin de pouvoir les utiliser efficacement dans notre code.

Alors pour ce faire, je vais écrire from SQL.

Un point pris.

Processing import standards Scala.

SC.

Tiret x égal standard.

Scala ouvré fermé la parenthèse X.

Tiret train égale sc.

Tiret x fuite tiret transformes x tiret train fermé parenthèses x tiret test sc tiret x fuite tiret

transforme ouvrait la parenthèse x tiret test et on lance cette cellule.

Alors qu'est ce qu'on a fait?

Nous avons importé la bibliothèque SK Learning pour notre algorithme et nous avons mis à l'échelle les

caractéristiques des données dans une plage spécifique.

Par la mise à l'échelle.

Nous essayons de ramener toute la variété des plages de valeur, des caractéristiques à une plage spécifique,

afin que notre algorithme comprenne dans quelle mesure un attribut affecte le modèle et obtienne de

meilleures performances en exécutant le code ci dessus.

Notre jeu de données est prêt à être utilisé par le classificateurs après la mise à l'échelle des caractéristiques,

notre jeu de données de test ressemblera à ceci.

Maintenant, nos données sont mises à l'échelle et nous sommes prêts à partir.

Nous pouvons voir que les données sont mises à l'échelle dans la plage de 2 à 2.

Par mise à l'échelle, on entend que nous ramenons nos valeurs de données dans une plage spécifique.

Dans notre cas, nous avons mis à l'échelle nos valeurs de données dans la plage -2 à 2.

### Implémentation en python : Formation du modèle

Nous avons bien préparé notre jeu de données et maintenant nous allons entraîner le jeu de données en

utilisant le jeu d'entraînement pour fournir l'entraînement ou l'ajustement du modèle à l'ensemble d'entraînement.

Nous allons importer la classe logistique régression de la bibliothèque, escalade.

Alors j'écris from escalier, un point linéaire modèle import logistics regression.

Après avoir remporté la classe, nous allons créer un objet classificateur et l'utiliser pour ajuster

le modèle à la régression logistique.

Alors je vais écrire classifieur égal, logistique regression.

Ouvrez la parenthèse random tiret state égal à zéro.

Fermez la parenthèse ici notre classificateur.

Apprends les paramètres pour fixer les données et trouver un modèle.

Après avoir formé le classificateur sur nos données de formation, nous verrons dans les prochains cours

comment utiliser le classificateur pour prédire le résultat de nos données tests.

### Implémentation en python : Prédiction des résultats & Matrice de confusion

Pour prédire les résultats.

Nous allons créer un vecteur I propre, puis créer une matrice de confusion à partir de la bibliothèque

sk1.

Alors j'écris i tiret pride égal classifieur pour predict.

Ouvrez la parenthèse X tirets test.

Fermez la parenthèse.

Je dis ici que je fais.

Making the confusion.

Matrix.

Donc je fais la matrice de confusion.

Puis je continue avec le code C.M..

Égale confusion.

Tiret matrix.

Ouvrez la parenthèse i qui reprennent virgules.

I tiret test.

Fermer la parenthèse print ouvre.

Parenthèse c m fermer la parenthèse ou long cette cellule.

Et voilà, vous pouvez voir la matrice de confusion.

La matrice de confusion est une matrice utilisée pour montrer le nombre de valeurs prédites et le nombre

de valeurs réelles.

Nous l'utilisons pour montrer la précision de notre modèle en comparant le nombre total de valeurs prédites

aux valeurs réelles correspondantes.

Les résultats montrent qu'il y a 68 plus 32 à 100 prédictions correctes et zéro prédiction incorrectes.

Ceci est la précision de notre classificateur.

Sur 100 prédictions, 100 sont des prédictions correctes et zéro des prédictions erronées.

Nous pouvons utiliser la matrice de confusion pour voir les prédictions correctes et incorrectes.

Nous pouvons créer une jolie carte thermique de notre matrice de confusion en utilisant la bibliothèque

cyborg.

Pour ce faire, je dois écrire ce qui suit.

SNS.

PW.

Hit.

Mat.

Égal.

C.M..

Nous lançons cette cellule et voilà.

Vous pouvez voir la carte de chaleur dans le prochain cours.

Nous allons comparer la régression logistique à la régression linéaire.

Même si elles semblent similaires, elles sont très différentes.

Nous verrons ensuite quelles sont les similitudes et les différences entre l'utilisation de ces types

de régression.

### Régression logistique vs Régression linéaire

Donc quand nous avons affaire à une régression logistique, nous estimons les valeurs des variables

catégorielles.

Cependant, lorsqu'il s'agit de régression linéaire, notre objectif est d'estimer le résultat de variables

continues.

Ainsi, pour résumer, l'estimation des variables catégorielles se fait par régression logistique,

tandis que l'estimation des variables continues se fait par régression linéaire.

Donc ensuite, dans la régression logistique, nous découvrons la courbe en S qui donne la limite de

la catégorisation.

Par exemple, si notre valeur prédite est au dessus de la courbe en S, nous la mettons dans une catégorie

et si elle est en dessous, nous mettons le point de données dans l'autre catégorie.

OK.

Nous découvrons donc la courbe en S dans la régression logistique et l'utilisons pour catégoriser les

échantillons.

Nous utilisons la fonction sigmoïde pour trouver la courbe en S.

Cependant, dans régression linéaire, nous recherchons la ligne de meilleur ajustement qui nous permet

de prédire le résultat avec facilité.

Dans la régression logistique, il n'est pas nécessaire d'avoir un lien linéaire entre les variables

dépendantes et indépendantes.

Mais dans la régression linéaire, il est nécessaire que le lien entre les variables dépendantes et

indépendantes soit linéaire.

Enfin, pour la régression logistique, il ne doit pas y avoir de colinéaire entre les variables indépendantes,

alors que pour la régression linéaire, il existe une possibilité de colinéaire entre les vecteurs indépendants.

Une similitude entre les deux et qu'ils peuvent tous deux être utilisés pour la régression, tandis

que la régression logistique peut également être utilisée pour la classification.

Comme nous l'avons vu dans cette section.

C'est tout pour cette section.

J'espère qu'elle vous a plu et que vous avez appris les principales différences entre régression logistique

et régression linéaire.

Et maintenant, passons à la prochaine conférence.

Voici une petite question avant de passer à la section suivante.

A votre avis, la régression logistique est elle principalement utilisée pour la régression?

La réponse est fausse car la régression logistique est un algorithme de classification.

Ne vous méprenez pas.

Simplement parce que le mot régression est figure.

## Clustering 

### Introduction au clustering

Notre prochain sujet est le clustering.

Alors, qu'est ce que le clustering?

Le clustering consiste à regrouper un ensemble d'objets de manière à ce que les objets du même groupe

forment un cluster.

Il s'agit d'une technique d'apprentissage non supervisée.

Comme nous pouvons le voir dans le diagramme, les points colorés arbitraires sont séparés en classes

par le clustering.

Voici quelques applications du clustering.

Elles incluent la reconnaissance des formes, l'analyse des données spatiales, le traitement des images,

la classification de documents.

Trouver un modèle de comportement météorologique et ainsi de suite.

### Cas d’utilisation

Dans cette conférence, nous allons voir pourquoi nous avons besoin de clustering.

Et nous allons voir les tâches pour lesquelles nous pouvons utiliser le clustering.

Comme vous le savez déjà, le clustering est utilisé pour séparer les données disponibles de manière

aléatoire en groupes de données similaires.

Nous pouvons utiliser le clustering pour les techniques suivantes.

L'analyse des données issues de la recherche.

Créer un résumé.

Détecter le bruit.

Détecter les doublons et ainsi de suite.

Toutes ces tâches peuvent être réalisées efficacement en utilisant le clustering.

Dans les prochains cours, nous allons discuter des algorithmes de clustering qui sont les suivants.

Regroupement.

Cas moyen Camille.

Le regroupement hiérarchique.

Le regroupement basé sur la densité.

### Algorithme de clustering K-Means

Le Camino Clustering est un algorithme d'apprentissage non supervisé qui regroupe l'ensemble de données

non étiquetées en différents clusters.

Il s'agit d'un algorithme itératif qui divise l'ensemble de données non étiquetées en quatre groupes

de manière à ce que chaque ensemble de données n'appartiennent qu'à un seul groupe.

Ayant des propriétés similaires.

La lettre K définit le nombre de clusters prédéfinis qui doivent être créés dans le processus.

Il nous permet de regrouper les données en différents groupes et de manière pratique.

Cela lui permettra d'avoir les catégories de groupes dans l'ensemble de données non étiquetées par lui

même et sans avoir besoin d'entraînement.

Comme nous pouvons le voir dans l'image, les données sont classées dans des groupes similaires.

Les étapes du CA clustering sont les suivantes.

Un premier regroupement de partitions.

En second, sans aucune structure en termes de clusters.

Les campings divisent les données en régions ou groupes qui ne se chevauchent pas.

Et en troisième au sein d'un cluster.

Les exemples sont très similaires.

Enfin, nous constatons que les différents clusters ont des exemples très différents.

### Méthode du coude

Alors comment déterminer la valeur optimale de CA?

Tout d'abord, nous devons garder à l'esprit que la performance de l'algorithme de clustering Kaminsky

dépend des clusters hautement efficaces qui le forment.

Par conséquent, le choix du nombre optimal de clusters est une tâche critique importante.

Il existe différentes façons de trouver le nombre optimal de clusters, mais nous discutons ici de la

méthode la plus appropriée pour trouver le nombre de clusters ou la valeur de K.

La méthode donnée ci dessous et la méthode du coude.

La méthode du coude est l'une des méthodes les plus populaires pour trouver le nombre optimal de clusters.

Comme vous pouvez le voir dans la formule ci dessous, nous avons la somme des distances entre chaque

point de donnée et son centre UID au carré et tout cela dans le cluster un.

Puis nous y ajoutons la somme des distances entre chaque point de donnée et son centre ID au carré et

tout cela dans le cluster deux.

Et il en va de même pour le troisième terme.

C'est la somme des distances au carré dans le groupe trois.

Maintenant, pour mesurer la distance entre les points de données et le Centre ID, nous pouvons utiliser

n'importe quelle méthode telle que la distance euclidienne ou la distance de Manhattan.

### Étapes de la méthode du coude
Pour trouver le nombre optimal de clusters.

En utilisant la méthode du coude, nous suivons les étapes mentionnées à l'écran.

Étant donné que le graphique présente une courbure prononcée qui ressemble à un coude.

Cette méthode est connue sous le nom de méthode du coude.

Le graphique de la méthode du coude ressemble à l'image ci dessous.

Les étapes de la méthode du coude sont les suivantes.

Il exécute le clustering Kaminsky sur un jeu de données donné pour différentes valeurs de cas.

Elles vont de 1 à 10 pour chaque valeur de K.

Il calcule la valeur w css.

Il trace ensuite une courbe qui nous montre comment les valeurs w css calculées varient avec le nombre

de clusters.

Le point net de la courbure ressemble à un coude et ce point est considéré comme la meilleure valeur

de K.

Ensuite, nous allons voir le code pour le tracé du coude et toutes les étapes mises en œuvre.

### Implémentation en python

Tout d'abord, nous allons récupérer l'algorithme Kam Means dans la bibliothèque de S.

Galerne.

Alors j'écris.

Finding the optimal number of clusters using elbow.

Méthode en commentaire.

From Escalona cluster import k means.

Ensuite nous allons initialiser la liste pour les valeurs de w css.

Je vais donc devoir écrire W.

CSS tirer list égal.

Ouvre les crochets fermés en commentaire initial de list for de value of w css.

En utilisant dix itérations, nous allons créer un cluster Camin et l'adapter à notre ensemble de données

X.

Dans ce cas là.

Alors j'écris.

Ten itérations for I in range 1,11.

Fermer la parenthèse 2.4.

Means egal k means.

Ouvrez la parenthèse n tiret cluster i virgules ini égale ou ré guillemet k tiret.

Mince plus plus fermer les guillemets virgules.

Random tiret state egale 42.

Fermer la parenthèse ca mine point fixe ou est parenthèse x?

Fermer la parenthèse v css tiret liste append ou la parenthèse car mise point energia tiret.

Fermer la parenthèse.

X est un jeu de données d'échantillons que nous avons obtenu de SK Lung Point DataSet.

Sur la base de ce jeu de données, nous allons mettre en œuvre le clustering Camino dans les prochaines

diapositives.

Le code Kaminsky Kaminsky.

And Cluster y va créer un nombre de clusters de 1 à 10.

Nous allons ajouter les valeurs inerties dans notre liste w css en utilisant W vss.

Liste.

A peine ouvrez la parenthèse car mince inertie.

Tiret.

Fermer la parenthèse.

La méthode de l'inertie mesure la qualité du regroupement d'un ensemble de données.

Par les camin.

Elle est calculée en mesurant la distance entre chaque point de donnée et son centre cible.

En enlevant cette distance aux carrés et en additionnant ces carrés sur chaque cluster.

Ensuite, nous traçons les valeurs de K, les clusters sur l'axe des X et les valeurs des wcs list correspondant

sur l'axe des i.

Alors pour faire ça, j'écris.

PLT point Plaute.

Ouvrez la parenthèse Range.

Ou est la parenthèse 1,11?

Fermer la parenthèse.

Virgules.

W, css, tiret.

Liste fermée la parenthèse.

PLT, pw, title.

Ouvrez la parenthèse, ouvrez les guillemets.

The elbow méthode.

Fermez les guillemets.

Fermez la parenthèse.

PLT pw x label.

Ouvrez la parenthèse, ouvrez les guillemets number of clusters, fermez les guillemets, fermez la

parenthèse PLT hi tech la belle, ouvrez la parenthèse, ouvrez les guillemets w css liste.

Fermez les guillemets, fermez la parenthèse et finalement plt pw show.

Ouvrez, fermez les parenthèses.

Nous avons utilisé la méthode dots plot et donner à nos valeurs X nos itérations à dix et I les dix

valeurs d'inertie correspondantes de W css.

Tirer list comme nous pouvons le voir.

Nous avons également donné le titre à l'aide de la méthode PLT Point Title.

Nous avons ensuite nommé les étiquettes X et Y et à la fin, nous avons utilisé la méthode CHO pour

tracer notre graphique.

Dans nos prochains cours, nous verrons d'autres algorithmes de clustering.

### Regroupement hiérarchique

Dans cette conférence, nous allons aborder un autre type de clustering le clustering hiérarchique.

Le clustering hiérarchique consiste à créer des clusters qui ont un ordre prédéterminé de haut en bas.

Par exemple, tous les fichiers et dossiers du disque dur sont organisés par hiérarchie.

Dans ce type de clustering, nous pouvons voir comment les différents sous groupes sont liés les uns

aux autres.

Il existe deux stratégies de clustering hiérarchique.

L'une est divisif et l'autre est agglomérée hâtive.

La stratégie de division est descendante, c'est à dire que vous commencez par toutes les observations

d'une grande grappe et vous la divisez en petits morceaux.

Pensez à la division comme à la division de la grappe.

La méthode agglomérée est l'inverse de la méthode divisif.

Il s'agit donc d'une méthode ascendante ou chaque observation commence dans son propre cluster, et

les paires de clusters sont fusionnées au fur et à mesure qu'elles remontent dans la hiérarchie.

### Clustering basé sur la densité

Parlons maintenant du clustering basé sur la densité.

Il dépend de la densité du cluster.

Il localise la région de haute densité et sépare les bruits.

L'algorithme DBS Scan est un type de clustering basé sur la densité.

Il peut trouver n'importe quel cluster de forme arbitraire sans être affecté par le bruit.

Par exemple, si un point particulier appartient à un cluster, il devrait être à côté de nombreux autres

points dans ce cluster.

Il fonctionne sur la base de deux paramètres l'un est le rayon et l'autre le point minimum.

Epsilon détermine un rayon déterminé.

Si ce rayon comprend suffisamment de points, nous l'appelons une zone dense.

M détermine le nombre minimum de points de données que nous voulons dans un voisinage pour définir un

cluster.

L'algorithme procède en choisissant arbitrairement un point temps l'ensemble de données s'il a au moins

m points dans un rayon de epsilon autour du point, alors nous considérons que tous ces points font

partie du même cluster.

Voici quelques avantages.

Il peut découvrir des clusters de formes arbitraires.

Il peut trouver des clusters entouré d'un cluster différent et il est robuste face à la détection du

bruit.

### Implémentation du clustering k-means en python
Implémenter on notre clustering kamikaze en python?

Donc je vais devoir écrire pour s'en mettre plein.

Gottlieb in line.

From copies import dip copies import numbi as NP import.

Pendaison az pd from Matt Plaute.

Lib import py plus as plt.

Comme toujours, nous avons apporté les bibliothèques requises.

OK, alors laissez moi continuer.

PLT, pw, rc.

Param.

Ouvrez les crochets, ouvrez les guillemets.

Figures fixes size.

Fermez les guillemets.

Fermez le crochet égal ou la parenthèse 16,9.

Fermez la parenthèse PLT style EWS.

Ouvrez la parenthèse, ouvrez les guillemets GG plotte, fermez les guillemets, fermez la parenthèse

et c'est tout.

Pour la première étape.

### Importation du jeu de données
L'étape deux de notre mise en œuvre consiste à importer notre jeu de données et à vérifier ses colonnes

et ses lignes.

Voici l'ensemble de données que nous allons utiliser dans Python pour comprendre à quoi ressemblent

nos données.

Écrivons ce qu'il suit.

On écrit comme commentaires importer in the dataset puis data égal pd point read tiret csv.

Ouvrez la parenthèse, ouvrez les guillemets.

Mon custom data pw txt.

Fermez les guillemets virgules.

CEP égal.

Ouvrez les guillemets vieillots, fermez les guillemets, fermez la parenthèse print.

Ouvrez la parenthèse data point shape.

Fermez la parenthèse.

Data.

PW.

Head.

Ouvrir.

Fermer.

Parenthèses.

Ainsi, vous pouvez voir que dans l'ensemble de données données, nous avons Customers, ID, Gender

H.

1 ¥ in comme en milliers de dollars et le spending score qui est la valeur calculée de combien un client

a dépensé dans le centre commercial.

Plus la valeur est élevée, plus il a dépensé.

À partir de cette ensemble de données, nous devons calculer certains modèles.

Maintenant.

Puisque CAMIN est un algorithme de machine learning non supervisé, nous ne savons pas ce qu'il faut

calculer exactement.

La première étape sera le prétraitement des données, comme nous l'avons fait précédemment dans nos

cours.

Mais pour le problème du clustering, il sera différent des autres modèles.

Tout d'abord, nous avons importé les bibliothèques pour notre modèle, ce qui fait partie du prétraitement

des données.

Dans les conférences précédentes, nous avons apporté une aide pour effectuer des calculs mathématiques

et nous avons également apporté Mad Block Clips pour tracer des graphiques et Panda pour gérer notre

jeu de données.

Ensuite, nous avons apporté le jeu de données que nous devions utiliser.

Ainsi, comme nous l'avons vu précédemment.

Nous allons utiliser le jeu de données MOL Customers Data csv.

Ici, nous n'avons pas besoin de variables dépendantes pour l'étape de prétraitement des données, puisqu'il

s'agit d'un problème de clustering et que nous n'avons aucune idée de ce qu'il va déterminer.

Commençons par transformer les valeurs catégorielles en vecteurs binaires.

Tout d'abord, nous allons compter les valeurs uniques dans notre colonne Gender.

Donc nous utilisons Value Count sur la colonne Gender.

J'écris le code suivant.

Print Data.

Ouvrez les crochets, ouvrez les guillemets Gender Family Guillemets family.

Cochez Points value ou Tiret Accounts.

Ouvrez parenthèses et fermez les parenthèses.

Nous lançons cette cellule et voilà, nous avons une sortie.

Le résultat nous montre que nous avons 112 femmes et 88 hommes.

### Visualisation du jeu de données

Maintenant obtenons les valeurs annuelles Income et Spending School en utilisant les lignes de code

suivantes.

On écrit un commentaire Getting de valises and putting it et on écrit F un égal data.

Ouvrez le crochet, ouvrez les guillemets annual income.

Entre parenthèses ca dollar.

Fermer la parenthèse, fermer les guillemets.

Fermer le crochet.

Point value f2 égal data.

Ouvrez le crochet, ouvrez les guillemets spending score.

Ouvrez la parenthèse.

Un tiret sans fermer la parenthèse.

Fermez les guillemets fermés.

Crochets, points values.

Ensuite, nous vérifions les noms des colonnes en utilisant la boucle for for qui in data.

Quiz Ouvrez la parenthèse, fermez la parenthèse.

Deux points print qui x égale np pw arrêt.

Ouvrez la parenthèse liste.

Ouvrez la parenthèse zip.

Ouvrez la parenthèse f un virgule F2.

Fermez toutes les parenthèses.

Ensuite je note ce à quoi ressemble le X.

Donc en commentaire x égal.

Ou est le crochet ou est crochet 1,1?

Fermé le crochet de gueules ou le crochet 1,2.

Fermé le crochet virgule ou l crochet 3,3.

Fermer le crochet virgule.

Ouvrez le crochet 4,4.

Fermez les deux crochets.

Puis on écrit plt.

PW squatteurs.

Ouvrez la parenthèse f un virgule F deux virgule ces égales, ouvrez les guillemets blacks.

Fermez les guillemets virgules s égales devant.

Fermez les crochets et nous lançons cette cellule.

Et voilà.

Alors qu'est ce que je viens de faire?

J'ai affiché toutes les clés de nos données.

Qui sont l'idée du client, le genre, l'âge et ainsi de suite.

Ensuite, j'ai défini un tableau numb et zipper les valeurs des listes F1 et F2.

J'ai également laissé un commentaire sur l'apparence de X.

Nous avons ensuite tracé un graphique de dispersion pour voir dans quelle mesure nos données sont dispersées.

Vous pouvez le voir dans le graphique de sortie.

Maintenant, dans le prochain cours, nous allons entrainer nos modèles et nous allons visualiser les

regroupements.

### Définition du classificateur
Maintenant dans notre étape de mise en œuvre.

Cinq, nous allons définir le classificateur.

Tout d'abord, nous l'emportons from SQL, un cluster import.

Car mine algorithme.

Ensuite, nous allons créer notre classificateur avec un nombre de clusters.

On choisit nombre de clusters égal à trois.

Alors j'écris en commentaire.

Number of clusters.

Puis Cummings et Cummings entre parenthèses.

N cluster égal.

Trois Fermez la parenthèse.

Ensuite, nous allons entraîner notre modèle à l'aide de la méthode FITZ et en fournissant nos données

d'entraînement X.

Donc je garde une note ici.

Fitting the input data et camin.

Mince.

Points fixes entre parenthèses X.

Ensuite, nous précisons les performances de notre modèle sur X et stockons les étiquettes en commentaire

commentaires getting the clusters label et on écrit Label Égal Camin Predict X.

Ensuite, nous créons les clusters en utilisant Dots Clusters Centers.

Et nous imprimant les valeurs.

On écrit Centre Rottweilers et Centre ID égal kaminsky.

PW clusters.

Tirets centers.

Tiret.

Il s'agit des coordonnées des clusters.

Et elles sont cohérentes avec nos étiquettes.

Dans les prochains cours, nous allons tracer les clusters.

### Visualisation 3D des clusters

Donc laissez moi écrire le code suivant.

Fig égale plt point.

Figure.

Ouvrir et fermer la parenthèse.

Axe.

Axis 3D.

La parenthèse Fig.

Fermer la parenthèse acces point.

Squatteurs.

Ouvrez la parenthèse X.

Ouvrez les crochets deux point virgule zéro.

Fermer les crochets.

Virgule.

X ou y crochet deux points virgules.

Un.

Fermer les crochets virgules x ou y crochets.

Deux points virgule deux fermés.

Crochets.

Fermer la parenthèse.

Ici, nous avons d'abord défini une figure en utilisant PLT point figure.

Puis nous avons défini un axe 2D à l'intérieur de la figure.

Après quoi, nous avons créé les diagrammes de dispersion pour nos valeurs X pour trois attributs.

Le code X2 point virgule zéro fermé crochet correspond à.

La première catégorie X ouvrait crochet deux point virgule un, fermé le crochet à la deuxième et ainsi

de suite.

### Visualisation 3D des valeurs prédites

Nous arrivons à notre dernière étape d'implémentation en traçant nos clusters.

Notre cabinet prédit sur l'ensemble de données X.

Nous utilisons le même code que précédemment.

Nous définissons d'abord une figure en utilisant Fig égale PLT point figure.

Ensuite axe Axis 3D.

Les parenthèses Fig fermées, les parenthèses.

Nous utilisons ici un tracé 3D à l'intérieur de la figure.

Après quoi, axe points skateurs.

Ouvrez la parenthèse X ouvre le crochet deux points virgule zéro.

Fermé le crochet virgule X.

Ouvrez le crochet deux point virgule un.

Fermez le crochet.

Virgules x deux points 1,2.

Crochet.

C'est égal.

Ouvrez les guillemets y.

Fermez les guillemets.

Fermez la parenthèse.

Ici, nous avons créé les diagrammes de dispersion pour nos valeurs de X pour trois attributs.

Le code.

X crochet deux point virgule zéro crochet correspond à la première catégorie et x crochet deux point

virgule un crochet à la deuxième et ainsi de suite.

Acces point squatteurs.

Parenthèse C crochet 2.0 crochet virgules.

C crochet deux points virgules, un crochet virgules.

C 2.2 crochets, virgules, marqueurs égalent.

Guimet.

Etoile.

Guimet.

Virgule.

C'est également Guimet.

Hashtag zéro cinq zéro cinq zéro cinq.

Guillemet virgules s égales sans fermer le crochet.

Ces crochets, deux points virgule zéro crochets et la première catégorie de nos données prédites,

ces crochets de point virgule un crochets.

La seconde et ainsi de suite.

Le marqueur guillemets étoile guillemets.

Les étoiles montrent le centre de notre cluster et c'est égal.

Guillemets.

Hashtag zéro cinq zéro cinq zéro cinq.

Guillemets et la couleur et s également un zéro.

Et le prélèvement de 1000 échantillons des valeurs prédites.

### Nombre de clusters prédits

Dans cette diapositive, nous avons d'abord initialisé notre algorithme Camin camin camin.

Ouvrez la parenthèse.

N Cluster égal quatre.

Nous avons fixé notre nombre de clusters à quatre, ce qui signifie que l'algorithme Kaminsky va classer

nos valeurs dans quatre clusters.

Dans la ligne de code suivante, nous écrivons qu'un means égale qu'un mince point fixe ouvre.

La parenthèse X permet la parenthèse.

Nous entraînons notre algorithme gamine sur les données X.

Après l'entraînement, nous allons prédire le cluster pour d'autres points de données.

Donc maintenant pour prédire les clusters, je vais écrire la belle camin predict.

Entre parenthèses X fermes implantés ici, nous stockons les clusters de chaque point de donnée dans

une variable appelée labels.

Ensuite, nous affichons les étiquettes en écrivant Print Label.

Cette ligne de code affiche tous les numéros de clusters dans lesquels notre modèle entraîné a classé

les points de données.

Comme nous pouvons le voir, nous avons des valeurs de clusters de 0 à 4.

Ceci parce que nous avons défini un nombre de clusters égal à quatre.

Voyons si vous pouvez répondre à cette question.

Lequel des éléments suivants est requis par le clustering car mince à la métrique de la distance définie.

B.

Le nombre de clusters, c'est l'estimation initiale des centraux ID des clusters des.

Tout ce qui précède.

Tout ce qui précède car le clustering CA Mainz suit l'approche de partitionnement.

Par l'approche de partitionnement, on entend que Camin utilise toutes les étapes pour classer les points

de données apparentés dans un cluster.

Pour ce faire, il utilise les options A, B et C.

## Section 9 : Systeme de recommandation 

### Introduction

Notre dernière section et le système de recommandation.

Alors, qu'est ce que le système de recommandation?

Les systèmes de recommandation sont des algorithmes visant à suggérer des éléments pertinents aux utilisateurs.

Par exemple, il peut s'agir de films à regarder et de textes à lire, de produits à acheter ou de tout

autre chose en fonction du secteur d'activité.

Alors, quelles sont les applications de ce système?

Les applications des systèmes de recommandation comprennent les films, la musique, les livres, les

sites web et les programmes de télévision.

Netflix, Amazon, LinkedIn, Twitter et Facebook utilisent des systèmes de recommandation dans leurs

logiciels à des fins différentes.

Maintenant, quels sont les avantages des systèmes de recommandation?

Les systèmes de recommandation augmentent l'engagement des clients.

Ils augmentent la satisfaction du client en fournissant un contenu pertinent.

Par exemple, Amazon peut montrer tous les produits pertinents à ses clients.

Et de la même manière, Netflix peut vous recommander des films en fonction de vos intérêts.

Les systèmes de recommandation réduisent le temps de recherche de contenu.

En effet, il vous suffira de sélectionner vos films préférés parmi les films recommandés.

### Filtrage collaboratif dans les systèmes de recommandation

Quels sont donc les systèmes de recommandations par filtrage collaboratif?

La méthode de filtrage collaboratif permet de prédire les intérêts d'un utilisateur pour un produit

en recueillant les informations sur les préférences de nombreux autres utilisateurs.

Nous pouvons voir que l'utilisateur aime le film un, le film deux et le film trois.

Et l'utilisateur aime le film deux.

Et le film un.

Sur la base de la méthode de filtrage collaboratif, le système recommandera le film trois à l'utilisateur

deux.

### Système de recommandation basé sur le contenu

Maintenant, qu'est ce qu'un système de recommandation basé sur le contenu?

Les méthodes de filtrage basées sur le contenu utilisent les caractéristiques des produits pour recommander

d'autres produits comme ce que l'utilisateur aime sur la base des actions précédentes d'autres utilisateurs,

ou d'un retour explicite comme la notation des produits.

Comme nous pouvons le voir sur le diagramme U1 qui est l'utilisateur un M film M1 et M2, le genre né

de films et celui des films d'aventure.

Dans un tel scénario, le système de recommandation basé sur le contenu va choisir un film d'aventure

pour l'utilisateur.

Un comme prochaine suggestion
### Implémentation en python : Importation de bibliothèques et de jeux de données
Nous voyons maintenant l'implémentation des systèmes de recommandations en Python.

La première étape de la mise en œuvre consiste donc à importer les bibliothèques et les ensembles de

données.

Comme d'habitude, je vais devoir écrire ce qui le suit.

Importe.

Numbi ase np importe.

Panda.

Ass pédé.

Importe si bone as sns.

Après avoir emporté Numbi panda et si bonnes, nous allons utiliser les bibliothèques pour obtenir les

ensembles de données.

Nous aurons deux ensembles de données dans cet exemple U Point Data et Movie Tiret ID Tiret title.

Donc laissez moi d'abord récupérer les données de.

Euh data en écrivant ce qui suit.

Colonne tiret names égalent crochets.

Guillemets user tiret.

Des guillemets, virgules.

Guillemets.

Item, tiret.

Idée.

Guillemets.

Virgules, guillemets.

Writing guillemets.

Virgules.

Guillemets.

TimeStamp.

Guillemets.

Crochets d f égal.

PD point read.

Tiret csv.

Ouvrez la parenthèse, ouvrez les guillemets u data.

Fermez les guillemets, virgules, ceps égales.

Ouvrez les guillemets back slash t.

Fermez les guillemets.

Virgules names égales.

Colonne tiret name.

Fermez les parenthèses.

DF pw.

Head.

Ouvrez la parenthèse, fermez la parenthèse et on loss cette cellule.

Donc ici vous pouvez voir les données de U Point Data.

Nous pouvons voir que pour cet ensemble de données, les données de l'utilisateur contient en item ID

un User ID, un rating et un timestamp.

Nous avons utilisé Panda pour importer notre fichier csv.

Donc en fait c'est juste la fonction point read csv qui nous a aidé à emporter les données.

Nous pouvons également spécifier les colonnes que nous voulons importer.

Dans notre cas, il s'agit de users à EDI et de items idee ainsi que du rating et du time stamp.

Nous avons ensuite utilisé la méthode HEAD de la bibliothèque Panda pour voir les cinq premières lignes

de nos données.

Maintenant, récupérons les données de l'ensemble de données qui contient l'idée et les titres des films.

Movie Title égal PD point huit du type CSV.

Ouvrez la parenthèse, ouvrez les guillemets.

Movie tiret ID tiret title.

Fermer les guillemets.

Fermer la parenthèse movie tiret title head.

Ouvrez, fermez les parenthèses.

Nous pouvons voir que l'élément numéro un et Toy Story.

Puis pour l'élément numéro deux, son titre et GoldenEye, et ainsi de suite.

### Fusion de jeux de données en une seule trame de données

Ainsi, pour avoir importé les deux ensembles de données, nous les fusionneront en un seul cadre de

données Data Frame, en utilisant l'idée d'articles communs.

Nous allons utiliser la méthode de fusion de la bibliothèque Panda.

Je vais donc écrire ce qui suit.

DF égal pd Murdoch.

Ouvrir parenthèses.

DF virgules.

Movie tiret.

Title.

Virgule.

Un égal.

Ouvrez les guillemets.

Items tiret id.

Fermer les guillemets.

Fermer la parenthèse des f head.

Ouvrez la parenthèse.

Fermer la parenthèse.

Encore une fois, nous pouvons vérifier nos données en utilisant la méthode Head de Panda.

### Tri par titre et notation

Après avoir fusionné nos ensembles de données en un seul, nous tirons les rangers par groupes de titres

et d'évaluations.

Ensuite, nous trouvons le nombre et la moyenne de toutes les évaluations sur un titre donné.

Laissez moi donc écrire les lignes de code nécessaires import math plus, livre pi plus ass.

PLT import cyborg as sns.

SNS point sept.

Tiret style ou un parenthèses ou les guillemets white.

Fermez les guillemets.

Fermez la parenthèse.

Pour 100 ma de plotte.

Lib inline.

Maintenant, créons un cadre de données d'évaluation avec l'évaluation moyenne et le nombre d'évaluation.

DF.

PW.

Group be.

Ouvrez la parenthèse, ouvrez les guillemets.

Title.

Fermez les guillemets.

Fermez la parenthèse, ouvrez les crochets, ouvrez les guillemets writing.

Fermez les guillemets, fermez les crochets.

PW mine ouvert, parenthèses.

Fermez les burundaises.

Sortes tiret valouse ouvrez la parenthèse ascending égale falls.

Fermez la parenthèse points head parenthèse.

Nous lançons cette cellule.

DF Groupe BI.

Ouvrez la parenthèse ou les guillemets title.

Fermez les guillemets, fermez la parenthèse, ouvrez le crochet, ouvrez les guillemets writing.

Fermez les guillemets, fermez les crochets.

Points count crochets.

Points sortir value.

Parenthèse à standing égal Fool's Farm, La Parenthèse, Head Parenthèse.

Nous lançons cette cellule.

En gros, nous avons utilisé la méthode Group By pour regrouper nos données par titre et par note.

Ensuite, nous avons compté toutes les évaluations sur les titres donnés.

Et puis nous avons trié les valeurs par ordre décroissant, comme vous pouvez le voir.

Et enfin, nous avons affiché nos données en utilisant la fonction Head.

Donc, comme vous pouvez le voir, nous avons obtenu tous les comptes pour les titres 584 évaluations

pour Star Wars, 509 pour Contra, 508 notes pour Fargo et ainsi de suite.

Ensuite, nous avons également trouvé la moyenne du classement en utilisant la fonction Point Mean.

Comme vous pouvez le voir à l'écran.

OK.

Passons maintenant à l'étape suivante.

Nous trions les rangés par groupe de titre et par classement.

Nous avons placé toutes les évaluations sous forme de data frame dans notre variable d'évaluation et

nous avons obtenu la moyenne de toutes les évaluations.

Nous pouvons voir que pour chaque titre, nous avons un classement correspondant.

Par exemple, pour le titre il l'est ou au IU 1997.

La moyenne des notes est de 2,333.

Maintenant, après avoir obtenu tous les évaluations moyennes, nous allons ajouter une nouvelle colonne

à ce data frame.

Et nous mettrons le nombre d'évaluations disponibles pour chaque film.

Laissez moi donc écrire le code nécessaire.

Ratings ou télé crochets, ouvrez les guillemets nuls off ratings.

Fermez les guillemets, fermez les crochets égal pd point dans ta frame.

Ouvrez les parenthèses.

DF point group.

Bye, ouvrez la parenthèse, ouvrez les guillemets title.

Fermez les guillemets, fermez la parenthèse, ouvrez le crochet ou guillemets writing.

Fermez les guillemets, fermez crochets, points count.

Ouvrez les parenthèses et fermez toutes les parenthèses.

Ratings head.

Ouvrez, fermez Pontaise et nous lançons cette cellule.

Comme vous pouvez le voir, nous avons ajouté une nouvelle colonne et nous l'avons appelée.

Number of ratings.

Nous avons mis tous les comptes de chaque classement dans cette colonne.

Par exemple, pour le film Til There Was You 1997, vous pouvez voir que seuls neuf utilisateurs ont

évalué ce film.

De même, le film Douze hommes en colère 1957 a été évalué par 125 utilisateurs.

Cela nous donne une idée claire du nombre d'utilisateurs qui ont évalué le film et de la signification

de ces évaluations.

### Histogramme indiquant le nombre d’évaluations
Maintenant traçons un histogramme qui nous montrera le nombre d'évaluations.

Donc pour faire cela, je vais écrire le code suivant PLD point figure.

Ouvrez la parenthèse Fig seize égale.

Ouvrez la parenthèse 10,4.

Fermez les parenthèses ratings.

Ouvrez le crochet, ouvrez les guillemets name of ratings.

Fermez les guillemets.

Fermez le crochet.

Hit.

Ouvrez la parenthèse beans égalent 70.

Fermez la parenthèse.

Nous lançons la cellule et voilà.

Nous avons utilisé la méthode pointilliste pour tracer cet histogramme.

Et comme vous pouvez le voir, nous avons un classement maximum de 500 utilisateurs pour un film.

### Distribution des fréquences


Maintenant, laissez moi créer un histogramme pour les évaluations.

Cela nous permettra de voir combien d'utilisateurs ont choisi une note de un.

Combien d'utilisateurs ont choisi une note de deux?

Combien d'utilisateurs ont choisi une note de trois et ainsi de suite?

OK.

Donc pour faire ça, je vais devoir écrire le morceau de code suivant PLT.

Point figure.

Ouvrez la parenthèse Fig seize égale ou vraie parenthèse?

10,4.

Fermez les parenthèses ratings.

### Graphique combiné des notations et nombre de notations

Nous allons maintenant utiliser la bibliothèque Seaboard pour tracer un graphique conjoint, des évaluations

et du nombre d'évaluations.

OK, laissez moi faire ça.

SNS jeune plotte.

Ouvrez la parenthèse X égal.

Ouvrez les guillemets writing.

Fermez les guillemets virgules, y egales.

Ouvrez les guillemets.

Name off ratings fermez les guillemets virgules.

Data égale ratings virgule alpha egale 0.5.

Fermez la parenthèse.

Nous lançons cette cellule et voilà, nous avons le résultat souhaité.

À partir de ce graphique, nous pouvons clairement voir que très peu de personnes ont noté un film cinq

étoiles.

Pour ce qui est des 4,5 étoiles, nous constatons qu'environ 600 notes de 4,5 ont été attribuées par

les utilisateurs.

Nous constatons également que le nombre d'évaluations est plus élevé pour les catégories trois et quatre

étoiles.

OK, maintenant que nous avons une idée générale de ce à quoi ressemblent les données, passons à la

création d'un système de recommandation simple.

### Prétraitement des données

Dans cette étape de mise en œuvre, nous importons le jeu de données de films et le pré traitons.

Créons une matrice avec les identifiants des utilisateurs sur un axe et le titre du film sur un autre

axe.

Chaque cellule sera ensuite composée de la note que l'utilisateur a donné à ce film.

Notez qu'il y aura beaucoup de valeur n a n car la plupart des gens n'ont pas vu la plupart des films

ok.

Donc pour faire cela, nous allons utiliser le pivot.

Table et on va faire un tableau comme index.

Le user ID.

Les titres comme colonne et les ratings comme valeur de nos cases.

Alors je vais écrire movie mate.

Égal egal df point pivote.

Table ouvrait la parenthèse index égal.

Ouvrez les guillemets user tiret id.

Fermez les guillemets.

Virgules, colonnes.

Ouvrez les guillemets title.

Fermez les guillemets, virgules, values égales.

Ouvrez les guillemets writing.

Fermez les guillemets.

Fermez la parenthèse.

Movie Matt Head.

Et on lance la cellule.

Et voilà, nous avons le résultat souhaité.

Chaque cellule sera alors constituée de la note de l'utilisateur pour un film donné et nous pouvons

voir les données en utilisant la méthode PWM Head.

Comme nous l'avons vu précédemment, il y a quelques valeurs nulles dans nos données et ces valeurs

sont nulles parce que la plupart des gens n'ont pas vu la plupart des films et ne les ont pas notées.

Nous devons pré traiter ces données et les rendre propres.

Mais avant cela, trions les films les mieux notés.

### Tri des films les mieux notés

Trions les films les plus évalués en utilisant le point, sorte value sur le nombre d'évaluation, puis

imprimant les dix premières valeurs ratings.

Sorte value?

Ouvrez la parenthèse.

Ouvrez les guillemets.

Name of ratings.

Fermez les guillemets.

Virgules, ascending égales.

Fausses.

Fermez la parenthèse point head ou à la parenthèse dix femmes appâtés.

Nous lançons cette cellule.

Nous pouvons voir que le film le mieux noté est Star Wars 1977 avec un nombre d'évaluations égal à 584

et une note moyenne de 4,359.

Le deuxième est contact 1977 avec une note de 3,80 et il est évalué par 169 personnes.

### Obtenez les notes pour deux films

Prenons les évaluations des utilisateurs.

Pour ces deux films, nous trouverons la colonne de Star Wars 1977 dans notre DataSet Movie Math.

Et de même pour le film Layer Layer 1997.

D'accord, laisse moi écrire StarWars.

Tiret user tiret ratings égal movie.

Maths.

Crochets, guillemets, starwars.

Ouvrez la parenthèse.

1977 fermait la parenthèse fermée, le guillemet ferme et le crochet.

Laya Laya User Ratings égal movie Math.

Ouvrez le crochet, ouvrez les guillemets, l'ailleurs, l'ailleurs.

Ouvrez la parenthèse, 1997.

Fermer la parenthèse fermée, les guillemets fermés, le crochet.

Star Wars USA Ratings PW Head ouvre la parenthèse sur ma panthéisme.

Nous lançons cette cellule.

Nous pouvons voir que pour l'utilisateur ID3, il n'y a pas de classement et cela va créer quelques

erreurs que nous verrons plus tard.

### Corrélation entre les films les mieux notés

Nous allons maintenant utiliser la méthode Core huit pour obtenir la corrélation entre nos films les

mieux notés.

Similar to Star Wars Egal movie mate core wit.

Entre parenthèses Star Wars tiret user tiret ratings.

Similar to life layers égal movie math core which ouvrait la parenthèse layer layer.

Tiret user tiret ratings.

Et nous obtenons une erreur.

L'erreur indique un avertissement d'exécution.

Zéro rencontré.

C'est à cause des valeurs nulles dans notre table.

Donc supprimons les erreurs.

Nous allons maintenant créer un autre data frame avec des arguments qui contiennent la variable similar

to StarWars ainsi que la colonne de corrélation corps tiret StarWars égal PD data frame.

Ouvrez la parenthèse similar to StarWars virgules, columns égales.

Ouvrez les crochets, ouvrez les guillemets.

Corrélation, ouvrez les guillemets, fermez le crochet.

Fermez la parenthèse core.

StarWars PW.

Drop na.

Ouvrez la parenthèse.

Une place égale trou.

Fermer la parenthèse corps tiret.

StarWars head.

Nous lançons la cellule et voilà.

Nous avons donc supprimé toutes les valeurs nulles en utilisant le point drop n'a.

### Tri des données par corrélation

Trions donc nos données sur la base de la corrélation core starwars point sword tiret valouse.

Ouvrez la parenthèse, ouvrez les guillemets corrélation.

Fermez les guillemets, virgules, ascending et foals.

Fermez la parenthèse head.

Ouvrez la parenthèse dix.

Fermez la parenthèse, lançons cette cellule.

Maintenant, si nous trions le cadre de données par corrélation, nous devrions obtenir les films les

plus similaires.

Mais notez que nous obtenons des résultats qui n'ont pas vraiment de sens.

Cela s'explique par le fait qu'un grand nombre de films n'ont été regardé qu'une seule fois par des

utilisateurs qui ont également regardé Star Wars.

C'était le film le plus populaire.

Nous pouvons résoudre ce problème en filtrant les films qui ont moins de 100 critiques.

### Filtrage des films

D'accord.

Corrigeons maintenant ce problème en filtrant les films qui ont moins de 100 critiques.

Cette valeur a été choisie en fonction de l'histogramme tracé précédemment.

Corps tiré du bas Star Wars égal corps tiré du bas Star Wars Point Jeune ouvrait la parenthèse Writings.

Ouvrez le crochet, ouvrez les guillemets.

Name of ratings fermait les guillemets.

Fermé le crochet.

Fermé la parenthèse core.

Star Wars Point Head et nous lançons cette cellule.

### Tri des valeurs
Ensuite, nous tirons enfin les valeurs et nous remarqueront que les titres ont beaucoup plus de sens.

Encore Star Wars ou télécrochet?

Car Star Wars ouvre les crochets, ouvrez les guillemets name of ratings, fermez les guillemets fermés,

les crochets plus grands que sans fermer crochets.

Sorte value ouvrez la parenthèse, ouvrez les guillemets.

Corrélation, fermez les guillemets, virgules, ascending et falls.

Fermez la parenthèse point head.

Ouvrez Fermer la parenthèse et nous lançons cette cellule.

Ici, nous avons utilisé un nombre d'évaluation supérieur à 100, puis nous avons trié les valeurs en

fonction de la corrélation.

Lorsque nous imprimant nos données, nous pouvons voir que le nombre d'évaluations pour Star Wars est

de 584 et qu'il y a une corrélation de 100 %.

Puis après cela, nous avons d'autres films.

### Répéter le processus pour un autre film

En procédant de la même manière.

Pour le film Layer Layer 1997, nous écrivons corps tirets Layer Layer égale PD Data Frame ouvrait la

parenthèse similar to layer layer.

Virgules.

Colonnes égales, ouvrez crochets.

Ouvrez les guillemets.

Corrélation fermer les guillemets.

Fermer les crochets fermes.

Importer.

Core layer layer drop.

RNA.

Ouvrez la parenthèse in place.

Trou.

Fermez la parenthèse.

Core Layer Layer Core Layer Layer Point.

Jouanne.

Ouvrez la parenthèse ratings.

Ouvrez les crochets.

Ouvrez les guillemets.

Name of ratings.

Fermer les guillemets.

Fermer les crochets, fermer les parenthèses.

Core layer layer ou est crochet core layer layer ou a les crochets ou les guillemets.

Name of ratings.

Fermez les guillemets fermés.

Le crochet plus grand que sans fermer les crochets.

Sortes value entre parenthèses ou les guillemets.

Corrélation.

Fermez les guillemets.

Virgules, ascending et gal falls.

Fermez les guillemets.

Point head.

Ouvrez, fermez les guillemets et nous lançons cette cellule.

Nous pouvons voir qu'il y a un nombre deux 485 evaluation avec une corrélation de 100 %.

Et puis après cela, nous avons d'autres films.

Voici le dernier quiz pour vous.

Pourquoi les moteurs de recommandation deviennent ils populaires?

Ah, les utilisateurs ont moins de temps, plus d'options et sont confrontés à une surcharge d'informations.

B Il est obligatoire d'avoir un moteur de recommandation selon les règles de télécommunication.

C.

Il est préférable de recommander à l'utilisateur de faire des recherches sur son téléphone portable

plutôt que de lui demander de les faire d?

Les utilisateurs ne savent pas ce qu'ils veulent et la réponse est.

Les moteurs de recommandation deviennent populaires parce que les utilisateurs ont moins de temps,

plus d'options et sont confrontés à une surcharge d'informations.

## Section 10 : conclusion 
Voilà, c'est la fin de ce cours.

J'espère que vous êtes maintenant à l'aise avec les différents concepts du machine learning.

Merci.



References:
- [Python pour le Deep Learning & le Machine Learning: A à Z](https://www.udemy.com/course/machine-learning-et-deep-learning-avec-python-la-formation-complete/)


Created:: 2024-03-14 10:05
- 17782 words.
- 115022 Characters.