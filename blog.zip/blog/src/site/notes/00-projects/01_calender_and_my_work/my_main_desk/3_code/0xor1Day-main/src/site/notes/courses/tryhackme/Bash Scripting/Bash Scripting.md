---
{"dg-publish":true,"permalink":"/00-projects/01-calender-and-my-work/my-main-desk/3-code/0xor1-day-main/src/site/notes/courses/tryhackme/bash-scripting/bash-scripting/","dgPassFrontmatter":true,"noteIcon":""}
---


#bash 

---
Task 1 [[00-projects/01_calender_and_my_work/my_main_desk/3_code/0xor1Day-main/src/site/notes/courses/tryhackme/Bash Scripting/content/Introduction_bash\|Introduction_bash]]

Task 2 [[Our first simple bash scripts \|Our first simple bash scripts ]]

Task 3 [[00-projects/01_calender_and_my_work/my_main_desk/3_code/0xor1Day-main/src/site/notes/courses/tryhackme/Bash Scripting/content/Variables\|Variables]]

Task 4 [[00-projects/01_calender_and_my_work/my_main_desk/3_code/0xor1Day-main/src/site/notes/courses/tryhackme/Bash Scripting/content/Parameters\|Parameters]]

Task 5 [[00-projects/01_calender_and_my_work/my_main_desk/3_code/0xor1Day-main/src/site/notes/courses/tryhackme/Bash Scripting/content/Arrays\|Arrays]]

Task 6 [[00-projects/01_calender_and_my_work/my_main_desk/3_code/0xor1Day-main/src/site/notes/courses/tryhackme/Bash Scripting/content/Conditionals\|Conditionals]]

Task 7: [[00-projects/01_calender_and_my_work/my_main_desk/3_code/0xor1Day-main/src/site/notes/courses/tryhackme/Bash Scripting/content/Further reading\|Further reading]]