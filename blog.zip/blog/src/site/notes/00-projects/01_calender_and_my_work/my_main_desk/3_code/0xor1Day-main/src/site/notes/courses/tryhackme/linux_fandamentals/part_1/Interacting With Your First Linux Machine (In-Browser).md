---
{"dg-publish":true,"permalink":"/00-projects/01-calender-and-my-work/my-main-desk/3-code/0xor1-day-main/src/site/notes/courses/tryhackme/linux-fandamentals/part-1/interacting-with-your-first-linux-machine-in-browser/","dgPassFrontmatter":true,"noteIcon":"","created":"2024-09-16T09:05:48.139+01:00"}
---


However, to get started, simply press the green "Start Machine" button on the top-right of this task indicated by the arrow on the right:

Once deployed, a card will appear at the top of the room:
![Pasted image 20230830161242.png](/img/user/courses/tryhackme/linux_fandamentals/part_1/img/Pasted%20image%2020230830161242.png)

This contains all of the information for the machine deployed in the room including the IP address and expiry timer - along with buttons to manage the machine. Remember to "**Terminate**" a machine once you are done with the room. More information on this can be found in the [tutorial](https://tryhackme.com/jr/tutorial) room.

For now, press "**Start Machine**" where you will be able to interact with your own Linux machine within your browser whilst following along with this room:
![Pasted image 20230830161317.png](/img/user/courses/tryhackme/linux_fandamentals/part_1/img/Pasted%20image%2020230830161317.png)


