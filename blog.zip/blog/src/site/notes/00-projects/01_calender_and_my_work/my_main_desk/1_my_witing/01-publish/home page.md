---
{"dg-home":true,"dg-publish":true,"title":"Ghouti start brain","permalink":"/00-projects/01-calender-and-my-work/my-main-desk/1-my-witing/01-publish/home-page/","tags":["gardenEntry"],"dgPassFrontmatter":true,"noteIcon":"","created":"2024-09-19T13:36:47.570+01:00"}
---

# 0xor1Day Second Brain

![0xor1Day_banner.jpg](/img/user/00-projects/01_calender_and_my_work/my_main_desk/1_my_witing/01-publish/img/0xor1Day_banner.jpg)

# start here :
> this site is hosted by [0xor1Day](https://0xor1Day.me/) as a second brain hosted note to the public welcome to my brain and my deep idea.

**Welcome to my personal knowledge management system! I'm a computer science student from Algeria with a deep love for history, tech, and art. Join me as I explore the intersections of these passions and share my insights with you. Let's embark on this journey together!**

# how to use the site 

<iframe width="560" height="315" src="https://www.youtube.com/embed/vcRj5qxk_ho?si=L1L35hmw_edDm0Rx" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

# module that i learn 

## from univ (in french)

<div class="transclusion internal-embed is-loaded"><a class="markdown-embed-link" href="/00-projects/01-calender-and-my-work/my-main-desk/1-my-witing/01-publish/faculter-cs/faculter-note-and-cours/" aria-label="Open link"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="svg-icon lucide-link"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"></path><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"></path></svg></a><div class="markdown-embed">




# Semester 1
## Analyse 1
## Algebre 1
## algorithmique 1
## architecture 1 
## systeme d'exploitation 1
## francais 
# Semester 2
## Analyse 2
## Algebre 2
## algorithmique 2
## logic mathematique 
## systeme d'exploitation 2
## probabilite et statistic 1
## expretion oral 
# Semester 3
## Analyse 2
## Algebre 2
## structure & fichier 
## obejct oriented programming (java) 1
## algorithme & comlexité 
## probabilite et statistic 2
## entrepenaria 
# Semester 4
## obejct oriented programming (java) 1
- [[00-projects/01_calender_and_my_work/my_main_desk/1_my_witing/01-publish/Faculter CS/Semester 4/orionté objet progamming 2/gestion des exception\|gestion des exception]]
- [[00-projects/01_calender_and_my_work/my_main_desk/1_my_witing/01-publish/Faculter CS/Semester 4/orionté objet progamming 2/Les génériques (generics)\|Les génériques (generics)]]
- [[Colection\|Colection]]
## base de donner (oracle 10g EX )
- [[00-projects/01_calender_and_my_work/my_main_desk/1_my_witing/01-publish/Faculter CS/Semester 4/base de donner/Data Base/Unlock the Power of Data Your First Steps into Oracle 10g SQL\|Unlock the Power of Data Your First Steps into Oracle 10g SQL]]
- [[00-projects/01_calender_and_my_work/my_main_desk/1_my_witing/01-publish/Faculter CS/Semester 4/base de donner/Data Base/Your SQL Playground Setting Up Your Database Adventure\|Your SQL Playground Setting Up Your Database Adventure]]
- [[00-projects/01_calender_and_my_work/my_main_desk/1_my_witing/01-publish/Faculter CS/Semester 4/base de donner/Data Base/Demystifying Data Essential SQL Commands for Beginners\|Demystifying Data Essential SQL Commands for Beginners]]
- 
## resaux 
## theore des graph 
## theore des languge
## projet pluridesiplinaire 
- [[00-projects/01_calender_and_my_work/my_main_desk/1_my_witing/01-publish/Faculter CS/Semester 4/projet pluridesiplinaire/la partie AI\|la partie AI]]
- 
## english 
# Semester 5
# Semester 6
# Semester 7
# Semester 8
# Semester 9
# Semester 10

</div></div>

# last edit 

```dataview
TABLE WITHOUT ID
  file.name AS "Note",
  file.last_modified AS "Last Modified"
SORT file.last_modified DESC
LIMIT 5
```

# Books
```dataview
Table author as Author, ("![|100](" + cover + ")") as Cover, pages, category as genre
From "BOoks" 
Where contains(status, "complete") 
```
---
[<img style="float:left" src="https://user-images.githubusercontent.com/14358394/115450238-f39e8100-a21b-11eb-89d0-fa4b82cdbce8.png" width="200">](https://ko-fi.com/0xor1day) 