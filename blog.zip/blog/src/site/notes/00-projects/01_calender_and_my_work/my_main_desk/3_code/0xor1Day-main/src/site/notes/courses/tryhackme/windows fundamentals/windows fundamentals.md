---
{"dg-publish":true,"permalink":"/00-projects/01-calender-and-my-work/my-main-desk/3-code/0xor1-day-main/src/site/notes/courses/tryhackme/windows-fundamentals/windows-fundamentals/","dgPassFrontmatter":true,"noteIcon":""}
---


# part 1 

Task 1 [[00-projects/01_calender_and_my_work/my_main_desk/3_code/0xor1Day-main/src/site/notes/courses/tryhackme/windows fundamentals/part 1/Introduction to Windows\|Introduction to Windows]]

Task 2 Windows Editions

Task 3 The Desktop (GUI)

Task 4 The File System

Task 5 The Windows\System32 Folders

Task 6 User Accounts, Profiles, and Permissions

Task 7 User Account Control

Task 8 Settings and the Control Panel

Task 9 Task Manager

Task 10 Conclusion