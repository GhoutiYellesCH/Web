---
{"dg-publish":true,"permalink":"/00-projects/01-calender-and-my-work/my-main-desk/1-my-witing/01-publish/courses/hack-the-box/hackthe-box/","dgPassFrontmatter":true,"noteIcon":"","created":"2024-09-19T13:36:47.528+01:00"}
---


- [[00-projects/01_calender_and_my_work/my_main_desk/1_my_witing/01-publish/courses/HackTheBox/Kioptrix Level 1\|Kioptrix Level 1]]
- 