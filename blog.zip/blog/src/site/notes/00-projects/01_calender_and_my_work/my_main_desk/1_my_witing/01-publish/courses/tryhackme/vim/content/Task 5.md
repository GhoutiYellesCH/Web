---
{"dg-publish":true,"permalink":"/00-projects/01-calender-and-my-work/my-main-desk/1-my-witing/01-publish/courses/tryhackme/vim/content/task-5/","dgPassFrontmatter":true,"noteIcon":"","created":"2024-09-19T13:36:47.477+01:00"}
---

