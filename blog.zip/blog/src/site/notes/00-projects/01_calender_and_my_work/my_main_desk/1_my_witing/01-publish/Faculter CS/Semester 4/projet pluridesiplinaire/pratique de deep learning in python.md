---
{"dg-publish":true,"tags":["AI","Python","DL"],"permalink":"/00-projects/01-calender-and-my-work/my-main-desk/1-my-witing/01-publish/faculter-cs/semester-4/projet-pluridesiplinaire/pratique-de-deep-learning-in-python/","dgPassFrontmatter":true,"noteIcon":""}
---

Status:
Tags: <% tp.file.cursor(3) %>
Links: [[<% tp.file.cursor(4) %>\|<% tp.file.cursor(4) %>]]

___
# pratique de deep learning in python
<% tp.file.cursor(5) %>
___

# Section 1 : pratique de deep learning in python

## Qu'est-ce que le Deep Learning?

**Le Deep Learning : Un Guide pour les Débutants**

Ces dernières années, le deep learning est devenu un terme à la mode dans la communauté technologique.

Nous en entendons constamment parler dans les actualités sur l'IA.

Pourtant, la plupart des gens ne savent pas vraiment ce que c'est.

Dans ce cours, nous allons démystifier le terme "deep learning" et vous donner une idée de son fonctionnement.

**Relation entre le Deep Learning, le Machine Learning, les Réseaux Neuronaux et l'Intelligence Artificielle**

Pour comprendre ce qu'est le deep learning, nous devons d'abord comprendre sa relation avec le machine learning, les réseaux neuronaux et l'intelligence artificielle.

La meilleure façon de visualiser cette relation est de les considérer comme des cercles concentriques.

Le deep learning est un sous-ensemble spécifique du machine learning, qui est lui-même un sous-ensemble de l'intelligence artificielle.

**Définitions**

* **Intelligence artificielle (IA)** : La création de machines capables de penser intelligemment, effectuant des tâches sans qu'elles soient explicitement programmées.
* **Machine learning (ML)** : Une approche pour effectuer des tâches en utilisant des algorithmes pour extraire des informations à partir de données.
* **Deep learning (DL)** : Une approche de ML qui utilise des données et des résultats pour dériver des règles à l'aide d'un algorithme spécifique appelé réseau neuronal.

**Résumé**

En résumé, le deep learning est une forme de machine learning qui utilise des réseaux neuronaux, des algorithmes inspirés de la structure du cerveau humain.

Passons maintenant au prochain cours.
## Pourquoi le Deep Learning est-il important?

**Pourquoi le Deep Learning est-il important ?**

Nous avons vu dans le cours précédent que le deep learning est un sous-ensemble du machine learning, qui est lui-même un sous-ensemble de l'intelligence artificielle.

Le deep learning est important car il peut gérer des complexités impossibles pour le machine learning classique.

En effet, le machine learning a été utilisé pour la classification d'images et de textes pendant des décennies.

Mais il existe un point seuil au-delà duquel le machine learning n'est pas très puissant.

En effet, nous ne sommes pas toujours confrontés à un nombre de données suffisamment petit qu'un simple algorithme puisse gérer la plupart du temps.

Même lorsque le nombre de données est gigantesque, le deep learning nous permet enfin de franchir le seuil du machine learning, comme on peut le voir sur le graphique.

En effet, les performances du deep learning sont nettement supérieures par rapport au nombre de données utilisées aux machines learning classiques ou algorithmes d'apprentissage classique.

**Résumé**

En résumé, de nombreux problèmes complexes peuvent être résolus en utilisant le deep learning.

Le deep learning permet d'analyser de grands jeux de données, de variables pour trouver des modèles cachés dans les données ou trouver des connexions complexes entre elles.

Le deep learning peut ensuite utiliser les modèles trouvés pour optimiser les règles précédemment trouvées pour qu'elles soient plus efficaces.

Le deep learning est vraiment très fort dès qu'il s'agit de tâches compliquées, complexes.

Typiquement, la reconnaissance vocale ou la compréhension du langage, comme le fait votre téléphone ou votre PC.

**Prochaines étapes**

Passons aux prochains cours.

## Logiciels et plateformes

**Logiciels Open Source pour le Deep Learning**

De nombreux progrès dans les applications pratiques du deep learning ont été réalisés grâce à la disponibilité généralisée de logiciels robustes open source.

Avec tous ces logiciels existants, les développeurs préfèrent partir de ceux-ci et les améliorer plutôt que de créer les leurs. Cela augmente évidemment le nombre de personnes qui font activement avancer le développement du deep learning.

En particulier, les praticiens de la science des données s'orientent généralement vers Python ces derniers temps.

De fait, la plupart de ces logiciels sont maintenant développés pour ce langage.

On peut notamment citer TensorFlow, Keras, PyTorch et Scikit-learn.

**Prochain cours**

Passons au prochain cours.
## Supports de Cours (Deep Learning)

# Section 2 : Réseaux de Neurones Artificiels (RNA)

## Introduction

Maintenant que vous connaissez un petit peu le deep learning, nous allons pouvoir aller dans la complexité

de notre sujet.

Comme expliqué précédemment, le deep learning utilise un réseau de neurones pour fonctionner.

Alors il faut garder à l'esprit que le réseau de neurones peut aussi s'appeler un réseau de neurones

artificiels.

Donc c'est un réseau de neurones inspiré de l'architecture du cerveau.

Une version si vous voulez simplifier du système neuronal biologique, il va s'agir d'un réseau extrêmement

dense avec énormément de processeurs qu'on appellera des neurones dont l'architecture rappelle le cerveau

humain.

Les réseaux neuronaux artificiels cherchent à imiter la façon dont les cellules du cerveau fonctionnent.

Ils sont une partie vitale du deep learning.

Maintenant que vous avez un peu plus compris ce que c'était un réseau neuronal artificiel, nous allons

passer au prochain cours.

## Anatomie et fonction des neurones

À l'école, la plupart des élèves trouvent ce diagramme.

Il s'agit de l'anatomie du neurone.

En termes simples, le travail fondamental du neurone, c'est quoi?

C'est de recevoir et de transmettre des impulsions qui sont en fait des informations dans diverses parties

de notre corps.

D'ailleurs, il n'y aura pas un seul neurone, le bloc de construction.

Il va générer des millions et des millions de neurones qui en fait constituent notre réseau neuronal

qui va pouvoir ensuite transmettre les informations dans tout notre corps.

Pensez simplement à la circonstance d'un accident de voiture qui se produit devant votre appartement.

Ce que votre cerveau va penser, c'est immédiatement aller chercher de l'aide, si c'est possible,

sinon contacter une ambulance.

Et ça, ça va se passer par des impulsions dans votre cerveau.

L'information va se transporter de neurone en neurone pour que vous puissiez penser à aller chercher

de l'aide.

J'espère que vous avez un peu mieux compris comment votre système nerveux fonctionne et on va pouvoir

passer à la suite.

## Introduction aux réseaux de neurones

Maintenant, les notions biologiques telles que démontrées dans le sujet précédent deviennent une approche

technologique dans cette représentation graphique.

Le neurone biologique c'est un peu comme le neurone informatique, ils vont recevoir une information

et la transférer au prochain et ainsi de suite.

Donc supposons qu'on ait X-1, exe et XM.

Des neurones multiples qui vont transmettre un signal à un neurone.

Signal.

On va avoir y la sortie.

Imaginez que vous êtes au cinéma avec vos amis, face à un film et à un moment, une scène particulièrement

violente.

Supposer que X ce sont vos yeux, X de vos oreilles, x3 votre bouche, les entrées.

Alors quelles sont vos sorties?

Vous allez automatiquement fermer les yeux, fermer les oreilles et crier plus fort.

Ce sont les sorties.

En bref, cela peut être illustré par le diagramme de cette diapositive.

Nous avons des termes comme W1, W2, W3, et cetera qui signifient les poids.

Alors les poids, c'est crucial pour le fonctionnement d'un réseau neuronal artificiel.

Car les poids sont la façon dont les réseaux neuronaux apprennent en modifiant les poids.

Le réseau neuronal décide quel signal est significatif dans chaque cas et quel signal n'est pas pertinent

pour les neurones.

Donc, quand vous allez entraîner votre réseau neuronal artificiel, vous allez pouvoir choisir ce qui

est le plus important dans votre étude.

Pour résumer en bref, comment se déroule un réseau neuronal.

Un.

Les signaux de plusieurs neurones X1X2.

Et cetera ainsi que leur poids associé w1, w2 deux sont transmis au neurone successif.

Ça va être la couche d'entrée.

Deux.

Après avoir reçu plusieurs signaux, on va considérer comme les neurones avec les points associés.

Nous allons additionner tous les signaux avec leur poids.

Ce sera donc notre étape.

la premaire etape :

Comme indiqué sur la figure.

Ensuite, on va appliquer une fonction d'activation.

Ce sera sera l'étape deux.

Cette étape permet de déterminer pour le neurone si, s'il doit transmettre le signal ou non.

Si le neurone transmet le signal, c'est à dire à un autre neurone, c'est notre sortie et on aura donc

notre couche de sortie.

Finalement, le processus se répète jusqu'au dernier neurone ou la partie de notre corps.

Algorithmiques ou mathématiquement, cela va être traduit par une descente de Gradignan ou une rétro

propagation.

C'est ce que nous allons étudier dans la prochaine leçon.

## Architecture d'un réseau de neurones

Passant en revue les différents types d'architecture de réseaux neuronaux.

L'architecture d'un réseau neuronal est en fait assez simple.

Il y a d'abord la couche d'entrée avec les X1X de XN qui consiste en tous les nœuds d'entrée.

Puis il y a une couche cachée qui consiste en tous les nœuds qui se trouvent entre les nœuds d'entrée

et les nœuds de sortie.

Puis il y a la couche de sortie qui consiste en toutes les sorties du système.

Bon, sur notre système, il n'y a qu'une sortie.

Pour résumer, comment fonctionne un réseau neuronal artificiel?

Il s'agit de nœud d'entrée.

Donc x1, x2, et cetera qui vont envoyer avec leur poids aux nœuds qui appartiennent à la couche cachée.

Ces entrées sont ensuite sommées avec leur poids associé pour créer la fonction de transfert.

Puis une fonction d'activation est appliquée à cette somme pour avoir une valeur finale à mettre en

sortie.

Puis le processus se répète jusqu'à ce que le dernier neurone et la valeur de sortie.

J'espère que vous avez maintenant compris l'architecture d'un réseau de neurones.

Nous allons maintenant nous intéresser à comment l'information se propage tout au long du réseau de

neurones et comment notre modèle peut apprendre de lui même.

# Section 3 : Propagation de l'information dans un résaux de neurones artificiels.
## Réseau de neurones à propagation avant et rétrograde
Il y a deux approches différentes dans la façon dont un réseau neuronal propage le signal des données d'entrée.

Celle qui va dans le sens direct et celle qui va dans le sens rétrograde.

La propagation avance, c'est à dire la propagation directe.

L'information se déplace depuis les nœuds du système d'entrée par les couches cachées s'il y en a, jusqu'aux nœuds de sortie.

Il n'y a pas d'autres connexions qui iraient dans une direction opposée, la propagation rétrograde.

En revanche, il s'agit de la propagation opposée de la propagation directe.

Si on n'a pas la bonne sortie, on va partir du résultat voulu et remonter le processus.

En agissant de la sorte, notre réseau va apprendre et changer les valeurs des pois pour trouver la

bonne valeur et donc évidemment apprendre en conséquence.
## Rétro-propagation
Voici un graphe de vraies valeurs et de valeurs prédites de notre modèle.

Dans ce scénario, il n'y a que deux possibilités.

Premièrement, si les valeurs prédites et les valeurs véritables sont égales, c'est bon, pas de problème.

Sinon, il y a une différence entre ces valeurs.

On pourra créer la valeur appelée résiduelle.

Il s'agit de la valeur réelle, moins la valeur prédite.

Il s'agit donc d'une erreur de notre algorithme que nous voudrions baisser.

Nous allons pouvoir utiliser la propagation rétrograde pour changer les poids et donc baisser l'erreur.

Pour résumer, la rétro propagation permet de trouver les poids optimaux et augmenter la précision de

l'algorithme.

C'est un des algorithmes les plus utilisés mondialement dans l'intelligence artificielle.

Voilà pour la propagation de l'information dans un réseau de neurones.

Passons à la suite.
## Minimisation de la fonction coût avec la rétropropagation
Voici un graphe de vraies valeurs et de valeurs prédites de notre modèle.

Dans ce scénario, il n'y a que deux possibilités.

Premièrement, si les valeurs prédites et les valeurs véritables sont égales, c'est bon, pas de problème.

Sinon, il y a une différence entre ces valeurs.

On pourra créer la valeur appelée résiduelle.

Il s'agit de la valeur réelle, moins la valeur prédite.

Il s'agit donc d'une erreur de notre algorithme que nous voudrions baisser.

Nous allons pouvoir utiliser la propagation rétrograde pour changer les poids et donc baisser l'erreur.

Pour résumer, la rétro propagation permet de trouver les poids optimaux et augmenter la précision de

l'algorithme.

C'est un des algorithmes les plus utilisés mondialement dans l'intelligence artificielle.

Voilà pour la propagation de l'information dans un réseau de neurones.

Passons à la suite.
# Section 4 : Type d'architecture des résaux de neurones.
## Perceptron à une couche
Passant en revue les différents types d'architecture de réseaux neuronaux.

Le premier type et le plus simple est le modèle de percée.

Entrons dans les réseaux neuronaux.

Les réseaux neuronaux ont deux unités d'entrées et une unité de sortie sans couches cachées.

Ils sont également connu sous le nom de percée de trous à couche unique.

Voilà pour les perceptions à couches uniques.

Les suivants sont les réseaux neuronaux à fonction de base radiale.
## Réseau à base radiale
Parlons maintenant du réseau neuronal à fonction de base radiale.

Ces réseaux sont similaires au réseau neuronal à action directe.

Sauf qu'on a des nœuds cachés et que la fonction de base radiale est utilisée comme une fonction d'activation

de ces neurones.

Alors qu'est ce qu'une fonction d'activation?

La fonction d'activation, c'est celle qui décide.

C'est un neurone doit être activé ou non.

Dans le cas du réseau neuronal à fonction de base radiale, la fonction de base radiale et la fonction

d'activation utilisées, cette fonction assigne une valeur à toutes les entrées et la valeur produite

est toujours une valeur absolue.
## Perceptron à plusieurs couches
Maintenant.

Parlons des pères, ces patrons à plusieurs couches.

Ces réseaux utilisent plus d'une couche cachée de neurones.

Contrairement aux percés, patrons accouchent unique que nous avons vu tout à l'heure.

Ils sont également connu sous le nom de réseaux neuronaux profonds à anticipation.

Ils possèdent une couche d'entrée et une couche de sortie.

Mais là ou ils sont différents, c'est qu'ils ont plusieurs nombre de couches cachées.

On sait que les couches cachées sont les véritables couches computationnelle de l'algorithme.

C'est donc là qu'il y aura le plus de calcul.

C'est tout.

Pour, les percées passeront à plusieurs couches.

Passons maintenant aux réseaux neuronaux récurrents.
## Réseau de neurones récursif (RNN)
Les réseaux neuronaux récurrents traitent la mémoire.

La valeur d'un neurone de couches cachées et la combinaison des données qu'il reçoit de la couche précédente

et de sa valeur précédente.

La valeur précédente contribue à la valeur actuelle et c'est justement ça qui permet le réseau neuronal

de traiter la mémoire.

Pour résumer, un réseau neuronal récurrent est un réseau neuronal artificiel qui peut être utilisé

pour analyser des données qui utilisent le temps ou les données qui utilisent des séries.

Quand on utilise un algorithme ordinaire de propagation avant, tu as besoin d'avoir beaucoup de points

de données indépendantes.

Mais si les données sont arrangées pour que tous les points de données soient dépendants de leur point

précédent, il faudra prendre en compte ces interdépendances dans notre algorithme.

Et cette mémoire, dont on a parlé précédemment pour le réseau neuronal récurrent, permet de garder

en mémoire les entrées d'avant pour sortir une nouvelle sortie dans la suite.
 
## Cellules LSTM (Long Short Term Memory)
Viennent ensuite les réseaux neuronaux à mémoire à long court terme qu'on appelle MLCT ou LSTM en anglais

long short term memories.

Le type de réseau neuronal dans lequel la cellule de mémoire est incorporée dans les neurones de la

couche cachée est appelé réseau neuronal à mémoire à long court terme.

Le MCT est un cas particulier du réseau neuronal récursif.

Ce type particulier peut apprendre des dépendances long terme en utilisant un réseau de mémoire à court

terme.

Comme on l'a vu précédemment, Haug Writer et Schmidt Huber en 1997 l'ont créé et beaucoup l'ont repris

par la suite.

Le MCT est utilisé et beaucoup utilisé parce que très utile sur beaucoup de problèmes.

Il n'y a pas de problème avec la dépendance à long terme par définition.

Voilà pour le MCT.

Et maintenant passons à la suite.
## Réseau de Hopfield
Maintenant.

Parlons des réseaux Hope Field.

Les réseaux Hope Fields sont un type particulier de réseaux de neurones récursifs.

Il s'agit d'un réseau de neurones entièrement interconnecté, dans lequel chaque neurone est connecté

à tous les autres neurones.

Le réseau est entraîné avec des modèles d'entrée.

En fixant une valeur de neurones aux modèles désirés.

Ensuite, ces poids sont calculés par des algorithmes de deep learning.

Les poids ne sont pas modifiés une fois formés pour un ou plusieurs modèles.

Le réseau converge vers les modèles appris.

Il est différent des autres réseaux de neurones.

Voilà pour les réseaux Holyfield.

Passons maintenant au prochain corps.
## Machine de Boltzmann
Le dernier type de réseau est la machine de Boltzmann.

Ce réseau est similaire au réseau Hope Field, sauf que certains neurones sont directement connectés

aux entrées pendant que d'autres ne sont pas du tout connectés directement aux entrées.

Les POI sont initialisée aléatoirement et apprennent grâce à l'algorithme de rétro propagation.

OK.

Donc pour résumer, le réseau neuronal de la machine de Boltzmann est aussi un type de réseau neuronal

récursif.

C'est un agrégat de nœuds qui font des décisions binaires et sont prédisposés dans un certain biais.

Voilà pour les machines de Boltzmann.

Passons maintenant au prochain cours.
# Section 5 : Fonctions d'activation.

## Qu'est ce qu'une fonction d'activation?
Notre prochain thème est un des éléments crucial du deep learning et du machine learning.

Ce sera à propos des fonctions d'activation.

Alors que fait la fonction d'activation?

La fonction d'activation est une fonction qui est ajoutée à un réseau neuronal artificiel pour aider

le réseau à apprendre des modèles complexes dans les données.

Si l'on compare avec un modèle basé sur les neurones qui se trouve dans notre cerveau, la fonction

d'activation décide à la fin de ce qui doit être renvoyé au neurone suivant.

Elle prend le signal de sortie de la cellule précédente et le convertit en une forme qui peut être utilisée

comme une entrée pour la cellule suivante.

C'est une transformation non linéaire que nous faisons pour les entrées que nous recevons avant de les

envoyer à la couche ou au neurone suivant.

La fonction d'activation également connue sous le nom de fonction de transfert.

En gros, la fonction de transfert peut être classée en deux catégories la fonction de transfert linéaire

et la fonction de transfert non linéaire.

En termes simples, sans fonction de transfert, le signal de sortie sera une fonction linéaire comme

un polynôme de un degré ou un modèle de régression linéaire.

Attention.

Il faut garder en mémoire qu'ils ont moins de pouvoir pour apprendre la cartographie fonctionnelle complexe

des données.

La fonction d'activation capture une relation non-linéaire entre les entrées et convertit également

les entrées en sorties utiles.

Mais notre cerveau fonctionne de manière non linéaire pour des calculs complexes.

La robustesse et un parallélisme élevé.

La capacité à gérer des informations imprécises et flous.

Donc, pour imiter cela, nous avons besoin d'une fonction d'activation pour travailler dans les grands

ensembles de données compliquées, de hautes dimensions et non linéaires, qui ont une architecture

compliquée.
## Terminologie Importante
Pour comprendre les fonctions d'activation non linéaire, nous avons besoin de quelques terminologies.

Premièrement, la fonction différentielle, ça représente les changements de la fonction au niveau de

l'axe des i par rapport au changement de l'axe des X.

Donc en gros, c'est la pente, une fonction monotone quand une fonction croît sur tout son domaine

ou décroît sur tout son domaine.

On dit que la fonction est monotone.

Maintenant nous allons voir tous les types de fonctions d'activation.
## Fonction sigmoïde
Passons en revue les points de la fonction sigmoïde que nous devons garder à l'esprit.

Les caractéristiques importantes à garder à l'esprit sont un.

La fonction est supérieure ou égale à zéro et inférieure à un.

Deux.

La fonction est comprise entre zéro et un.

Donc particulièrement utile pour les modèles ou on doit prédire une probabilité comme sortie.

Trois.

Elle est différentiable.

Cela signifie que nous pouvons trouver la pente en deux points quelconques.

Quatre.

C'est une fonction monotone.

Cinq.

Il faut savoir que cette fonction n'est pas très utile dans la vraie vie parce qu'elle est lourde en

calcul.

Elle n'est pas centrée en zéro, donc elle va être en sortie seulement positive ou seulement négative.

Et on a aussi un problème de gradient de fuite.

Les réseaux neuronaux artificiels sont entraînés par la méthode du gradient n et par propagation.

Donc les poids.

Ils vont recevoir une mise à jour proportionnelle à la dérivée partielle de la fonction erreur et en

fait le gradient.

Ensuite, c'est quand le gradient devient trop petit pour changer le poids.

Voilà pour la fonction sigmoïde.

Passons maintenant à la suite.
## Fonction tangente hyperbolique
On regarde maintenant la fonction tangente hyperbolique.

Certains points importants de la fonction tangente hyperbolique sont un.

Il s'agit d'une meilleure version de la fonction sigmoïde puisque la plage cette fois est de -1 à plus

un, donc elle va en dessous de zéro, contrairement à la fonction sigmoïde qui allait de 0 à 1 deux.

C'est une fonction comme la sigmoïde différentiable et trois monotone et celle ci a une autre application

en quatre.

Elle est utilisée pour les problèmes à deux classes.

On marque fortement les valeurs négatives et fortement les valeurs positives ou même les valeurs en

zéro puisque on va vite arriver à quelque chose qui donne un.

Et ensuite, dès qu'on sort de ou un peu loin, on arrive directement à zéro.

Puis, dès qu'on sort un petit peu de zéro, on arrive directement à un.

Donc cette fonction va être utilisée dans les réseaux en propagation avant pour augmenter la différence

entre les sorties.
## Fonction softmax
Parlons maintenant de la fonction soft max.

C'est une fonction d'activation particulière.

Elle fonctionne dans la couche de sortie.

Deux.

Il faut appliquer une fonction exponentielle standard à toutes les valeurs de la couche de sortie,

puis effectuer la normalisation en divisant la somme de toutes les exponentielles.

Et en fait, quand on somme toutes les valeurs, on aura une somme égale à un.

Trois.

Pour les applications, on peut l'utiliser pour implémenter des probabilités ou des scores de confiance

pour chaque attribut.

Pour l'utiliser dans les problèmes de classification multi classes.

Quatre.

C'est une fonction différentiable comme les fonctions précédentes.

Voilà pour la fonction soft max.

Passons maintenant au prochain cours.
## Fonction Unité Linéaire Rectifiée (ou ReLU)
Parlons maintenant de la fonction R?

U ou relue.

La fonction unitaire linéaire rectifiée si la valeur est inférieure à zéro.

La fonction est nulle, sinon la fonction devient le nombre.

Cette fonction est la plus utilisée dans les réseaux neuronaux qu'on voulût tif dont on parlera plus

tard dans ce cours, et de nombreuses approches de deep learning l'utilisent parce qu'elles ne posent

pas de problème de gradients de fuites.

Trois.

C'est une fonction différentiable, mais quatre.

Attention, ce n'est pas une fonction monotone.

Cinq.

L'étendue de cette fonction est de zéro à l'infini.

Mais si c'est un inconvénient, si une valeur est inférieure à zéro, la fonction la ramène automatiquement

à zéro.

Ce qui fait que la valeur négative n'est pas représentée correctement.

Et donc notre réseau neuronal n'apprend rien de ses neurones et conduit également à un nœud instable.

Voilà pour le relu.

Passons maintenant à la suite.
## Fonction d'activation Leaky ReLU
Nous avons vu précédemment comment fonctionne.

d'Activation la fonction relu.

Fonction unitaire linéaire rectifiée et nous allons voir maintenant la fonction d'activation relue.

Fuyard, sais tu?

C'est une fonction avancée de relue qui résout l'impact négatif de la fonction relue, c'est à dire

qu'elle n'est pas directement à zéro au niveau des valeurs négatives.

On a une légère pente de A et deux.

Habituellement, la valeur A dans le diagramme ci dessus est autour de 0,01 seulement.

Trois.

La gamme de la revue Fuyard et de l'infini à plus l'infini.

Quatre.

C'est une fonction différentiable.

Cinq.

Une fonction aussi monotone.
# Section 6 : Algorithme du gradient (gradient descent) avec Python 
## Qu'est-ce que la Descente de Gradient ?
Nous allons maintenant nous intéresser à qu'est ce qu'une descente de gradient?

Nous en avons parlé précédemment, mais nous ne savons pas encore exactement ce que c'est.

La partie la plus incroyable du machine learning, c'est qu'il peut apprendre de lui même.

Donc on va comprendre comment un réseau ajuste ses poids et apprendre soi même.

La descente de gradient et la technique d'optimisation la plus utilisée en deep learning et en machine

learning.

Elle trouve la valeur des paramètres d'une fonction qui minimise une fonction coup au maximum.

On initialise d'abord les paramètres et ensuite le.

La descente de Gradignan utilise des calculs pour itérative.

Ajuster les valeurs pour minimiser la fonction coût.

On suppose que notre graphe sur l'écran est la fonction coût de notre modèle.

Les points bleus sont différents à chaque itération pour lesquels on a mis des poids différents.

On aura une fonction coup différente à chaque point parce qu'on a changé les poids à chaque itération.

On prend une valeur de base et ensuite on applique la formule à l'écran.

B égal à A.

Moins gamma.

Fois le gradient de f de a ou a et la position actuelle gamma.

Le facteur de correction.

Et Gravillon Le Gradlon.

De la position de départ, on avance ou on recule.

Et la taille de notre PA dépendent du gamma de la fonction.

Elle peut aussi être déterminée par le gradient ou la pente.
## Qu'est-ce que la Descente de Gradient Stochastique ?
Le problème de la descente de gradient, c'est que cette méthode ne fonctionne que dans le cas d'une

fonction convexe.

On peut voir une fonction non convexe à l'écran qui ne pourra pas permettre une descente de Gradignan.

On a plusieurs minimums locaux.

Dans ce cas là, la descente de gradient, on ne va pas trouver le minimum optimal mais seulement un

minimum local.

On peut dans ce cas là utiliser la descente stochastique.

Dans ce terme stochastique, il y a une partie aléatoire.

En effet, dans la descente de gradient en stochastique, on trouve le gradient de la fonction d'une

seule entrée à chaque itération au lieu de la somme des gradients en deux.

La fonction coût de toutes les sorties.

On utilise donc seulement une donnée de l'ensemble des données.

Le chemin utilisé est plus bruité que celui de la descente de Gradignan, mais ce n'est pas important

parce que ce n'est pas le chemin qui est important, mais le minimum trouvé et la vitesse d'entraînement

de l'algorithme.
## Descente de Gradient vs Descente de Gradient Stochastique
La seule différence entre la descente de Gradignan et la descente de Gradignan stochastique est que dans la descente de Gradignan, nous allons prendre toutes les données.

Les branchés dans notre modèle de réseau.

Puis trouver la valeur de sortie et ensuite corrélée avec la valeur réelle.

Trouver la fonction de coût puis revenir par réseau de rétro propagation.

Ajuster les poids.

Et continuer pour différentes valeurs.

Parmi eux, nous trouverons les valeurs minimales de la fonction coût.

Par contre, pour la descente de Gradignan stochastique, nous suivons les mêmes étapes que pour la

descente de Gradignan.

Une seule différence, c'est que, au lieu d'appliquer tous les échantillons, nous allons le faire

pour chaque ligne séparément et mettre à jour les poids.

Donc, s'il y a beaucoup de données, l'algorithme de descente de gradient sera très long.

Dans ce cas, l'algorithme de descente de gradient en stochastique serait le plus rapide.
# Section 7 : Présantation sommaire des résaux de neurones
## Comment fonctionnent les réseaux de neurones artificiels ?
Comment marche un réseau avant de passer à l'implémentation.

Résumons un petit peu.

D'abord, rappelons nous comment fonctionnent les réseaux neuronaux artificiels.

Un réseau consiste en un certain nombre d'éléments simples mais hautement interconnectés, appelés nœuds

ou neurones.

Ces neurones sont organisés en couches qui traitent l'information de manière dynamique quant aux entrées.

La première couche est appelée couche d'entrée.

La dernière est appelée couche de sortie.

On suppose qu'on doit calculer le prix de la maison et qu'on n'a pas de couches cachées.

Le prix sera simplement la somme des entrées pondérées.

C'est une approche de type machine learning.

On ira donc regarder par exemple en entrée le nombre de chambres, la distance à la ville, l'âge de

la propriété, l'hôpital pour les enfants, les écoles pour les enfants.

Le prix de la maison sera alors la somme des entrées multipliée par leur poids.

Ce qui rend le deep learning supérieur au machine learning, c'est l'adjonction d'une couche cachée

qui donne de la puissance et de la flexibilité pour améliorer la qualité de l'estimation.

Prenons l'exemple précédent, mais avec un réseau de neurones artificiels, tous les neurones d'entrée

sont connectés au neurone de la couche cachée, ce qui veut dire qu'on n'aura pas la même pondération

de la part de la couche d'entrée.

Ce qui signifie qu'en fonction des priorités de pondération, les valeurs changent.

Chaque neurone dans la couche cachée a des priorités et des pondérations qui lui sont affectées.

Ce fonctionnement est proche de celui de notre cerveau.

Si on continue d'ajouter des couches cachées pour résoudre des problèmes complexes, la précision s'améliore.

C'est comme ajuster parfaitement le réseau pour avoir le résultat optimal.

Sur l'écran, vous pouvez voir le détail du travail d'un réseau de neurones artificiels.

Un.

Chaque neurone de l'entrée a une valeur qui correspond à une donnée.

Ensuite, en deux, on additionne toutes ces données avec leur certain poids.

Trois.

On met tout ça dans une fonction d'activation pour transformer en une autre valeur ces valeurs.

Ici, on a choisi une fonction d'activation de type sigmoïde, comme nous l'avons présenté précédemment.

L'étape quatre, nous avons une sortie de la fonction d'activation qui est donnée au prochain neurone

et ainsi de suite jusqu'au neurone de sortie.

Voyons maintenant les avantages et inconvénients des réseaux de neurones artificiels.
## Avantages des réseaux de neurones artificiels
On a vu les réseaux de neurones artificiels pendant les cours précédents.

Quels sont leurs avantages?

Un.

Les réseaux de neurones artificiels ont la capacité de travailler avec des données lacunaires.

Quand il est entraîné, il peut sortir des sorties, même sans certaines informations.

La perte de performances dépend de l'importance de la perte d'informations.

Deux.

Il a une tolérance aux fautes.

Peu importe si le réseau est corrompu sur une ou plusieurs cellules, le réseau ne stoppera pas la génération

d'une sortie.

Trois.

Il a la capacité de traiter en parallèle.

Le réseau de neurones artificiels peut faire plusieurs travaux à la fois.

Maintenant, passons au désavantage.
## Inconvénients des réseaux de neurones artificiels
Les désavantages.

Un.

La dépendance au hardware.

Les réseaux de neurones artificiels ont besoin d'un processeur qui peuvent travailler en parallèle par

définition de leur structure.

Donc du coup, il va falloir un processeur avec plusieurs coeurs.

On dépend donc beaucoup du matériel dont on dispose.

Deux.

La nécessité de déterminer la bonne structure de réseau.

Il n'y a pas de règle spécifique.

Il faut donc faire des expériences et on trouve le bon réseau, principalement par essais erreurs.
## Applications des réseaux de neurones artificiels
Regardons maintenant les applications des réseaux de neurones artificiels.

Il y a plein d'applications.

Certaines sont notamment la reconnaissance d'écriture, la compression d'images, les fluctuations du

marché.

Pour la reconnaissance d'écriture.

En effet, c'est très important.

Surtout que maintenant, en ce moment, on utilise beaucoup les iPad.

Notre book tablette, c'est quelque chose de très populaire et on peut utiliser des réseaux de neurones

pour reconnaître notamment des caractères écrits à la main.

La compression d'images.

Beaucoup d'informations sont arrivées et sont traitées par les réseaux de neurones dans le système.

Avec l'explosion d'Internet, on utilise de plus en plus d'images et les réseaux de neurones pour la

compression d'images devient très intéressant, surtout sur les sites Internet.

On peut aussi analyser les fluctuations du marché, qui sont très compliquées.

On ne peut jamais savoir si le market va monter ou descendre au jour le jour.

Par contre, on peut entraîner un réseau de neurones pour examiner beaucoup d'informations très vite.

Et peut être prévoir l'évolution des prix au fur et à mesure des jours, des heures ou des minutes.

C'est l'heure du quiz.

Selon vous, quelle est la définition la plus appropriée de la propagation rétrograde parmi les options

données dans la diapositive?

Prêts avec votre réponse.

La réponse est c'est comme nous l'avons appris dans ce court.

J'espère que vous comprenez maintenant comment les réseaux neuronaux artificiels fonctionnent théoriquement.

Apprenons maintenant l'implémentation de réseaux neuronaux à travers le codage Python.
# Section 8 : Implémentation d'un RNA en Python 
## Introduction
Pour l'implémentation en Python, je vais utiliser un ensemble de données ou dataset issues de la modélisation

de churn.

Vous pouvez télécharger le DataSet à partir de Kagel.

Les réseaux neuronaux artificiels peuvent être utilisés aussi bien pour la classification que pour la

régression.

Nous allons ici utiliser les réseaux neuronaux artificiels pour la classification.
## Exploration de la base de données
Maintenant vous avez téléchargé le dataset.

Vous pouvez double cliquer dessus pour voir ce qu'il y a dedans.

Cet ensemble de données a lie des clients le nom, le pointage de crédit, la géographie, le sexe,

l'âge, la durée, le solde, le nombre de produits qu'ils utilisent de la banque comme la carte de

crédit ou le prêt, et cetera.

A une carte de crédit ou non.

Un signifie oui.

Zéro signifie nom et membre actif.

Cela signifie que le client utilise la banque ou non et le salaire estimé.

Ce sont toutes les variables indépendantes de l'ensemble des données churn modeling.

La dernière caractéristique est la variable dépendante et c'est à dire que le client a quitté ou non

la banque.

Un signifie que le client quittera la banque et zéro signifie que le client reste dans la banque.
## Énoncé du problème
La banque utilise ces variables indépendantes et analyse le comportement des clients pendant six mois,

qu'ils quittent la banque ou restent et créent cet ensemble de données.

Maintenant, la banque doit créer un modèle prédictif basé sur cet ensemble de données pour les nouveaux

clients.

Ce modèle prédictif doit prédire pour tout nouveau client qu'il restera à la banque ou qui quittera

la banque.

Ainsi, cette banque peut offrir quelque chose de spécial aux clients dont le modèle prédictif prédit

qu'ils quitteront la banque.

J'espère maintenant que vous avez compris l'énoncé du problème.
## Prétraitement des données
Ainsi, la première étape de mise en œuvre d'un réseau de neurones artificiels en Python est le prétraitement

des données.

C'est le fait de transformer les données brutes en un ensemble de données bien formées pour que le machine

learning et le deep learning par les algorithmes puissent être appliqués.

Il y a de librairies importantes en Python pour faire du traitement de données.

Trois d'entre elles sont affichées à l'écran.

Numbi est une bibliothèque Python open source utilisée pour effectuer diverses tâches mathématiques

et scientifiques.

Nomme.

Pi est utilisé pour travailler avec des tableaux ou array.

Il a également des fonctions pour travailler dans le domaine de l'algèbre linéaire, de la transformée

de Fourier et des matrices.

Math Plot Lib est une bibliothèque de traçage qui est utilisée pour créer une figure, tracer une zone

dans une figure, tracer quelques lignes dans une zone de traçage, décorer la parcelle avec des étiquettes,

et cetera.

Panda.

Et d'un outil utilisé pour la discussion et l'analyse de données.

Si vous n'avez pas Python installé sur votre PC, vous pouvez aller sur www.

Anaconda Point com qui possède Python et des librairies utiles pour la manipulation de données.

Installer Anaconda, c'est c'est installer Python.

Jupiter et les librairies telles que Panda, Numbi et Maps.

Plate libre sur votre machine.

Nous allons travailler sur Jupiter Notebook.

Jupiter Notebook est une application basée sur le Web.

Elle vous permet d'écrire, de lancer le code, avoir des visuels et des textes narratifs sur la même

page.

Nous allons utiliser Anaconda Distribution pour 7Up Jupiter Notebook sur notre machine.

Après avoir installé Anaconda, j'ai cherché Anaconda Navigator dans votre barre de recherche et ouvrez

le dans le programme Anaconda ou Anaconda Navigator.

Il y a une Tab qui s'appelle Jupiter.

Lancer l'application en cliquant sur Launch.

Ça lancera Jupiter dans votre application Web.

Cliquez sur New et Python trois pour créer un nouveau notebook.

Maintenant, nous importons les différentes librairies.

Im Port Numbi az np.

In porte matt.

Pilote lib by plot has plt.

Importe PEN this has PD.

Cliquez sur Run.

Donc à l'étape un, nous avons emporté toutes les bibliothèques requises.

Maintenant l'étape suivante, nous allons devoir importer nos données dans Python.
## Chargement de la base de données
On importe l'ensemble des données en utilisant une fonction qui s'appelle READ qui irait du bas csv

dans la librairie Panda.

On écrit dataset égal pd point read tirée du bas csv.

Ouvrez la parenthèse.

Ouvrez les guillemets.

Churn modeling.

Fermez les guillemets.

Fermez la parenthèse.

On vient de créer une variable qui s'appelle DataSet dans laquelle on a rangé tout notre ensemble de

données qui s'appelle Churn Modeling BW, csv.

Comme vous pouvez le voir dans le jeu de données, il y a treize variables indépendantes et une variable

dépendante.

Mais les trois premières variables indépendantes.

Numéro de ligne ID, client et nom de famille sont inutiles pour notre prédiction car elles ne nous

donnent aucune information sur le fait que les clients vont ou non partir de la banque.

Nous élimineront donc ces trois variables indépendantes à l'étape suivante et nous allons également

diviser les variables indépendantes en X et une variable dépendante en Y.
## Séparation de la base de données en variables dépendantes et indépendantes.
Pour séparer les ensembles de données entre variables indépendantes et dépendantes, on doit écrire

x dataset.

Point.

Il hoche.

Ouvrez le crochet deux point virgule trois 2.13.

Fermer le crochet point Valouse.

I égalent data sept points.

Il lock.

Ouvrez le crochet deux point virgule treize.

Fermé le crochet.

Points valise.

Point.

Il lock est utilisé quand l'index label et autre chose qu'une série numérique de zéro un deux trois

n ou quand l'utilisateur ne connaît pas l'index.

Pourquoi est ce qu'on a écrit dataset?

Il lock crochet deux point virgule trois de points treize crochets.

Points values.

Parce que le credit score a une valeur d'index de trois.

Et nous voulons des fonctionnalités qui partent de crédit score, a estimé Todd Sillery.

Dans cette ligne de code, nous prenons toutes les valeurs de 3 à 13, sans inclure treize.

I prend toutes les valeurs de la colonne numéro treize.

Pour mieux comprendre, on affiche X sur l'écran, on écrit Print.

Ouvrez la parenthèse X, fermez la parenthèse et voilà, on a toutes les informations qu'on veut.

Maintenant pour voir ce qu'il y a dans I, on écrit print.

Ouvrez la parenthèse I fermez la parenthèse.

Comme prévu, on a tous les éléments de la colonne treize y représente la variable dépendante.

On a donc que X et l'ensemble de données de crédit score, a estimé Teresa Lowery.

Et Y les bulletins de sortie.

Maintenant, nous avons divisé notre ensemble de données en X et Y.

Passons à la prochaine étape.
## Codage d'étiquette avec Scikit-Learn
Pourquoi l'encodage est il nécessaire?

Parce que, comme nous pouvons le voir, il y a deux variables catégorielles qui ne sont donc pas numériques.

On a la géographie et le sexe.

Nous devons donc encoder ces variables catégorielles dans certaines étiquettes telles que zéro pour

femmes et un pour hommes pour le genre.

Et un encodage à chaud pour la variable géographique qui est un encodage légèrement différent.

Ici, chaque valeur est représentée comme on arrête un tableau grâce à la librairie SK Learning.

On peut encoder comme on veut.

Très efficace comme librairie, notamment pour la classification, le clustering, le modeling pour

les States, les régressions, et cetera.

Sur l'écran, vous pouvez voir qu'on importe le label encodé et le one hot encodé de la librairie Escale

Learning Point, près Processing.

Notre objectif est de transformer les valeurs string des genres en valeurs numériques en utilisant le

label encodé dans la ligne deux.

On a créé un objet nommé label encodeur tiré du bas X tiré du bas deux de la classe La Belle Encodeur.

Dans la dernière ligne à gauche de l'équation, on applique une valeur à la troisième colonne de la

variable x.

A droite, on utilise la fonction Phi transforme de la classe label en codeur qui retourne une valeur

numérique depuis une chaîne de caractères.

Dans notre cas, on va remplacer des genres mâle et femelle, mais il faut.

Mail par des nombres zéro un.

Donc, après avoir effectué l'encodage d'étiquettes sur la variable genre, hommes et femmes sont convertis

en zéro et un.

Allons sur le jeep est un notebook pour voir comment ça marche.

On écrit from.

Est ce qu'à un point près processing import label encodeur.

Virgule One Hot Encoder.

La belle en CO2 tiré du bas X tirée du bas deux égales.

Label encodeur.

Entre parenthèses.

X.

Ouvrez les crochets deux point virgule deux.

Fermé les crochets.

Égal la belle encodeur tiré du bas x tiré du bas.

Deux points fixes.

Tiré du bas transforme.

Pour ouvrir Parenthèse X, ouvrez le crochet deux point virgule deux ferme et le crochet fermé, la

parenthèse affichant les valeurs de X qui représentent les variables indépendantes de notre modèle.

Zéro représente la femme et un représente l'homme.

Maintenant, nous avons une autre variable catégorielle et c'est la géographie.

Maintenant, nous allons donc effectuer un encodage à chaud pour convertir la France, l'Espagne et

l'Allemagne en formes de zéro et un.

Voyons comment nous pouvons faire cela.
## Encodage one-hot avec Scikit-Learn
Pour faire un encodage à chaud, on va avoir besoin de l'aide du colon transformé et de la OneNote Encoder.

Ouvrez les parenthèses de la librairie.

Est ce calé?

Passons à Jupiter pour voir comment ça marche.

Pour importer OneNote Encoder, on écrit from ait scalaire compose import colonnes transformant.

Puis on écrit C'était égal, colonnes transformant.

Ouvrez les parenthèses, ouvrez les crochets.

Ouvrez les guillemets œ comme OneNote Encoder.

Fermez les guillemets virgules.

OneNote.

Encoder.

Ouvrir la parenthèse.

Ferme la parenthèse.

Virgule.

Ouvrez le Rocher.

Un.

Fermez le crochet.

Fermé, inventé, fermé.

Crochet.

Y a gueule.

Remis d egal.

Ouvrez les guillemets.

Pas trop fermer les guillemets.

Fermer la parenthèse.

On crée un objet de la classe.

Colonnes transformées.

Mais avant de pouvoir faire ça, on doit comprendre que le constructeur de colonnes transformé prend

plusieurs arguments.

On a besoin que de deux de ces arguments on prend un arrêt nommé Transformer qui est une liste de tuples.

C'est arrêt, donc ce tableau prend en argument.

Ces éléments.

Un.

Le nom.

Un nom pour le colon transformé qui rend la recherche du colon transformée et des paramètres plus simples.

Deux.

Le transformer qui donne un estimateur.

On peut toujours ajuster.

Juste passer dessus ou abandonner les données.

Mais comment veux encoder les données?

Dans cet exemple, on utilisera le OneNote Encoder.

Le transformateur doit supporter les fuites et transforme.

Trois.

La colonne, c'est la liste de colonnes qu'on veut transformer.

Ici, on ne transforme que la première colonne.

Quatre.

Le Roumain D.

Ça dira au Transformers ce qu'il doit faire avec les autres ensembles de données.

Par défaut seulement, les données qui ont été transformées seront retournées par le transformées.

Les autres seront juste lâchées.

On aura la possibilité de dire aux transformer.

Que faire avec les autres colonnes?

On peut soit les laisser tomber, soit les laisser inchangés ou specifier un autre estimateur si on

veut faire un peu plus de pré processing.

Comme vous pouvez le voir, on nomme le transformateur simplement.

Oh heu.

Comme One Hot Encoder, on utilise le constructeur One Hot Encoder pour donner une nouvelle instance

des estimateurs.

Et on dit que seulement la colonne un est changée et que toutes les autres devront lester.

Pas de trou, donc laissé sans changement.

Continuons avec le code.

X égal M.P.

Point arrêt.

Ouvrez la parenthèse CT.

Points fixes tiré du bas transforme.

Ouvrez la parenthèse X.

Fermer la parenthèse virgule dix TIP égale NP point STR.

Fermer la parenthèse X égal x ouvrait les crochets.

Deux points virgules.

Un deux points.

Alors.

Que faisons nous ici une fois que nous avons construit le côlon transformé?

Nous devons changer le data set pour Label Encode, donc encoder étiquettes et OneNote encode donc en

codage à chaud la colonne.

Pour ce faire, nous avons notre troisième ligne de code.

On prend le data set X et on transforme les valeurs des attributs de géographie pour avoir des valeurs

numériques utilisables pour le One Hot Encoder.

Ce code prend toutes les valeurs du data set transformer X et le transforme en tableau.

Toutes les valeurs sont converties en string en utilisant this type égal np, pw, str.

Dans la dernière ligne, quand on écrit x, x ouvrait les crochets deux point virgule 2.1 fermé.

Crochet.

On ignore le premier index car la même information peut être faite de l'index un et deux.

Par exemple, les valeurs de un et deux sont zéro.

Alors la valeur qu'on a perdue et un.

Comme géographie, il ne peut avoir qu'une seule localisation.

On a réussi à réduire un neurone d'entrée sans perdre de l'information.

Maintenant, affichons X pour voir ce que ça nous donne.

On a cette sortie.

Les deux premières colonnes sont notre encodage à chaud de la géographie.

Zéro zéro veut dire français, zéro un veut dire Espagne, un zéro veut dire Allemagne.

J'espère maintenant que c'est clair comment nous pouvons transformer des données catégorielles en données

numériques sous forme de zéro et de un, comme nous l'avons fait ici pour la géographie.

La prochaine étape consiste en le fait de séparer les données en des données d'entraînement et des données

de tests.

Passons à la suite pour voir comment nous pouvons faire ça.
## Ensembles d'apprentissage et de test : Fractionnement des données
Pour construire un modèle d'apprentissage automatique, nous devons former notre modèle sur le plateau de formation.

Et pour vérifier les performances de notre modèle, nous utilisons un ensemble de tests.

C'est pourquoi nous devons diviser les ensembles de données X et Y en ensembles, formations et ensembles tests.

Les données d'entraînement dans le sens de formation sont les données qui permettent de former l'algorithme de machine learning.

Les data scientists donnent à manger à l'algo les données d'entrée qui correspondent à un résultat attendu pour certaines données.

L'algo analyse les données et les résultats pour apprendre de lui même et créer un modèle attendu après que le modèle soit créé.

Les données de tests permettent de vérifier que le modèle peut faire des prédictions correctes.

Il s'agit de la comparaison de la compréhension de l'algorithme et du vrai monde.

En effet, il se confronte à des données encore jamais vues, ce qui permet de confirmer ou non le modèle créé.

C'est pour cela qu'il faut séparer les données en formation, entraînement et tests.

Lors de la division en ensembles de formation et de tests, vous devez vous rappeler que 80 % à 90 % de vos données doivent figurer dans les tests d'entraînement et donc le reste en données tests.

Pour l'implémentation, nous allons utiliser la méthode Train Test Split de la librairie SK Learning Model tiré du BAT Sélection.

Allons voir dans Jupiter.

D'abord on emporte la librairie from.

Est ce qu'a learning pw model tiré du bas?

Sélection.

Import train tiré du bas.

Test tiré du bas.

Split puis on écrit X tiré du bas train virgule x tiré du bas.

Test virgule i tiré du bas train virgule i tiré du bas test égal.

Train qui du Battesti a du ba split.

Ouvrez la parenthèse X, règle y vis a girl test tirée du bas size egale 0,2 virgule random tiré du bas state egale zéro.

Fermez la parenthèse.

Ici, on a quatre variables.

Xtrem XT y traîne, y teste.

Nous allons séparer X dans les deux premières et I dans les deux dernières.

On a mis.

Test size 0,2.

Ce qui veut dire que nous allons prendre 20 % de l'échantillon comme test et 80 % comme formation.

De plus, on a mis Random States à zéro, ce qui veut dire qu'on ne choisit pas à toi vraiment les lignes

utilisées, ce qui nous permet d'avoir toujours les mêmes résultats en relançant l'algorithme.

Maintenant, nous avons divisé notre ensemble de données en X-Trail, XTC, I Train et I Test.
##  Le Feature Scaling
L'étape suivante consiste donc à mettre à l'échelle les fonctionnalités.

Comme vous pouvez le voir dans le jeu de données, toutes les valeurs ne sont pas dans la même plage.

Certains sont de 0 à 1, d'autres de 0 à 100, d'autres de 0 à 1000.

En particulier, par exemple, estimateur salary.

Il est assez évident que votre salaire n'est pas compris entre zéro et un.

Et cela demande donc beaucoup de temps de calcul.

Donc, pour surmonter ce problème, nous effectuons une mise à l'échelle des fonctionnalités.

>Une chose que vous devez vous assurez de toujours effectuer une mise à l'échelle des fonctionnalités dans le deep learning.
>Peu importe l'intervalle des données que vous avez.

Commençons pour voir comment nous pouvons faire en Python.

On écrit from.

Est ce qu'à l'heure pris.

Processing?

Import standard scanner.

Essai égal standard scalaire.

Ouvrez les parenthèses.

Xtrem égale SC point feet tirée du bas transforme.

Ouvrez les parenthèses.

X tiré du bas train.

Fermer la parenthèse.

X tiré du bas test égal et ces transforme, transforment, ouvrir.

Parenthèse x tiers du bas test.

Fermer la parenthèse.

En Python, on utilise la classe standard de mise à l'échelle standard scalaire.

Puis nous avons créé l'objet SC de la classe emporté.

Dans la troisième ligne, on utilise la fonction feed tirée du bas transforme.

Comme précédemment, elle prend X tirée du bas train en entrée puis.

Mais à l'échelle toutes les valeurs de x tiret du bas trame et retournent un tableau.

On fait de même pour X, y a du test.

La différence c'est qu'on utilise filtre tiré du bas transforme pour x tiers du train et seulement Transform

pour x test.

On le fait parce qu'on apprend les paramètres de la mise à l'échelle sur les données d'entraînement

et en même temps on va mettre à l'échelle les données alors que pour le data test, on peut utiliser

les données de la mise à l'échelle utilisée précédemment.

Donc on n'a plus qu'à les transformer.

On n'a plus besoin de l'EFI.

La mise à l'échelle des fonctionnalités nous aide à normaliser les données dans une plage particulière,

par exemple 0 à 1.

Après avoir mis à l'échelle les fonctionnalités, toutes les valeurs sont normalisées et maintenant

utilisables.

Confirmant ça dans Jupiter import panda SPD print X tiré du bas train, ça m'importait.

Ici on a un tableau pour avoir un data frame, on doit écrire PD point.

Data frame.

Entre parenthèses x.

Tirets du bas trait.

Et voilà, comme prévu, vous pouvez le voir.

Toutes les valeurs ont été bien mises à l'échelle.

OK, passons à la suite.
## Construction du réseau de neurones artificiels
Maintenant, nous avons terminé avec les étapes de prétraitement de données.

Il est temps de passer à la deuxième partie et ça, c'est la construction du réseau de neurones artificiels.

Pour cela, nous allons utiliser la librairie Queyras.

Elle est forte, très facile à utiliser et c'est une librairie open source de Python.

Pour développer et évaluer des modèles de deep learning.

Commençons par évaluer From turn ce flow point.

Queyras pw model import sit cancel.

Froome.

Camera pw modèle import séquentiel.

From Cairo Point layer is.

Import dense classifié égal.

Séquentiel.

Ouvrez les parenthèses.

On apporte la classe séquentielle de la librairie Terrasse modèle et la classe dense de la librairie

Cairo Layer.

La classe séquentielle nous permet de construire un réseau neuronal artificiel, mais sous la forme

d'une séquence de couches.

Comme je vous l'ai dit dans la partie théorie, le réseau neuronal artificiel est construit avec des

couches entièrement connectées.

Pour créer un réseau neuronal artificiel, on a besoin d'initialiser notre réseau.

On commence par créer un objet de notre classe séquentiel.

C'est ce que fait la ligne Classifier égal séquentiel.

Ouvrez les parenthèses.

En faisant ceci, nous nous initialiser notre réseau par une variable qui se nomme classifieur.
## Ajout de la couche d’entrée et la première couche cachée
Maintenant, nous avons besoin d'ajouter des neurones à notre réseau classifié.

Pour ce faire, on utilise une méthode nommée AD.

Dans le classifieur, on écrit alors Classifieur, point ad.

Ouvrez la parenthèse danse.

Ouvrez la parenthèse.

Unite égale six virgule kernels.

Tiré du bas.

Initialisé égal.

Ouvrez les guillemets uniforme.

Fermez les guillemets virgules.

Activation égale.

Ouvrez les guillemets ou relu.

Fermez les guillemets.

Input tiré du bas dim et gal onze.

Fermer les deux parenthèses.

Ces quelques lignes vont ajouter de nouvelles composantes de réseau à notre modèle.

Cette méthode ADD prend en entrée des données de la classe dance dance est utilisée pour ajouter une

couche entièrement connectée dans le réseau de neurones artificiels.

Ce réseau est composé de onze neurones d'entrée et six neurones de sortie.

On va ajouter plusieurs couches comme celle ci pour que ces six neurones de sortie soient en fait des

neurones de couches cachées de notre réseau complet dense prend comme paramètre unique le nombre de

neurones dans la dernière couche.

Mais il n'y a pas de règle empirique pour cela.

C'est pour ça que j'ai utilisé six.

Vous pouvez utiliser n'importe quel autre numéro et vérifier un kernel initialisé.

C'est l'algo.

En fait, l'algorithme doit commencer avec un certain poids pour les variables d'entrée avant de les

changer.

Itérative.

Pour en avoir de meilleurs kernel, initialiser initialise les poids.

En cas d'une distribution statistique, la librairie générera des nombres de la distribution statistique

et les utilisera comme poids de départ.

Ici, on prend une distribution statistique uniforme.

Donc on prendra une distribution uniforme.

Des poids dans un premier temps.

Activation.

Il s'agit de la fonction d'activation.

La fonction d'activation dans la couche cachée pour un réseau neuronal entièrement connecté doit être

la fonction d'activation du redresseur.

Input tiret dim.

Notre coup je d'entrée à onze neurones.

Pourquoi onze?

Vous allez me dire parce que nous avons onze variables indépendantes?

Ben oui, rappelez vous, nous en avons deux pour géographie.

C'est pourquoi input tiret dim onze.

Maintenant, nous avons construit notre première couche d'entrée et une couche cachée.

Dans l'étape suivante, nous allons construire la couche cachée suivante.
## Ajout de la seconde couche cachée
Pour rajouter la deuxième couche cachée, on écrit.

Classifié.

Abd ouvrait la parenthèse.

Danse ouvrait la parenthèse.

Unité égale six virgule kernels.

Tiret du bas initialisé égal.

Ouvrez les guillemets uniform.

Fermez les guillemets, virgules, activation et gal.

Ouvrez les guillemets relus.

Fermez les guillemets, fermez les parenthèses, c'est la même ligne de code.

Sauf que nous n'avons pas besoin de spécifier les nombres d'entrée car il s'agit simplement de la couche

suivante.

Le code, c'est qu'il y a six couches dans la couche cachées précédentes.

Là encore, nous utilisons six neurones cachés dans la deuxième couche cachée de poids, répartis de

façon uniforme et avec la même fonction d'activation.

Maintenant, nous avons ajouté une couche d'entrée et deux couches cachées.

Il est temps d'ajouter notre couche de sortie.

Voyons comment nous pouvons le faire.
## Ajout de la couche de sortie
Dans la couche de sortie, nous avons besoin de un neurone.

Pourquoi un neurone?

Parce que, comme vous pouvez le voir dans le jeu de données, nous avons une variable dépendante.

Sous forme binaire, cela signifie que nous devons prédire sous forme zéro ou un.

Le client partira si nous avons un un et restera si nous avons un zéro.

C'est pourquoi un seul neurone est nécessaire dans la couche de sortie, ok.

Donc pour ajouter la couche de sortie, on écrit classifiée point AD.

Ouvrez la parenthèse danse.

Ouvrez la parenthèse unie égale un virgule kernel tiret du bas initialisé égal.

Ouvrez les guillemets uniform.

Fermez les guillemets, virgules, activation et gal ou les guillemets virgules sigmoïde.

Fermez les guillemets, fermez les parenthèses et j'écris Unix.

Un Parce qu'un seul neurone de sortie est suffisant, ce soit zéro, soit un.

La prochaine chose est la fonction d'activation.

Dans la couche de sortie, il devrait y avoir une fonction d'activation sigmoïde.

Pourquoi une fonction d'activation sigmoïde, me direz vous?

Parce que la fonction d'activation sigmoïde permet non seulement de prédire, mais fournit également

la probabilité que le client quitte la banque ou non.
## Compilation du réseau de neurones artificiels
Maintenant, nous en avons terminé avec la création de notre premier réseau de neurones artificiels.

Dans la première étape, nous entraîneront notre réseau de neurones artificiels.

On le fait en donnant des données d'entraînement à notre réseau.

Commençons l'entraînement de notre réseau de neurones artificiels.

On écrit.

Classifié.

Point.

Compile entre parenthèses.

Optimisé égal pour les guillemets.

ADM.

Jamais.

Guillemets.

Virgules.

Loss égale ou a les guillemets.

Binary tiré du bas cross.

Entropie.

Fermez les guillemets, virgules.

Métrique et gal.

Ouvrir le crochet.

Ouvrez les guillemets.

Accuracy.

Fermer les guillemets.

Fermer le crochet.

Compile est une méthode de la librairie Turn Off Law qui compile les réseaux neuronaux artificiels.

Ensemble.

Le premier paramètre et l'optimiser dans notre code, c'est ADM.

C'est l'optimiser.

Qui peut effectuer la descente de gradient en stochastique?

L'optimiser met à jour les poids pendant l'entraînement et réduit la perte.

Le paramètre suivant est le paramètre loss.

Elle représente la fonction coût.

Il s'agit d'une fonction d'optimisation qui est utilisée dans le cas de l'entraînement d'un modèle de

classification.

Cette fonction classifie les données en donnant une probabilité qu'une donnée appartienne à une classe

ou une autre.

Une chose que vous devez vous assurer lorsque vous faites une prédiction binaire similaire à celle ci.

Utilisez toujours la fonction de l'OS comme Binary cross entropie.

La fonction Binet reconcentre pi traite la grosse entropie entre la vraie étiquette et l'étiquette prédite

pour évaluer notre modèle de réseau.

Neurones.

Je vais utiliser des métriques de précision et c'est pourquoi.

Métrique égal au vrai, les crochets ouvrent les guillemets.

Précision fermez IE mais fermez, cochez.

La métrique de précision calcule à quel point l'étiquette prédite et la vraie étiquette.

Nous avons maintenant compilé notre modèle de réseaux neuronaux artificiels.
## Adaptation du RNA à l’ensemble d’apprentissage
Votre prochain objectif est de donner notre jeu, de donner au modèle.

Pour ce faire, nous allons utiliser la fonction fuite.

Faisons le en python.

Classifieur.

Fi.

Ouvrez la parenthèse X.

Tirets du bas trains.

Virgules.

I k du bas train.

La gueule.

Batch qui est du bas.

Size égale dix virgule époxy.

Égale sans ça.

Mais la pente est le premier argument et les entrées d'entraînement sont contre arguments.

Et les sorties d'entraînement?

Troisième argument et le patch six?

Au lieu de comparer notre prédiction avec les résultats réels en parent, il est bon de performer en

utilisant des lots.

C'est pour ça que j'écris batch size égale dix.

L'algorithme apprends donc dix lignes par des lignes.

Et le dernier argument est hypoxie.

Il s'agit du nombre de fois que l'algorithme va visiter l'ensemble de données.

Le réseau neuronal doit s'entraîner sur un certain nombre POC pour améliorer la précision au fil du

temps.

J'ai donc décidé que le nombre dit POC serait 100.

Ainsi, lorsque vous exécutez le code, vous pouvez voir la précision l'Acura curation à chaque hypoxie

pour les premiers iBooks Cura.

Si donc la précision est la suivante, elle tourne autour de 80 %.

Mais après avoir fait tourner 100 iBooks, on trouve la précision finale qui est de 85,44 %.

C'est assez bien.

Nous avons maintenant terminé l'étape d'apprentissage, la dernière étape et non des moindres.

Et de prédire les données d'ensembles tests.
## Prédiction des résultats de l'ensemble de tests
 Maintenant que notre modèle est entraîné, nous voulons voir comment notre modèle prédit les résultats

à partir des données de test X tirées du bas test.

Écrivons ces lignes de code.

Y a du bas spreads égal.

Classifieur, point predict.

Entre parenthèses x tiers du bas test.

Et Greg Proud Ygal entre parenthèses.

I proud supérieure à 0,5.

Fermer la parenthèse i prêt supérieur à 0,5 signifie que si, y compris entre zéro et 0,5, alors cette

nouvelle i prête deviendra à zéro.

Donc faux.

Et si ie près de supérieur à 0,5, alors la nouvelle i prête deviendra un vrai.

Voyons voir ce qu'il y a dans i spread.

Écrivons.

Print.

Parenthèse i tiret près.

Fermer la parenthèse.

Pouvez vous expliquer, en regardant ces valeurs prédites, combien de valeurs sont prédites correctement

et combien de valeurs sont prédites mal pour un petit jeu de données?

C'est possible, mais quand nous en avons un grand ensemble, c'est tout à fait impossible.

Et c'est pour ça qu'on utilise une matrice de confusion.

C'est pour dissiper notre confusion.

Donc nous écrivons le code suivant from escala un pw métrique.

Import confusion.

C'est du pas.

Matrix The girl accuracy tiré du bas score, c'est m égal.

Confusion qu'il a du bas.

Metric ou les parenthèses I tirées du bas.

Test you'll I like tirée du bas prod.

Fermer la parenthèse print ouvre les parenthèses.

C'est M.

Fermer la parenthèse Accuracy tirée du bas score.

Vous répondez y.

Tirets du bas test via Google i.

Tiret du bas.

Près de fermer la Pontaise.

La matrice de confusion est aussi appelée matrice d'erreur.

C'est une façon de prédire le résultat d'un problème de classification.

La matrice qui s'affiche à l'écran est une matrice de confusion.

Qui nous dit que 1499 valeurs trous sont prédites?

Trous.

Donc 1499 valeurs vraies sont vraies.

Que 96 valeurs full sont prédites.

Vrai que 189 valeurs vraies sont prédites fausses et que 216 valeurs fausses sont prédites de façon

correcte.

Fausse.

Donc la matrice de confusion nous donne un peu plus d'informations que juste les nombres de prédictions

correctement prédits et nous avons une précision de 85,75 %.

C'est pas mal.

Maintenant, je vous recommanderais d'expérimenter avec certaines valeurs et de me faire savoir quelles

précisions vous vous obtenez.

Félicitations!

Vous avez construit avec succès votre premier réseau de neurones artificiels.

Maintenant, il est temps de conclure.

C'est l'heure du quizz.

Le nombre de nœuds dans la couche d'entrée et dix le nombre de nœuds dans la couche cachés et cinq le

nombre maximum de connexions entre la couche d entrée et la couche cachées et.

J'espère que vous êtes prêts avec la réponse.

La réponse est l'option A, c'est à dire 50.

Étant donné que le Persée patron multicouche est un graphe dirigé entièrement connecté.

Le nombre de connexions est un multiple du nombre de nœuds dans la couche d'entrée et de la couche cachée.
# Section 9 : Réseaux de neurones convolutif (RNC) 134
## Introduction
Au cours des dernières décennies, le deep learning s'est avéré être un outil très puissant en raison

de sa capacité à gérer de grandes quantités de données.

L'intérêt d'utiliser des couches cachées a dépassé les techniques traditionnelles, en particulier dans

la reconnaissance de formes.

L'un des réseaux de neurones profonds les plus populaires et le réseau de neurones convulsif ou RNC,

le RNC est devenu une partie intégrante de la vision par ordinateur.

Dans ce cours, nous allons explorer cet outil que sont les réseaux de neurones.

Convolution.

Les RNC ont été développées et utilisées pour la première fois vers les années 80.

Le plus qu'un RNC pouvait faire à l'époque était de reconnaître les chiffres manuscrits écrits à la

main.

Ils étaient principalement utilisés dans les secteurs postaux pour lire les codes postaux, les codes

PI, et cetera.

La chose importante à retenir à propos de tous les modèles de deep learning, c'est qu'ils nécessitent

une grande quantité de données pour s'entraîner et nécessitent également beaucoup de ressources informatiques.

C'était un inconvénient majeur pour les rennes à cette époque et par conséquent, les RNC n'étaient

limités qu'aux secteurs postaux et n'ont pas réussi à entrer dans le monde de l'apprentissage automatique.

En 2012, Alex Krzyzewski a réalisé qu'il était temps de ramener la branche du deep learning, qui utilise

des réseaux de neurones multicouches.

La disponibilité de grands ensembles de données, notamment les ensembles de données.

Images n'est plus spécifique avec des millions d'images étiquetées et une abondance de ressources informatiques

a permis aux chercheurs de relancer les RNC en deep learning.

Un réseau neuronal qu'ont voulu TIFF, RNC ou convenaient est une classe de réseaux de neurones profonds,

le plus souvent appliqués pour analyser l'imagerie visuelle.

Maintenant, quand nous pensons à un réseau neuronal, nous pensons aux multiplications matricielles,

mais ce n'est pas le cas avec.

Net.

Il utilise une technique spéciale appelée convolution, maintenant en math.

La convolution est une opération mathématique sur deux fonctions qui produit une troisième fonction

qui exprime comment la forme de l'une est modifiée par l'autre.

La convolution est donnée comme l'intégrale du produit de la première fonction inverser et translaté

et de la seconde l'intégrale et calculée pour toutes les valeurs de translation possibles.

Notre image d'entrée est peut être en niveaux de gris ou en RGB.

Chaque image est composée de pixels allant de 0 à 255.

Nous devons les normaliser, c'est à dire convertir la plage comprise entre zéro et un avant de la passer

au modèle.
## Composants d’un réseau de neurones convolutifs
Passons maintenant en revue les composantes du RNC.

En détail, le RNC fonctionne en deux étapes l'extraction des caractéristiques et la classification

des caractéristiques extraites dans l'extraction des caractéristiques.

De nombreux filtres et couches de traitement sont appliquées aux images pour extraire l'information

et ses caractéristiques.

Quand c'est fait, on passe à l'étape suivante de classification ou les données sont triées en fonction

de la variable cible du problème.

Un RNC typique ressemble à ça couche d'entrée, couche de convolution plus fonction d'activation.

Couche de mise en commun et couche pleinement connectée.
## Couche de convolution
Voici une image d'entrée de taille 4X4 qui a quatre chaînes RGB et valeur du pixel.

La couche de convolution est la couche ou le filtre est appliqué à notre image d'entrée pour extraire

ou détecter ces caractéristiques.

Un filtre est appliqué à l'image plusieurs fois et crée une carte d'entité qui aide à classer l'image

d'entrée.

Comprenons.

Selon un petit exemple, pour plus de simplicité, nous prendrons une image d'entrée 2D avec des pixels

normalisés.

Dans la figure.

Nous avons une image d'entrée de taille six par six et nous avons appliqué un filtre de trois par trois

dessus pour détecter certaines caractéristiques.

Dans cet exemple, nous n'avons appliqué qu'un seul filtre, mais dans la pratique, de nombreux filtres

de ce type sont appliqués pour extraire des informations de l'image.

Le résultat de l'application du filtre à l'image et que nous obtenons une carte des entités de quatre

par quatre qui contient des informations sur l'image d'entrée.

De nombreuses cartes d'entités de ce type sont générées dans des applications pratiques.

Entrons dans quelques mathématiques derrière l'obtention de la carte des entités dans l'image ci dessus.

Le filtre est appliqué à partir de la partie verte ligné de l'image et les valeurs de pixels de l'image

sont multipliées avec les valeurs du filtre.

Comme indiqué dans la figure à l'aide de lignes, puis additionnées pour obtenir la valeur finale.

A l'étape suivante, le filtre est décalé d'une colonne, comme illustré dans la figure ci dessous.

Ce saut à la colonne ou à la ligne suivante est connu sous le nom de foulée et dans cet exemple, nous

prenons une foulée de un.

Ce qui signifie que nous nous déplaçons d'une colonne.

De même, le filtre passe sur toute l'image et nous obtenons notre carte d'entité finale.

Une fois que nous avons obtenu la carte des identités, une fonction d'activation lui est appliquée

pour introduire de la non-linéarité.

Un point noté ici est que la carte des entités que nous obtenons est plus petite que la taille de notre

image.

Au fur et à mesure que nous augmentons la valeur des foulées, la taille de la carte des entités diminue.
## Couche de mise en commun
La couche de mise en commun.

Cette couche est appliquée après la couche de convolution.

Elle est utilisée pour réduire les dimensions de la cartographie.

Par conséquent, elle réduit le nombre de paramètres à apprendre.

Cela conserve néanmoins les informations ou caractéristiques importantes de l'image d'entrée.

À l'aide de la mise en commun, une version d'entrée de résolution inférieure est créée et contient

toujours les éléments volumineux ou importants de l'image d'entrée.

Les types de mises en commun les plus courantes sont les mises en commun maximales, les mises en commun

moyennes.

La mise en commun maximale garde la valeur maximale de l'image.

Quel coût évolue alors que la mise en commun moyenne en garde la valeur moyenne?

La mise en commun moyenne aura tendance à lisser l'image et à ne pas beaucoup rendre compte des valeurs

aux extrémités.

La figure ci dessous montre le fonctionnement de la mise en commun maximale.

L'utilisation de la carte d'identité que nous avons obtenue à partir de l'exemple ci dessous pour appliquer

la mise en commun.

Ici, nous utilisons une couche de mise en commun de taille deux par deux avec une foulée de deux.

La valeur maximale de chaque zone en surbrillance est prise et une nouvelle version de l'image d entrée

est obtenue, qui est de taille deux par deux.

Donc, après l'application de la mise en commun, la dimension de la carte d'entité a été réduite.
## Couche pleinement connectée
Jusqu'à présent, nous avons effectué les étapes d'extraction de fonctionnalités.

Convolution et mise en commun va extraire des caractéristiques différentes d'une image.

Par exemple, les bords d'un bateau dans une image peut être détecté si l'image est un félin.

Par exemple, les yeux et la bouche peuvent être détectés après les couches de convolution et la mise

en commun.

On ajoute des couches entièrement connectées pour compléter l'architecture du réseau de neurones convolution.

Il s'agit de la même architecture de réseaux neuronaux artificiels entièrement connectés dont on a parlé

dans les cours précédents.

La sortie de la convolution et de la mise en commun sont 2D.

Mais nous, on a vu dans notre architecture entièrement connectée que nous avons besoin d'une couche

en 1D.

On a donc converti les sorties de la dernière couche de la mise en commun en un vecteur qui devient

l'entrée des couches entièrement connectées de notre réseau de neurones.

La couche entièrement connectée, comme nous l'avons donc dans un réseau de neurones artificiels, est

utilisée pour classer l'image d'entrée dans une étiquette.

Cette couche relie les informations extraites des étapes précédentes, c'est à dire couches de convolution

et couches de mise en commun.

À la couche de sortie et classe finalement l'entrée dans l'étiquette WET.

Le processus complet d'un modèle de RNC.

Peut être vu dans l'image.

# Section 10 :  Implémentation d'un RNC en Python 
## Base de données
Donc, après avoir compris la théorie qui alimente le RNC, nous allons plonger plus profondément dans

la partie implémentation en utilisant le RNC.

Voyons comment on peut l'implémenter en Python.

On va utiliser em NIST Henry in Digital Data qui consiste en des images de chiffres écrits à la main.

On sait quelques informations sur les données.

Les images sont toutes pré alignées.

Elles ne contiennent que des images écrites à la main.

On sait aussi que les images ont toutes la même taille de 28 par 28 pixels et que les images sont en

échelle de gris.
## Import de bibliothèques python
J'espère que vous avez maintenant une meilleure compréhension des Français.

Il est temps de l'implémenter en python.

Nous allons commencer par importer toutes les bibliothèques requises pour un modèle de RAID5.

Allons dans Jupiter et écrivons from turn off flow.

Point qui fera date à cette.

Qu'importe M least from ten surf law.

PW correspond au modèle import séquentiel.

From Ten Overflow.

Point que raz.

Point layers.

In porte conf 2d.

From tenseur flow.

Point Queyras Layer.

Peu importe max.

Boules de dés.

Froment, tant à flot que race, poing levé importe, flattant, froment dense à flot.

Point.

Keira Cairo Layer is.

Une porte.

Tu vas pas.

Froome danse à flots.

Enfin caresse l'air.

Une porte dense.

Dans la première ligne, on apporte même nist dataset.

Des images.

Le module type qu'on utilise est séquentiel.

Qu'on importe de crasse modal.

Ça permet de construire un modèle couche par couche.

On va travailler avec des images, donc on importe aussi conf 2d qui est la convolution en 2D pour nous

aider lors des couches de convolution.

On importe aussi d'autres librairies qui sont importantes pour la construction d'un RNC en Python.

On les expliquera dans la vidéo suivante.
## Construction du modèle RNC
M.

Liszt appartient à la librairie Erasme.

Donc on peut facilement le load.

Voyons comment on fait, on écrit.

Here we are loading de data.

Ici en charge les données entre parenthèses.

X tirée du bas train via Google.

I tiré du bas train.

Fermer la parenthèse virgule ouvrait la parenthèse x tiers du bas test.

Virgule i tiré du bas test.

Fermer la parenthèse égale m nicht point load.

Tirer du bas data.

Fermer la parenthèse.

Here we are shaping the data.

Ici, on va redimensionner les données.

X tiré du bas.

Train égal.

X tu es du bas train?

Point recap.

Ouvrez les parenthèses.

X tirée du bas.

Trains points shape.

Ouvrez les crochets.

Zéro.

Fermez les crochets.

Fermez la parenthèse.

Virgules x.

Tirets du bas.

Trains points.

Shape.

Ouvrez crochets.

Un.

Fermez le crochet virgule x tiers du bas train.

Shape.

Ouvrez le crochet.

Deux.

Fermez le crochet.

Virgules.

Pas en thèse.

X.

Que du bas.

Test égal x tiers du bas.

Test pw.

Re shape.

Ouvrir la parenthèse ou aller inventer x?

Tu à du bas?

Test shape ou est cochée.

Zéro ferme les crochets.

Fermer la parenthèse virgule.

X tiré du bas.

Test shape.

Ouvrez le crochet.

Un.

Fermez le crochet virgule W tiré du bas.

Test shape ou l crochet.

Deux.

Fermer le crochet virgule un.

Fermer les parenthèses.

Here we are checking the shape after all shaping.

Donc ici on va vérifier la dimension après le rond.

Redimensionnement.

Print voit la parenthèse x dir du bas train.

Shape ferme la parenthèse.

Print ouvre le point des X.

Tirets du bas.

Test pw shape ça va mais la parenthèse.

And here we are normal rising de pixels values.

Initie aux normes, en normalise les valeurs du pixel.

X tiré du bas train égal x tiers du train sur 255.

X tu as dû.

Bah test egal X tiré du bas test sur 255.

Lançons ce programme et voila on a une sortie depuis les 70 000 images que nous donne cet ensemble de

données.

Cette date A7 60 000 sont données pour l entrainement et 10 000 pour le test.

Quand on affiche l'ensemble des données X, qu'il y a du bas train et X du bas test.

Il contiendront des images et i télé du bas train et Y jean-baptiste contiendront les numéros que ces

images représentent.

Notre prochain objectif est de reformer la taille de notre image.

Nous savons certaines choses sur l'ensemble des données.

Par exemple, nous savons que les images sont toutes pré alignées, que les images ont toutes la même

taille.

28 par 28.

Et que les images sont en niveau de gris.

Mais les dimensions de nos images ne seront peut être pas toujours égales.

Il vaut donc mieux ré homogénéiser dans le doute toutes les tailles et couleurs.

On le fait en utilisant la méthode Read Shape.

Elle prend trois arguments.

Le premier est le nombre d'images, le deuxième le nombre de pixels dans une colonne, le troisième

le nombre de pixels dans une ligne et le quatrième la couleur pour x terrain.

Dans notre cas, le premier argument sera 6000.

On sait de plus que la taille de notre image est de 28 par 28.

Donc on peut mettre comme deuxième et troisième argument 28.

Le dernier argument sera un qui représente une échelle de gris.

On fait de même pour X tests.

La seule différence est que ici le nombre d'images et de 1000 et non 6000.

Pour vérifier la forme, on écrit print.

Ouvrez la parenthèse X tiret du huit trains PWA shape.

Fermez la parenthèse.

Print.

Ouvrez la parenthèse X tirée du bas test pw.

Shape.

Fermez la bande et on a notre sortie.

Nous savons que les valeurs de pixels pour chaque image du jeu de données sont des entiers non signés

dans la plage comprise entre le noir et le blanc ou zéro et 255.

Nous ne connaissons pas la meilleure façon de mettre à l'échelle les valeurs de pixel pour la modélisation,

mais nous savons qu'une certaine mise à l'échelle serait nécessaire.

Un bon point de départ consiste à normaliser les valeurs de pixels des images en niveaux de gris, par

exemple en les redimensionnement à la plage zéro un.

Cela implique de convertir le type de données d'entiers non signés en flottants, puis de diviser les

valeurs de pixels par la valeur maximale.

Donc on divise par 255.

Voyons comment nous pouvons le faire en python.

Ensuite, nous devons définir un modèle de réseau neuronal convolution de base pour le problème.

Le modèle comporte deux aspects principaux le front end d'extraction de fonctionnalités composé de couches

évolutives et de pooling et le back end du classificateur qui fera une prédiction.

On le fait en écrivant ces lignes.

Modèle égal.

Séquentiel.

Ouvrir et fermer la parenthèse.

Le modèle a deux aspects principaux.

Le feature extraction qui consiste en une couche convolution vive et une couche de pooling.

Un classifieur constitué de couches entièrement connectées qui fera une prédiction.

Pour le front end.

Convoler hâtif, nous pouvons commencer par une seule couche qu'on vaut l'utile, avec une petite taille

de filtre trois trois et un nombre modeste de filtres 32.

On écrit modèle pw ad.

Entre parenthèses conf 2d.

Voyez la parenthèse 32 virgule à la parenthèse 3,3.

Fermer la parenthèse virgule activations égale.

Ouvrez les guillemets relus.

Fermez les guillemets.

Virgules.

Input t es du bas shape égale.

Ouvrez la parenthèse 28,20 8,1.

Fermez toutes les parenthèses.

On utilise la fonction d'activation relue dans notre couche.

L'image d'entrée a une taille 28 par 28 en nuances de gris.

Ensuite, on ajoute une couche de pooling maximale.

On écrit Model AD.

Ouvrez la parenthèse Max pool 2D.

Ouvrez la parenthèse 2,2.

Fermez les parenthèses.

La taille du maximal pooling est de deux par deux, ce qui veut dire que le filtre va prendre la valeur

maximale de chaque carré de pixels deux par deux.

Continuons avec le code.

On écrit Adding fully connected layers.

Comme commentaire, on ajoute des couches entièrement connectées, puis.

Modèle pw ad.

Entre parenthèses flatteuses.

Fermer.

Parenthèses fermant les parenthèses.

Modèle AD ou la parenthèse dense.

Ouvrez la parenthèse sans virgules.

Activation égale ou réelle guillemets relu.

Fermez les guillemets.

Fermer les parenthèses.

Entre les couches conf 2D et les couches denses, il y a une couche flottant aplatie qui sert comme

communication entre les couches de convolution et les couches denses denses.

Et le type de couche que nous allons utiliser pour notre couche de sortie dense est un type classique

qui est utilisé dans de nombreux cas de réseaux de neurones.

La méthode Flathead convertit les valeurs des pixels d'images 2D à des tableaux en 2D.

On ajoute une couche dense de 100 neurones dans notre coach de sortie en utilisant comme fonction d'activation

la fonction relou.

OK, continuons avec notre code, on écrit Adding output layer.

Comme commentaire, on ajoute une couche de sortie modèle AD.

Ouvrez la parenthèse danse, ouvrez la parenthèse dix virgule activations égales.

Ouvrez les guillemets soft max.

Fermez les guillemets, fermez la parenthèse.

Là, on ajoute une couche dense de dix neurones dans notre couche de sortie parce que nous savons qu'il

y a que dix chiffres possibles, donc de 0 à 9.

La fonction d'activation est soft max soft max fait en sorte que la somme des sorties soit un.

Le modèle peut donc être interprété comme une probabilité, puis on peut mettre en sortie le chiffre

qui a la plus grande probabilité.

OK, maintenant que notre modèle est prêt, nous devons le compiler comme nous l'avons fait dans l'exemple

précédent.

La seule différence, c'est que nous utilisons comme fonction coût par catégorie Karl Kraus entropie

au lieu de Binary Crossing Orbit car c'est un problème de catégorie alors que le problème précédent

était un problème binaire, c'est à dire le client part de la banque ou non, et nous on a des chiffres

de 0 à 9.

On écrit.

Copies.

Lignes de modèles comme commentaires.

Donc on compile le modèle.

Modèle PW.

Compil.

Ouvrez la parenthèse l'OS égal.

Ouvrez les guillemets.

Space tiré du bas catégorie cal tiré du bas cross.

Entropie.

Fermez les guillemets.

Virgules optimisées égales.

Ouvrez les guillemets à dames.

Fermez les guillemets.

Virgules.

Métrique égale ou a les crochets.

Ouais.

Les guillemets accuracy.

Fermer les guillemets fermés, crochets fermés.

Appointés.

La dernière étape de notre RNC, c'est d'adapter notre modèle sur les données M9.

On écrit fitting de modèles comme commentaires et.

Modèle point fixe.

Ouvrez la parenthèse Xtreme.

Virgule y train.

Une virgule, Hippocrate égale dix femmes appointés.

Pour adapter notre modèle aux données, on utilise la méthode PHI.

De plus, on spécifie que iBooks dix, ce qui veut dire que notre modèle parcourra notre ensemble de

données dix fois.
## Performance du modèle
Nous attendons que notre modèle soit formé et que toutes les hypothèques soient terminées.

Et Dada.

Notre français est entraîné.

Maintenant, on évalue le modèle.

On écrit comme commentaires.

Évaluez de modèle.

On évalue le modèle puis modèle PW.

Évaluer King.

Ouvrez la parenthèse X.

Test virgule I test farmer la Pontaise.

Vérifions l'exactitude de notre modèle.

Incroyable.

Sa précision est de 98,64 %.

Félicitations!

Vous avez construit votre premier modèle RNC.

C'est l'heure du quizz.

Alors à votre avis, quand une couche de mise en commun est ajoutée à un réseau de neurones?

Convolution, la variance est elle préservée?

Vrai ou faux?

Prêts.

Nous voyons la réponse.

La réponse est l'option A.

Vrai car l'invariance de la traduction est induite.

Lorsque vous utilisez le regroupement.

Merci d'avoir suivi ce cours sur le deep learning.




References:
- [Python pour le Deep Learning & le Machine Learning: A à Z](https://www.udemy.com/course/machine-learning-et-deep-learning-avec-python-la-formation-complete/)
- 


Created:: 2024-03-14 10:55