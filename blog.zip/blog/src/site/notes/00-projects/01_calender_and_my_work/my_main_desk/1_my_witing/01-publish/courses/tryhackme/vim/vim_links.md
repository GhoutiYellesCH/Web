---
{"dg-publish":true,"permalink":"/00-projects/01-calender-and-my-work/my-main-desk/1-my-witing/01-publish/courses/tryhackme/vim/vim-links/","dgPassFrontmatter":true,"noteIcon":""}
---

- https://medium.com/@tr1n1ty8/tryhackme-toolbox-vim-writeup-18ddadbacf72
- http://www.oualline.com/vim-cook.html#char%20twiddling
- https://vimhelp.org/#reference_toc
